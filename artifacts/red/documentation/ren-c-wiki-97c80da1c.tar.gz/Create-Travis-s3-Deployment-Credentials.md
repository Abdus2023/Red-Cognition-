Moved to here:

https://forum.rebol.info/t/create-travis-s3-deployment-credentials/1345