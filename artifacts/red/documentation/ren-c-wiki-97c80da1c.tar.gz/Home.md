The main place to look for notes being taken about Ren-C progress is currently the Trello:

https://trello.com/b/l385BE7a/rebol3-porting-guide-ren-c-branch

However, these GitHub wiki pages are an experiment as a place to put notes that may be too long for that format, including the FAQ.  It may wind up being used or not.
