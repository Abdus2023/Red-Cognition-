Moved to:

https://forum.rebol.info/t/on-building-ren-c-with-c-compilers/1343