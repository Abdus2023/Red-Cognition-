Moved to:

https://forum.rebol.info/t/relative-binding-and-frame-internals/1344