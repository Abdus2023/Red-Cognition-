Red's toolchain can pull a C or C++ library straight into your executable, so that what you ship is one file: no DLLs, no `.so` files, no installer. The Red side of that is a single switch:

```
red -r -s myapp.red
```

Everything else happens on the library side — how the archive was compiled, and what shape its Red-facing surface has. This page is that contract, plus the platform recipes to satisfy it. It is not a description of how the linker works internally.

The library's *internals* can be arbitrary C++: templates, exceptions, RTTI, `std::` containers, global constructors, thread-local storage. That part is settled — the libraries listed at the bottom of this page were linked and run on all four supported targets. The constraints below concern **how the library is compiled** and **how its surface is shaped**, and there are only six of them.

## Requirements at a glance

| | Requirement |
|---|---|
| **Architecture** | 32-bit, matching the Red target (x86, or ARM32 for `-t RPi`) |
| **Optimization** | No LTO — never `/GL` (MSVC) or `-flto` (gcc/clang) |
| **Runtime model** | Static: `/MT` on Windows, static archives elsewhere |
| **Import surface** | `extern "C"`, cdecl (stdcall also works on Windows) |
| **Exceptions** | Must not escape into Red — catch-all guard on every export |
| **Packaging** | One bundled archive per library, ideally |
| **Toolchain on the linking machine** | Windows: VS Build Tools ("Desktop development with C++") for C++ libraries, *nothing* for pure C. Linux: 32-bit static gcc runtime. macOS: nothing. |

## Contents

1. [The shape of a static-linkable library](#1-the-shape-of-a-static-linkable-library)
2. [The six rules](#2-the-six-rules)
3. [A worked example](#3-a-worked-example)
4. [Windows / MSVC](#4-windows--msvc)
5. [Linux / x86](#5-linux--x86)
6. [Linux / ARM32 (Raspberry Pi)](#6-linux--arm32-raspberry-pi)
7. [macOS / i386](#7-macos--i386)
8. [When the link fails](#8-when-the-link-fails)
9. [What has been validated](#9-what-has-been-validated)

## 1. The shape of a static-linkable library

Before the details, the picture. Four things sit between an upstream C++ library and your Red program:

```
   upstream C++ library          your C shim               one archive              your Red code
  +--------------------+      +----------------+      +------------------+      +--------------+
  | classes, templates |      |  extern "C"    |      |  foo-red.lib     |      | #import [    |
  | exceptions, STL    | ---> |  entry points, | ---> |  = shim.obj      | ---> |  "foo-red"   |
  | built /MT, no LTO  |      |  catch-all     |      |  + every dep     |      |  cdecl [...] |
  +--------------------+      +----------------+      +------------------+      +--------------+
```

The **shim** is a small C or C++ source file you write once. It is where C++ turns into C: it hides classes behind opaque handles, flattens volatile structs into scalars, and catches every exception before it can escape. It is the only part of this pipeline you author, and for most libraries it is a few hundred lines.

The **bundle** is a single archive containing the shim object and all of the library's own archives merged together, so your Red source has exactly one `#import` naming exactly one file. Nothing forces you to bundle — several archives can be imported — but a single file is far easier to move between machines and to check into a project.

If a library already publishes a C API (SQLite, libxmp, SDL, llama.cpp's `llama.h`), the shim shrinks to just the exception guards, or disappears entirely for a pure-C library.

## 2. The six rules

### 2.1 — 32-bit objects only

The library must be compiled for the same 32-bit architecture as your Red target: x86 for Windows, Linux and macOS, ARM32 for Raspberry Pi. 64-bit objects are rejected with a clear message rather than mis-linked. The 64-bit story arrives with the 64-bit toolchain.

### 2.2 — Real machine code, no link-time optimization

`/GL` on MSVC and `-flto` on gcc/clang do not produce machine code; they produce compiler bitcode that only that vendor's own linker can finish compiling. Red's linker rejects such objects by name. Default CMake `Release` settings are fine on every platform — just don't add LTO.

### 2.3 — The imported surface is C, not C++

Everything Red imports must be `extern "C"`, using `cdecl` (or `stdcall` on Windows). This is not a limitation of static linking: mangled names, `thiscall`, templates and inline code have no linkable surface under dynamic linking either. The extern-C surface is the contract in both worlds.

Scalars, pointers and by-value structs all reach across it — Red/System passes and returns `struct!` by value with the `value` keyword. Even so, for large or version-volatile structs (the `llama_model_params` class of API) the recommended pattern is to hide them in the shim behind pointer-and-scalar entry points. The reason is maintenance: an R/S struct declaration has to mirror the C layout field for field across library upgrades, and unions, bitfields and packed layouts have no `struct!` equivalent at all. A thin shim absorbs those hazards in one place.

### 2.4 — Exceptions must never cross the boundary

Red frames carry no unwind tables, so a C++ exception that escapes into Red terminates the process. Inside the library, exceptions are perfectly fine (with one caveat on old macOS, noted below) — they simply must not leave it. Put a catch-all guard in every exported function:

```cpp
extern "C" int foo_do_thing(void* h, const char* arg) {
    try {
        ((Foo*)h)->do_thing(arg);
        return 0;
    } catch (const std::exception& e) {
        set_last_error(e.what());
        return -1;
    } catch (...) {
        set_last_error("unknown error");
        return -2;
    }
}
```

Pair it with a `foo_last_error()` accessor so the Red side can report what went wrong. This pattern costs nothing at runtime and turns a hard crash into a return code.

### 2.5 — Build against the static runtime model

The linker supplies the C++ runtime itself, so the library must not be built against DLL runtimes: `/MT` (never `/MD`) on Windows, ordinary static archives elsewhere.

### 2.6 — Bundle everything into one archive

Merge the shim object and every dependency into a single archive:

```
lib /OUT:foo-red.lib shim.obj dep1.lib dep2.lib dep3.lib
```

On Linux and macOS, GNU `ar` merges archives through an MRI script:

```
CREATE foo-red.a
ADDMOD shim.o
ADDLIB dep1.a
ADDLIB dep2.a
SAVE
END
```

...fed to `ar -M < bundle.mri`. Your Red side is then a single import:

```red
#import ["foo-red" cdecl [ ... ]]
```

Note the **missing extension**. An extension-less name resolves per platform and per mode: with `-s` it becomes `foo-red.lib` on Windows and `foo-red.a` on Linux and macOS, so one Red source compiles everywhere. Write a suffix explicitly (`"foo-red.lib"`) and it is taken verbatim, which ties that source to one platform. Relative names resolve against the directory of the Red file holding the `#import`.

## 3. A worked example

A complete miniature library, from C++ source to running Red program. It keeps a `std::vector<double>` alive behind an opaque handle — enough to exercise C++ allocation, templates and exceptions.

**`stats.cpp`** — ordinary C++ inside, a C surface outside:

```cpp
#include <vector>
#include <algorithm>
#include <stdexcept>

struct Stats { std::vector<double> xs; };

extern "C" {

void* stats_new(void) {
    try { return new Stats(); } catch (...) { return 0; }
}

void stats_free(void* h) { delete (Stats*)h; }

int stats_add(void* h, double v) {
    try { ((Stats*)h)->xs.push_back(v); return 0; } catch (...) { return -1; }
}

double stats_median(void* h) {
    try {
        std::vector<double>& xs = ((Stats*)h)->xs;
        if (xs.empty()) throw std::runtime_error("empty");
        std::vector<double> c(xs);
        std::sort(c.begin(), c.end());
        return c[c.size() / 2];
    } catch (...) { return -1.0; }
}

}
```

**Build and bundle** (Windows shown; see the platform sections for the others):

```
cl /nologo /c /MT /O2 /EHsc stats.cpp
lib /nologo /OUT:stats-red.lib stats.obj
```

**`demo.reds`** — the Red/System side:

```red
Red/System []

#import ["stats-red" cdecl [
    stats-new:    "stats_new"    [return: [int-ptr!]]
    stats-free:   "stats_free"   [h [int-ptr!]]
    stats-add:    "stats_add"    [h [int-ptr!] v [float!] return: [integer!]]
    stats-median: "stats_median" [h [int-ptr!] return: [float!]]
]]

st: stats-new
stats-add st 3.0
stats-add st 1.0
stats-add st 2.0
print ["median: " stats-median st lf]
stats-free st
```

**Compile:**

```
red -r -s demo.reds
```

The report shows the static link happening and — because this is C++ — the MSVC static CRT being located and taking over the program entry:

```
Compiling to native code...
Static linking...
...linking          : stats-red.lib
...default library : libcpmt.lib
...default library : libcmt.lib
...MSVC static CRT : entry -> mainCRTStartup, Red start -> _main
...default library : oldnames.lib
...default library : libvcruntime.lib
...default library : libucrt.lib
...static-link time : 1563 ms
...output file size : 217600 bytes
```

Running it prints `median: 2.0`. That is one 213 KB `demo.exe` with a C++ standard library inside it and no sidecars.

## 4. Windows / MSVC

### Compiler settings

- x86 toolset (`vcvarsall amd64_x86` or `x86`).
- **`/MT`** — never `/MD`.
- No `/GL`. `/bigobj` is supported if the library needs it.
- `/EHsc` exceptions and RTTI work fully.
- Compile the shim itself with **`/TP`** so it is treated as C++ and its catch-all guards are actually armed — a `.c` shim compiled as C has no `try`/`catch`.
- `__declspec(thread)` and C++ `thread_local` work, including dynamic initialization and the VS2019+ `/Zc:tlsGuards` on-demand path.
- Watch for 64-bit-only intrinsics that do not exist on x86-32 — `_pdep_u64` and friends. They usually hide behind a CMake feature switch (for example, ggml needs `GGML_BMI2=OFF`). AVX2 and the other SIMD families are fine.

### What must be installed on the linking machine

There are two tiers, and the difference matters:

**Pure-C archives: nothing at all.** A freshly installed Windows 11 with only the Red toolchain on it links them. The C runtime resolves through the toolchain's embedded msvcrt trampolines, Win32 APIs through its embedded export snapshots, and COM/DirectX/MediaFoundation **GUID constants through an embedded table** of 14,308 names taken from the SDK's GUID archives. No `vswhere.exe`, no Windows SDK, no Visual Studio.

**Anything needing the static MSVC CRT: the VS Build Tools.** That means any C++ library, and also `/MT` C code that trips the CRT markers — exceptions, `operator new`, thread-safe statics, `thread_local`. Install the free **Visual Studio Build Tools** with the **"Desktop development with C++"** workload. That single action delivers both halves of the chain: the VC toolset (`libcmt`, `libcpmt`, `libvcruntime`, `oldnames`) and the Windows SDK (`libucrt`, `um`).

Nothing needs configuring afterwards. The linker finds the toolset by itself through the VS installer's own instance database and the default install roots — any year, any edition, picking the newest toolset that actually carries `lib\x86` — and the SDK through the registry. No `vcvarsall`, no `PATH` edits, no environment variables.

When the CRT engages you will see it in the compilation report, as in the worked example above:

```
...default library : libcmt.lib
...MSVC static CRT : entry -> mainCRTStartup, Red start -> _main
```

If those lines are absent from a C++ link, the toolset was not found — and the link will fail a moment later on CRT symbols.

### One known gap

A handful of oversized SDK constants (PROPERTYKEYs, DBIDs — 20 bytes and up) are deliberately outside the embedded GUID table. A library referencing those as externs needs its SDK archive named explicitly in the import. Most consumers never notice, because the common PROPERTYKEYs are defined inline by their headers into the referencing object.

## 5. Linux / x86

- `g++ -m32`, plain non-PIC static code, no LTO.
- Exceptions, RTTI and `thread_local` are all supported.
- The GNU runtime archives — `libstdc++.a`, `libgcc.a`, `libgcc_eh.a`, `libatomic.a`, plus `crtbeginT.o`/`crtend.o` — are pulled in automatically. Install your distribution's 32-bit static/multilib gcc packages on the build host, or keep those archives next to the bundle if you are cross-linking from Windows.

If they are missing, the linker says exactly what it wants:

```
C++ objects need the GNU runtime: put libstdc++.a, libgcc.a,
libgcc_eh.a (+ crtbeginT.o/crtend.o) next to the imported archive
```

## 6. Linux / ARM32 (Raspberry Pi)

- Build armhf, natively on the device. The Red target is `-t RPi`.
- On a 64-bit kernel running a 32-bit userland, pass `-DCMAKE_SYSTEM_PROCESSOR=armv7l` — without it, NEON and feature detection select the wrong code paths.
- EHABI exceptions (`.ARM.exidx`), variant-1 TLS and 64-bit atomics (libatomic) are all handled.
- The distro-default ARM mode is the battle-tested path. Thumb-2 objects link too.
- The GNU runtime archives are located the same way as on x86.

## 7. macOS / i386

For the 10.9-era 32-bit target:

- `clang++ -arch i386 -mmacosx-version-min=10.9 -mdynamic-no-pic`.
- **C++ exceptions work** — throw/catch verified on 10.9. Era-typical CIE encodings are supported; anything more exotic aborts the link loudly rather than mis-linking.
- **No `thread_local`** — 32-bit Mach-O has no thread-local storage at all.
- `dynamic_cast` beyond catch-type matching is untested; build with `-fno-rtti` if in doubt.
- Nothing needs installing beyond the toolchain: libc++, libc++abi, libSystem and framework symbols bind dynamically without any action from you (Apple ships no static libc++), and the linker carries the export tables it needs.

## 8. When the link fails

The linker aims to name the cause rather than emit a wall of symbols. The messages you are most likely to meet:

| Message | Cause | Fix |
|---|---|---|
| `cannot link <file> -- anonymous LTCG object (compiled with /GL); rebuild without /GL` | MSVC link-time code generation | Rebuild without `/GL` |
| `cannot link <file> -- LLVM bitcode (compiled with -flto); rebuild without link-time optimization` | gcc/clang LTO | Rebuild without `-flto` |
| `cannot link <file> -- x86-64 (64-bit) object; this build targets 32-bit x86` | 64-bit build | Rebuild for x86 / armhf |
| `cannot link <file> -- import-library member (dynamic-linking stub, not static code)` | You pointed at a DLL's import library | Get the real static archive |
| `<lib> is an import library (dynamic-linking stubs); import the DLL directly or provide the static archive` | Same, at the import level | Either drop `-s` for that library, or supply the static build |
| `unresolved external symbol: <name> (in <path>)` | A dependency archive is missing from the bundle | Add it — see below |
| `C++ objects need the GNU runtime: ...` | Missing 32-bit libstdc++/libgcc | Install the multilib static packages |
| `static import <name> not defined in <lib>` | The name in your `#import` doesn't exist in the archive | Check for a missing `extern "C"`, or a leading-underscore mismatch |

**Reading an unresolved-symbol failure.** It always means the same thing: some object that got merged references a symbol nobody defines. Two common shapes:

- *C++-looking names* (`??2@YAPAXI@Z`, `__CxxFrameHandler3`, `_memcpy`) on Windows → the static CRT was not found. Install the VS Build Tools with the C++ workload.
- *Names from a third library you forgot* → a dependency of your dependency. Add its archive to the bundle and relink.

