# Red and AI

In AI era, Red doesn't become obsolete: it becomes even more relevant than before. 

[LLM](https://en.wikipedia.org/wiki/Large_language_model) benefits from simple, clean and readable code in the same way humans do: 
- it has limited context, so a better signal-to-noise ratio allows it to build more and better
- per-token pricing means every insignificant syntactic detail has to be paid for

Red and REBOL were always about reducing software complexity, and the only thing AI changes is that this reduction now becomes easily quantifiable with LLM bills.

## Red/Sensei

A [RAG](https://en.wikipedia.org/wiki/Retrieval-augmented_generation)-powered *LLM chatbot* dedicated to Red language: [ask.lang.red](https://ask.lang.red/chat)

It's *main goal* is to help others learn Red and to query existing knowledge. It currently uses semantic and full-text search, so it can both grab meaningfully relevant context and look up exact terms, like function names or magic numbers.

It answers user's Red questions *in user's language*, bringing Red access to a wide audience.

## Agents

Red/Sensei is also available as a *skill* for any other [AI agent](https://en.wikipedia.org/wiki/AI_agent) of your choice: https://ask.lang.red/assets/SKILL.md

Unlike chatbots, agents have a direct feedback loop from their actions. This allows them to self-correct as they work and build actually working projects autonomously.

*To install* the skill, typically you either:
- ask your agent to install the skill from the URL above, or
- manually save it as `.agents/skills/red-sensei/SKILL.md` in your user profile or where the agent is installed

And then restart the agent. From there on the skill must work automatically.

**Warning**: running agents on your daily device is risky. Whenever possible, run it either on a *separate dedicated device* (e.g. VPS, old and clean laptop, Raspberry Pi) or at least on a VM. Do not give that device access to your actual file systems. Always assume that all the data it has access to will at some point end up in the hands of a party that's going to use this data against you.

### Recommended models

Not all models are equally proficient in Red, as it's not a popular language yet. To get good results, you have to choose the right one.

hiiamboris constantly monitors new LLMs and has an [AI arena page](https://codeberg.org/hiiamboris/red-dataset/wiki/LM-Skirmish). In particular, [the leaderboard](https://codeberg.org/hiiamboris/red-dataset/wiki/LM-Skirmish#leaderboard) table can help you choose the right model for your budget.

AI harnesses are a boiling cauldron, with no really overall good solutions in existence. If you are looking for an open source harness that just works and doesn't limit you in the model choice, try [OpenCode](https://opencode.ai/). You may use [openrouter](https://openrouter.ai/) to get access to the widest variety of models on the market (and it's anonymous with crypto payments support).

