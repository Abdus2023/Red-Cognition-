# Container Test Report

- Commit: `f860bbe075f26e0d3365c645d12a01097f81ef58`
- Image: `red-cognition/rebol-bootstrap:2.7.8`
- Platform: `linux/386`
- Started: `2026-08-30T09:31:24Z`
- Finished: `2026-08-30T09:37:09Z`

| Suite | Exit | Assertions | Passed | Failed | Failure marker |
|---|---:|---:|---:|---:|---|
| Red | 1 | 29410 | 29306 | 104 | True |
| Red/System | 0 | 10560 | 10560 | 0 | False |

**Overall result:** FAIL
