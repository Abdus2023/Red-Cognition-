# Container Test Report

- Commit: `f860bbe075f26e0d3365c645d12a01097f81ef58`
- Image: `red-cognition/rebol-bootstrap:2.7.8`
- Platform: `linux/386`
- Started: `2026-08-30T09:25:02Z`
- Finished: `2026-08-30T09:25:02Z`

| Suite | Exit | Assertions | Passed | Failed | Failure marker |
|---|---:|---:|---:|---:|---|
| Red | 125 | None | None | None | False |
| Red/System | 125 | None | None | None | False |

**Overall result:** FAIL
