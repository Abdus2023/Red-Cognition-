# Container Test Report

- Commit: `f860bbe075f26e0d3365c645d12a01097f81ef58`
- Image: `red-cognition/rebol-bootstrap:2.7.8`
- Platform: `linux/386`
- Started: `2026-08-30T09:25:20Z`
- Finished: `2026-08-30T09:30:00Z`

| Suite | Exit | Assertions | Passed | Failed | Failure marker |
|---|---:|---:|---:|---:|---|
| Red | 1 | 332 | 236 | 96 | True |
| Red/System | 0 | 10560 | 10560 | 0 | False |

**Overall result:** FAIL
