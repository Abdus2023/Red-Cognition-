Red [
    Title: "Checksum diagnostic"
]

print ["MD5 empty:" checksum #{} 'MD5]
print ["SHA256 empty:" checksum #{} 'SHA256]
print ["HMAC-SHA256 RFC4231:" checksum/with #{4869205468657265} 'SHA256 #{0B0B0B0B0B0B0B0B0B0B0B0B0B0B0B0B0B0B0B0B}]
