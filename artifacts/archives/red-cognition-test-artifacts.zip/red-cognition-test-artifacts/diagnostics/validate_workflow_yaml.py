from pathlib import Path

try:
    import yaml
except ImportError as exc:
    raise SystemExit(f"PyYAML unavailable: {exc}")

path = Path(".github/workflows/red-container-tests.yml")
data = yaml.safe_load(path.read_text())
assert isinstance(data, dict), "workflow root must be a mapping"
assert data.get("name") == "Red container tests"
assert "push" in data.get("on", data.get(True, {})), "push trigger missing"
assert "workflow_dispatch" in data.get("on", data.get(True, {})), "manual trigger missing"
assert data["permissions"]["contents"] == "read"
job = data["jobs"]["container-tests"]
assert job["runs-on"] == "ubuntu-24.04"
steps = {step.get("name"): step for step in job["steps"]}
required = {
    "Check out repository",
    "Enable i386 emulation",
    "Set up Docker Buildx",
    "Download and verify Rebol 2.7.8 bootstrap",
    "Build 32-bit Rebol test image",
    "Run Red and Red/System container tests",
    "Publish test reports",
}
missing = required - steps.keys()
assert not missing, f"missing steps: {sorted(missing)}"
assert steps["Publish test reports"]["if"] == "always()"
print("workflow structural validation: PASS")
