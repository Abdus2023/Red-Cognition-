
			Red/System []
			f: func [
				x [float!]
				return: [integer!]
				/local sr [subroutine!] y
			][
				y: as integer! x
				sr: [push as integer! y]
				0
			]
			probe f 100.0
		