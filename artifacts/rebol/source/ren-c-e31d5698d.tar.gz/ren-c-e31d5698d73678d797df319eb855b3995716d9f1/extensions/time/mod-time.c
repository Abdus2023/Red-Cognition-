//
//  file: %mod-time.c
//  summary: "Time Extension"
//  section: ports
//  project: "Rebol 3 Interpreter and Run-time (Ren-C branch)"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012 REBOL Technologies
// Copyright 2012-2017 Ren-C Open Source Contributors
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information.
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//


#include "sys-core.h"
#include "tmp-mod-time.h"


extern Value* Get_Current_Datetime_Value(void);

//
//  export /now: impure native [
//
//  "Returns current date and time with timezone adjustment"
//
//      return: [date! time! integer!]
//      :year "Returns year only"
//      :month "Returns month only"
//      :day "Returns day of the month only"
//      :time "Returns time only"
//      :zone "Returns time zone offset from UCT (GMT) only"
//      :date "Returns date only"
//      :weekday "Returns day of the week as integer (Monday is day 1)"
//      :yearday "Returns day of the year (Julian)"
//      :precise "High precision time"
//      :utc "Universal time (zone +0:00)"
//      :local "Give time in current zone without including the time zone"
//  ]
//
DECLARE_NATIVE(NOW)
{
    INCLUDE_PARAMS_OF_NOW;

    Api(Value*) timestamp = Get_Current_Datetime_Value();
    Copy_Cell(OUT, timestamp);
    rebRelease(timestamp);

    // However OS-level date and time is plugged into the system, it needs to
    // have enough granularity to give back date, time, and time zone.

    trap (  // shouldn't be unstable, but API's RebolValue* doesn't stop it
      Stable* stable = Decay_If_Unstable(OUT)
    );
    if (
        not Is_Date(stable)
        or not Does_Date_Have_Time(stable)
        or not Does_Date_Have_Zone(stable)
    ){
        panic ("Get_Current_Datetime_Value() didn't give date w/time and zone");
    }

    Element* out = As_Element(stable);

    if (not ARG(PRECISE)) {
        //
        // The "time" field is measured in nanoseconds, and the historical
        // meaning of not using precise measurement was to use only the
        // seconds portion (with the nanoseconds set to 0).  This achieves
        // that by extracting the seconds and then multiplying by nanoseconds.
        //
        Tweak_Cell_Nanoseconds(out, SECS_TO_NANO(VAL_SECS(out)));
    }

    if (ARG(UTC)) {
        //
        // Say it has a time zone component, but it's 0:00 (as opposed
        // to saying it has no time zone component at all?)
        //
        VAL_ZONE(out) = 0;
    }
    else if (ARG(LOCAL)) {
        //
        // Clear out the time zone flag
        //
        VAL_ZONE(out) = NO_DATE_ZONE;
    }
    else {
        if (
            ARG(YEAR)
            or ARG(MONTH)
            or ARG(DAY)
            or ARG(TIME)
            or ARG(DATE)
            or ARG(WEEKDAY)
            or ARG(YEARDAY)
        ){
            Fold_Zone_Into_Date(out);
        }
    }

    REBINT n = -1;

    if (ARG(DATE)) {
        Tweak_Cell_Nanoseconds(out, NO_DATE_TIME);
        VAL_ZONE(out) = NO_DATE_ZONE;
    }
    else if (ARG(TIME)) {
        Tweak_Cell_Type_Matching_Heart(out, HEART_TIME);
    }
    else if (ARG(ZONE)) {
        Tweak_Cell_Nanoseconds(out, VAL_ZONE(out) * ZONE_MINS * MIN_SEC);
        Tweak_Cell_Type_Matching_Heart(out, HEART_TIME);
    }
    else if (ARG(WEEKDAY))
        n = Week_Day(out);
    else if (ARG(YEARDAY))
        n = Julian_Date(out);
    else if (ARG(YEAR))
        n = VAL_YEAR(out);
    else if (ARG(MONTH))
        n = VAL_MONTH(out);
    else if (ARG(DAY))
        n = VAL_DAY(out);

    if (n > 0)
        Init_Integer(out, n);

    return BOUNCE_OUT;
}
