//
//  file: %f-stubs.c
//  summary: "miscellaneous little functions"
//  section: functional
//  project: "Rebol 3 Interpreter and Run-time (Ren-C branch)"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012 REBOL Technologies
// Copyright 2012-2017 Ren-C Open Source Contributors
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information.
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//

#include "sys-core.h"


//
//  Get_Num_From_Arg: C
//
// Get the amount to skip or pick.
// Allow multiple types. Throw error if not valid.
// Note that the result is one-based.
//
REBINT Get_Num_From_Arg(const Stable* val)
{
    REBINT n;

    if (Is_Integer(val)) {
        if (VAL_INT64(val) > INT32_MAX or VAL_INT64(val) < INT32_MIN)
            panic (Error_Out_Of_Range(val));
        n = VAL_INT32(val);
    }
    else if (Is_Decimal(val) or Is_Percent(val)) {
        if (VAL_DECIMAL(val) > INT32_MAX or VAL_DECIMAL(val) < INT32_MIN)
            panic (Error_Out_Of_Range(val));
        n = cast(REBINT, VAL_DECIMAL(val));
    }
    else if (Is_Logic(val))
        n = (Cell_Logic(val) ? 1 : 2);
    else
        panic (Error_Bad_Value(val));

    return n;
}


//
//  Float_Int16: C
//
REBINT Float_Int16(REBD32 f)
{
    if (fabs(f) > raw_cast(REBD32, 0x7FFF)) {
        DECLARE_ELEMENT (temp);
        Init_Decimal(temp, f);

        panic (Error_Out_Of_Range(temp));
    }
    return raw_cast(REBINT, f);
}


//
//  Int32: C
//
REBINT Int32(const Stable* val)
{
    if (Is_Decimal(val)) {
        if (VAL_DECIMAL(val) > INT32_MAX or VAL_DECIMAL(val) < INT32_MIN)
            goto out_of_range;

        return cast(REBINT, VAL_DECIMAL(val));
    }

    assert(Is_Integer(val));

    if (VAL_INT64(val) > INT32_MAX or VAL_INT64(val) < INT32_MIN)
        goto out_of_range;

    return VAL_INT32(val);

out_of_range:
    panic (Error_Out_Of_Range(val));
}


//
//  Int32s: C
//
// Get integer as positive, negative 32 bit value.
// Sign field can be
//     0: >= 0
//     1: >  0
//    -1: <  0
//
REBINT Int32s(const Stable* val, REBINT sign)
{
    REBINT n;

    if (Is_Decimal(val)) {
        if (VAL_DECIMAL(val) > INT32_MAX or VAL_DECIMAL(val) < INT32_MIN)
            goto out_of_range;

        n = cast(REBINT, VAL_DECIMAL(val));
    }
    else {
        assert(Is_Integer(val));

        if (VAL_INT64(val) > INT32_MAX)
            goto out_of_range;

        n = VAL_INT32(val);
    }

    // More efficient to use positive sense:
    if (
        (sign == 0 and n >= 0)
        or (sign > 0 and n > 0)
        or (sign < 0 and n < 0)
    ){
        return n;
    }

out_of_range:
    panic (Error_Out_Of_Range(val));
}


//
//  Int64: C
//
REBI64 Int64(const Stable* val)
{
    if (Is_Integer(val))
        return VAL_INT64(val);
    if (Is_Decimal(val) or Is_Percent(val))
        return cast(REBI64, VAL_DECIMAL(val));

    panic (Error_Bad_Value(val));
}


//
//  Dec64: C
//
REBDEC Dec64(const Stable* val)
{
    if (Is_Decimal(val) or Is_Percent(val))
        return VAL_DECIMAL(val);
    if (Is_Integer(val))
        return cast(REBDEC, VAL_INT64(val));

    panic (Error_Bad_Value(val));
}


//
//  Int64s: C
//
// Get integer as positive, negative 64 bit value.
// Sign field can be
//     0: >= 0
//     1: >  0
//    -1: <  0
//
REBI64 Int64s(const Stable* val, REBINT sign)
{
    REBI64 n;
    if (Is_Decimal(val)) {
        if (VAL_DECIMAL(val) > INT64_MAX or VAL_DECIMAL(val) < INT64_MIN)
            panic (Error_Out_Of_Range(val));

        n = cast(REBI64, VAL_DECIMAL(val));
    }
    else
        n = VAL_INT64(val);

    // More efficient to use positive sense:
    if (
        (sign == 0 and n >= 0)
        or (sign > 0 and n > 0)
        or (sign < 0 and n < 0)
    ){
        return n;
    }

    panic (Error_Out_Of_Range(val));
}


//
//  Datatype_From_Type: C
//
// Returns the specified datatype Value from the LIB context.
// The datatypes are all at the head of the LIB context.
//
const Stable* Datatype_From_Type(Type type)
{
    assert(type <= MAX_TYPE_ANTIFORM);
    Patch* patch;
    if (Is_Quoted_Type(type))
        patch = &g_datatype_patches[  // !!! fix: wasted space
            Byte_From_Type(TYPE_QUOTED_1_TIME_NONQUASI)
        ];
    else if (Is_Logic_Type(type))
        patch = &g_datatype_patches[
            Byte_From_Type(TYPE_LOGIC_NULL)
        ];
    else
        patch = &g_datatype_patches[Byte_From_Type(type)];
    const Stable* datatype = cast(Stable*, Stub_Cell(patch));
    assert(Is_Datatype(datatype));
    return datatype;
}


//
//  Datatype_From_Heart: C
//
const Stable* Datatype_From_Heart(Heart heart)
{
    return Datatype_From_Type(unwrap Type_From_Heart(heart));
}


//
//  Datatype_Of_Possibly_Unstable: C
//
// Returns the datatype value for the given value.
// The datatypes are all at the head of the context.
//
const Stable* Datatype_Of_Possibly_Unstable(const Value* v)
{
    Option(Type) type = Type_Of_Possibly_Unstable(v);
    if (type)
        return Datatype_From_Type(unwrap type);

    const ExtraHeart* ext_heart = Cell_Extra_Heart(v);
    assert(Is_Stub_Patch(ext_heart));

    const Stable* datatype = cast(Stable*, Stub_Cell(ext_heart));
    assert(Is_Datatype(datatype));
    return datatype;
}


//
//  Datatype_Of_Fundamental: C
//
const Stable* Datatype_Of_Fundamental(const Element* value)
{
    assert(Any_Fundamental(value));
    return Datatype_Of(value);
}


//
//  Datatype_Of_Builtin_Fundamental: C
//
const Stable* Datatype_Of_Builtin_Fundamental(const Element* value)
{
    assert(Any_Fundamental(value));

    Option(Type) type = Type_Of(value);
    assert(type);
    return Datatype_From_Type(unwrap type);
}

//
//  Type_Of_Builtin_Fundamental: C
//
Type Type_Of_Builtin_Fundamental(const Element* value)
{
    assert(Any_Fundamental(value));

    Option(Type) type = Type_Of(value);
    assert(type);
    return unwrap type;
}


//
//  Get_System: C
//
// Return a second level object field of the system object.
//
Slot* Get_System(REBLEN i1, REBLEN i2)
{
    Slot* obj_slot = Varlist_Slot(Cell_Varlist(LIB(SYSTEM)), i1);
    if (i2 == 0)
        return obj_slot;

    DECLARE_STABLE (obj);
    require (
      Read_Slot(obj, obj_slot)
    );
    assert(Is_Object(obj));

    return Varlist_Slot(Cell_Varlist(obj), i2);
}


//
//  Get_System_Int: C
//
// Get an integer from system object.
//
REBINT Get_System_Int(REBLEN i1, REBLEN i2, REBINT default_int)
{
    Slot* slot = Get_System(i1, i2);

    if (Is_Integer(Stable_Slot_Hack(slot)))
        return VAL_INT32(Stable_Slot_Hack(slot));

    return default_int;
}


#if RUNTIME_CHECKS

//
//  Extra_Init_Context_Cell_Checks_Debug: C
//
// !!! Overlaps with Assert_Varlist, review folding them together.
//
void Extra_Init_Context_Cell_Checks_Debug(
    Heart heart,
    VarList* varlist
){
    assert(CTX_TYPE(varlist) == heart);

    if (heart == HEART_FRAME)  // may not have Misc_Varlist_Adjunct()
        assert(
            (varlist->header.bits & STUB_MASK_LEVEL_VARLIST)
            == STUB_MASK_LEVEL_VARLIST
        );
    else
        assert((varlist->header.bits & STUB_MASK_VARLIST) == STUB_MASK_VARLIST);

    const Stable* archetype = Varlist_Archetype(varlist);
    assert(Cell_Varlist(archetype) == varlist);

    // Currently only FRAME! uses the extra field, in order to capture the
    // ->coupling of the function value it links to (which is in ->phase)
    //
    assert(archetype->extra.base == nullptr or heart == HEART_FRAME);

    // KeyLists are uniformly managed, or certain routines would return
    // "sometimes managed, sometimes not" keylists...a bad invariant.
    //
    KeyList* keylist = Bonus_Keylist(varlist);
    Assert_Stub_Managed(keylist);

    assert(
        not Misc_Varlist_Adjunct(varlist)
        or Any_Context_Heart(CTX_TYPE(unwrap Misc_Varlist_Adjunct(varlist)))
    );
}


//
//  Extra_Init_Frame_Checks_Debug: C
//
void Extra_Init_Frame_Checks_Debug(Phase* phase) {
    assert(Is_Frame(Phase_Archetype(phase)));

    Details* details = opt Phase_Details(phase);
    if (details)
        assert(Is_Stub_Details(details));

    assert(Is_Stub_Varlist(Phase_Paramlist(phase)));

    KeyList* keylist = Phase_Keylist(phase);
    assert(
        (keylist->header.bits & STUB_MASK_KEYLIST)
        == STUB_MASK_KEYLIST
    );

    if (Get_Stub_Flag(phase, MISC_NEEDS_MARK)) {
        assert(
            Misc_Phase_Adjunct(phase) == nullptr
            or Any_Context_Heart(CTX_TYPE(unwrap Misc_Phase_Adjunct(phase)))
        );
    }
}

#endif


//
//  Part_Len_May_Modify_Index: C
//
// This is the common way of normalizing a series with a position against a
// :PART limit, so that the series index points to the beginning of the
// subsetted range and gives back a length to the end of that subset.
//
// It determines if the position for the part is before or after the series
// position.  If it is before (e.g. a negative integer limit was passed in,
// or a prior position) the series value will be updated to the earlier
// position, so that a positive length for the partial region is returned.
//
REBLEN Part_Len_May_Modify_Index(
    Stable* series,  // ANY-SERIES? value whose index may be modified
    Option(const Element*) part_arg  // :PART (number, position in value)
){
    assert(Is_Rune(series) or Any_Series(series));

    if (not part_arg) {  // indicates :PART refinement unused
        if (not Is_Rune(series))
            return Series_Len_At(series);  // use plain length

        Size size;
        Cell_Utf8_Size_At(&size, series);
        return size;
    }

    const Element* part = unwrap part_arg;

    // Series_Index() checks to make sure it's for in-bounds
    //
    REBLEN iseries = Is_Rune(series) ? 0 : Series_Index(series);

    REBI64 len;
    if (Is_Integer(part) or Is_Decimal(part))
        len = Int32(part);  // may be positive or negative
    else {  // must be same series
        if (
            Is_Rune(part)  // !!! v-- allow AS alias?
            or not Have_Same_Type(series, part)
            or Cell_Flex(series) != Cell_Flex(part)
        ){
            panic (Error_Invalid_Part_Raw(part));
        }

        len = Series_Index(part) - iseries;
    }

    // Restrict length to the size available
    //
    if (len >= 0) {
        REBINT maxlen = Series_Len_At(series);
        if (len > maxlen)
            len = maxlen;
    }
    else {
        if (Is_Rune(part))
            panic (Error_Invalid_Part_Raw(part));

        len = (- len);
        if (len > i_cast(REBI64, iseries))
            len = iseries;
        SERIES_INDEX_UNBOUNDED(series) -= len;
    }

    if (len > UINT32_MAX) {
        //
        // Tests had `[1] = copy:part tail of [1] -2147483648`, where trying
        // to do `len = -len` couldn't make a positive 32-bit version of that
        // negative value.  For now, use REBI64 to do the calculation.
        //
        panic ("Length out of range for :PART refinement");
    }

    assert(len >= 0);
    if (not Is_Rune(series))
        assert(Series_Len_Head(series) >= len);
    return len;
}


//
//  Part_Tail_May_Modify_Index: C
//
// Simple variation that instead of returning the length, returns the absolute
// tail position in the series of the partial sequence.
//
REBLEN Part_Tail_May_Modify_Index(Element* series, Option(const Element*) limit)
{
    REBLEN len = Part_Len_May_Modify_Index(series, limit);
    return len + Series_Index(series); // uses the possibly-updated index
}


//
//  Add_Max: C
//
int64_t Add_Max(Option(Heart) heart, int64_t n, int64_t m, int64_t maxi)
{
    int64_t r = n + m;
    if (r < -maxi or r > maxi) {
        if (heart)
            panic (Error_Type_Limit_Raw(Datatype_From_Heart(unwrap heart)));
        r = r > 0 ? maxi : -maxi;
    }
    return r;
}


//
//  Mul_Max: C
//
int64_t Mul_Max(Heart heart, int64_t n, int64_t m, int64_t maxi)
{
    int64_t r = n * m;
    if (r < -maxi or r > maxi)
        panic (Error_Type_Limit_Raw(Datatype_From_Heart(heart)));
    return i_cast(int, r); // !!! (?) review this cast
}


//
//  Unsingleheart_Sequence: C
//
// Evolve a cell containing a sequence that's just an element and a BLANK!
// into the element alone, e.g. `a:` -> `a` or `:[a b]` -> `[a b]`
//
Result(Element*) Unsingleheart_Sequence(Element* seq)
{
    assert(Has_Sequence_Heart(seq));
    assert(not Sigil_Of(seq));
    assert(Type_Of_Raw(seq) <= MAX_TYPE_NOQUOTE_NOQUASI);

    if (not Sequence_Has_Pointer(seq))
        goto report_error;  // compressed bytes don't encode blanks

  extract_payload_1: {

    const Base* payload1 = CELL_PAYLOAD_1(seq);

  test_for_pairing_sequence: {

    if (Is_Base_A_Cell(payload1)) {  // compressed 2-elements, sizeof(Stub)
        const Pairing* pairing = cast(Pairing*, payload1);
        if (Is_Blank(Pairing_First(pairing))) {
            assert(not Is_Blank(Pairing_Second(pairing)));
            Copy_Cell_May_Bind(seq, Pairing_Second(pairing), Cell_Binding(seq));
            return seq;
        }
        if (Is_Blank(Pairing_Second(pairing))) {
            Copy_Cell_May_Bind(seq, Pairing_First(pairing), Cell_Binding(seq));
            return seq;
        }
        goto report_error;
    }

} test_for_flex_sequence: {

    const Flex* f = cast(Flex*, payload1);
    if (Is_Stub_Symbol(f)) {
        Tweak_Cell_Type_Matching_Heart(seq, HEART_WORD);
        Clear_Cell_Flag(seq, LEADING_BLANK);  // !!! necessary?
        return seq;
    }

    Option(Heart) mirror = Mirror_Of(cast(Source*, f));
    if (mirror) {  // no length 2 sequence arrays unless mirror
        Tweak_Cell_Type_Matching_Heart(seq, unwrap mirror);
        Clear_Cell_Flag(seq, LEADING_BLANK);  // !!! necessary
        return seq;
    }

}} report_error: { ///////////////////////////////////////////////////////////

    return fail (
        "UNCHAIN/UNPATH/UNTUPLE only on length 2 chains (when 1 item is BLANK)"
    );
}}


//
//  Unsingleheart_Sequence_Preserve_Sigil: C
//
Result(Element*) Unsingleheart_Sequence_Preserve_Sigil(Element* seq) {
    Option(Sigil) sigil = Sigil_Of(seq);
    Clear_Cell_Sigil(seq);
    trap (
      Unsingleheart_Sequence(seq)
    );
    if (sigil)
        Add_Cell_Sigil(seq, unwrap sigil);
    return seq;
}


//
//  /setify: native [
//
//  "If possible, convert a value to a SET-XXX! representation"
//
//      return: [element?: failure!]
//      value [element?]
//  ]
//
DECLARE_NATIVE(SETIFY)
//
// !!! This function is needed somewhat often and isn't covered by DECORATE.
// It may be possible to do with something like (join value ':)
{
    INCLUDE_PARAMS_OF_SETIFY;

    trap (
      Element* e = Setify(ARG(VALUE))
    );

    return COPY_TO_OUT(e);
}


//
//  /getify: native [
//
//  "If possible, convert a value to a GET-XXX! representation"
//
//      return: [:element? failure!]
//      value [element?]
//  ]
//
DECLARE_NATIVE(GETIFY)
//
// !!! REVIEW: Redundant with (DECORATE ':) ...
{
    INCLUDE_PARAMS_OF_GETIFY;

    trap (
      Element* e = Getify(ARG(VALUE))
    );

    return COPY_TO_OUT(e);
}


// Right now if we used SPECIALIZE of a SIGILIZE native, it would not be able
// to take advantage of the intrinsic optimization...since the sigil would
// have to live in a frame cell.  So the natives are made by hand here.
//
static Bounce Sigilize_Native_Core(Level* level_, Sigil sigil)
{
    INCLUDE_PARAMS_OF_META;  // META, PIN, TIE all same signature.

    require (
      Element* v = opt Typecheck_Element_Intrinsic_Arg(LEVEL)
    );
    if (not v)
        return NULL_OUT;

    attempt {
        if (Any_Plain(v))
            continue;

        if (LEVEL->executor != &Intrinsic_Executor) {
            if (ARG(FORCE)) {
                Clear_Cell_Sigil(v);
                continue;
            }
        }

        return fail (
            "Trying to add Sigil to already metaform/tied/pinned value"
        );
    }
    then {
        if (not Any_Sigilable(v))
            return fail (Error_Bad_Sigil_Raw(v));
    }

    return COPY_TO_OUT(Add_Cell_Sigil(v, sigil));
}


//
//  /meta: native:intrinsic [
//
//  "Convert a value to its ^XXX metaform representation"
//
//      return: [failure! ^plain?]
//      value '[fundamental?]
//      :force "Meta without erroring, even if already metaform/tied/pinned"
//  ]
//
DECLARE_NATIVE(META)
{
    return Sigilize_Native_Core(LEVEL, SIGIL_META);
}


//
//  /pin: native:intrinsic [
//
//  "Convert a value to its @XXX pinned representation"
//
//      return: [failure! @plain?]
//      value '[fundamental?]
//      :force "Pin without erroring, even if already metaform/tied/pinned"
//  ]
//
DECLARE_NATIVE(PIN)
{
    return Sigilize_Native_Core(LEVEL, SIGIL_PIN);
}


//
//  /tie: native:intrinsic [
//
//  "Convert a value to its $XXX tied representation"
//
//      return: [failure! $plain?]
//      value '[fundamental?]
//      :force "Tie without erroring, even if already metaform/tied/pinned"
//  ]
//
DECLARE_NATIVE(TIE)
{
    return Sigilize_Native_Core(LEVEL, SIGIL_TIE);
}


// Right now if we used SPECIALIZE of a UNSIGILIZE native, it would not be able
// to take advantage of the intrinsic optimization...since the sigil would
// have to live in a frame cell.  So the natives are made by hand here.
//
static Bounce Unsigilize_Native_Core(Level* level_, Sigil sigil)
{
    INCLUDE_PARAMS_OF_UNMETA;  // same signature as UNPIN, UNTIE

    require (
      Element* v = opt Typecheck_Element_Intrinsic_Arg(LEVEL)
    );
    if (not v)
        panic (nullptr);  // !!! this should only happen in typecheckers

    if (Sigil_Of(v) != sigil)
        return fail ("Trying to remove Sigil from value without that Sigil");

    return COPY_TO_OUT(Clear_Cell_Sigil(v));
}


//
//  /unmeta: native:intrinsic [
//
//  "Convert ^XXX to plain XXX, error if not metaform"
//
//      return: [plain? failure!]
//      value '[fundamental?]
//  ]
//
DECLARE_NATIVE(UNMETA)
{
    return Unsigilize_Native_Core(LEVEL, SIGIL_META);
}


//
//  /unpin: native:intrinsic [
//
//  "Convert @XXX to plain XXX, error if not pinned"
//
//      return: [plain? failure!]
//      value '[fundamental?]
//  ]
//
DECLARE_NATIVE(UNPIN)
{
    return Unsigilize_Native_Core(LEVEL, SIGIL_PIN);
}


//
//  /untie: native:intrinsic [
//
//  "Convert $XXX to plain XXX, error if not tied"
//
//      return: [plain? failure!]
//      value '[fundamental?]
//  ]
//
DECLARE_NATIVE(UNTIE)
{
    return Unsigilize_Native_Core(LEVEL, SIGIL_TIE);
}


//
//  /plain: native:intrinsic [
//
//  "Convert a value into its plain representation"
//
//      return: [plain?]
//      value '[element?]
//  ]
//
DECLARE_NATIVE(PLAIN)
{
    INCLUDE_PARAMS_OF_PLAIN;

    require (
      Element* v = opt Typecheck_Element_Intrinsic_Arg(LEVEL)
    );
    if (not v)
        panic (nullptr);  // !!! this should only happen in typecheckers

    return COPY_TO_OUT(Clear_Cell_Sigil(v));
}


//
//  /unchain: native [
//
//  "Remove CHAIN!, e.g. leading colon or trailing colon from an element"
//
//      return: [element? failure!]
//      chain [chain!]
//  ]
//
DECLARE_NATIVE(UNCHAIN)
{
    INCLUDE_PARAMS_OF_UNCHAIN;

    Element* elem = Element_ARG(CHAIN);
    trap (
      Unsingleheart_Sequence(elem)
    );
    return COPY_TO_OUT(elem);
}


//
//  /unpath: native [
//
//  "Remove PATH!, e.g. leading slash or trailing slash from an element"
//
//      return: [element? failure!]
//      path [path!]
//  ]
//
DECLARE_NATIVE(UNPATH)
{
    INCLUDE_PARAMS_OF_UNPATH;

    Element* elem = Element_ARG(PATH);
    trap (
      Unsingleheart_Sequence(elem)
    );
    return COPY_TO_OUT(elem);
}


//
//  /untuple: native [
//
//  "Remove TUPLE!, e.g. leading dot or trailing dot from a tuple"
//
//      return: [element? failure!]
//      tuple [tuple!]
//  ]
//
DECLARE_NATIVE(UNTUPLE)
{
    INCLUDE_PARAMS_OF_UNTUPLE;

    Element* elem = Element_ARG(TUPLE);
    trap (
      Unsingleheart_Sequence(elem)
    );
    return COPY_TO_OUT(elem);
}
