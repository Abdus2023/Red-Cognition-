//
//  file: %f-series.c
//  summary: "common series handling functions"
//  section: functional
//  project: "Rebol 3 Interpreter and Run-time (Ren-C branch)"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012 REBOL Technologies
// Copyright 2012-2017 Ren-C Open Source Contributors
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information.
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//

#include "sys-core.h"

#define THE_SIGN(v) ((v < 0) ? -1 : (v > 0) ? 1 : 0)


// Common code for series that just tweaks the index (doesn't matter if it's
// a TEXT!, BLOCK!, BLOB!, etc.)
//
IMPLEMENT_GENERIC(SKIP, Any_Series)
{
    INCLUDE_PARAMS_OF_SKIP;

    Element* v = Element_ARG(SERIES);
    assert(Any_Series(v));

    // `skip series 1` means second element, add offset as-is
    REBINT offset = Get_Num_From_Arg(ARG(OFFSET));
    REBI64 i = (
        i_cast(REBI64, SERIES_INDEX_UNBOUNDED(v)) + i_cast(REBI64, offset)
    );

    if (not ARG(UNBOUNDED)) {
        if (i < 0 or i > i_cast(REBI64, Series_Len_Head(v)))
            return fail (Error_Index_Out_Of_Range_Raw());
    }

    SERIES_INDEX_UNBOUNDED(v) = i;
    return COPY_TO_OUT(Trust_Const(v));
}


// Common code for series that just tweaks the index (doesn't matter if it's
// a TEXT!, BLOCK!, BLOB!, etc.)
//
// `at series 1` is first element, e.g. [0] in C.  Adjust offset.
//
// Note: Rebol2 and Red treat AT 1 and AT 0 as being the same:
//
//     rebol2>> at next next "abcd" 1
//     == "cd"
//
//     rebol2>> at next next "abcd" 0
//     == "cd"
//
// That doesn't make a lot of sense...but since `series/0` will always
// return NULL and `series/-1` returns the previous element, it hints
// at special treatment for index 0 (which is C-index -1).
//
// !!! Currently left as an open question.
//
IMPLEMENT_GENERIC(AT, Any_Series)
{
    INCLUDE_PARAMS_OF_AT;

    Element* v = Element_ARG(SERIES);
    assert(Any_Series(v));

    REBINT offset = Get_Num_From_Arg(ARG(INDEX));

    REBI64 i = i_cast(REBI64, SERIES_INDEX_UNBOUNDED(v));

    if (offset > 0)
        i += i_cast(REBI64, offset) - 1;
    else
        i += i_cast(REBI64, offset);

    if (ARG(BOUNDED)) {
        if (i < 0 or i > i_cast(REBI64, Series_Len_Head(v)))
            return NULL_OUT;
    }

    SERIES_INDEX_UNBOUNDED(v) = i;
    return COPY_TO_OUT(Trust_Const(v));
}


IMPLEMENT_GENERIC(REMOVE, Any_Series)
{
    INCLUDE_PARAMS_OF_REMOVE;

    Element* v = Element_ARG(SERIES);

    Ensure_Mutable(v);  // !!! Review making this extract

    REBINT len;
    if (ARG(PART))
        len = Part_Len_May_Modify_Index(v, Element_ARG(PART));
    else
        len = 1;

    Index index = SERIES_INDEX_UNBOUNDED(v);
    if (index < Series_Len_Head(v) and len != 0)
        Remove_Any_Series_Len(v, index, len);

    return COPY_TO_OUT(v);
}


IMPLEMENT_GENERIC(LENGTH_OF, Any_Series)
{
    INCLUDE_PARAMS_OF_LENGTH_OF;

    Element* ser = Element_ARG(VALUE);
    Init_Integer(OUT, Series_Len_At(ser));
    return BOUNCE_OUT;
}


IMPLEMENT_GENERIC(INDEX_OF, Any_Series)  // 1-based
{
    INCLUDE_PARAMS_OF_INDEX_OF;

    Element* ser = Element_ARG(VALUE);
    Init_Integer(OUT, SERIES_INDEX_UNBOUNDED(ser) + 1);
    return BOUNCE_OUT;
}


IMPLEMENT_GENERIC(OFFSET_OF, Any_Series)  // 0-based
{
    INCLUDE_PARAMS_OF_OFFSET_OF;

    Element* ser = Element_ARG(VALUE);
    Init_Integer(OUT, SERIES_INDEX_UNBOUNDED(ser));
    return BOUNCE_OUT;
}


//
//  /head-of: native:generic [
//
//  "Get the head of a series (or other type...? HEAD of a PORT?)"
//
//      return: [<null> fundamental?]
//      value [fundamental?]
//  ]
//
DECLARE_NATIVE(HEAD_OF)
{
    INCLUDE_PARAMS_OF_HEAD_OF;

    return Dispatch_Generic(HEAD_OF, Element_ARG(VALUE), LEVEL);
}


//
//  /tail-of: native:generic [
//
//  "Get the tail of a series (or other type...? TAIL of a PORT?)"
//
//      return: [<null> fundamental?]
//      value [fundamental?]
//  ]
//
DECLARE_NATIVE(TAIL_OF)
{
    INCLUDE_PARAMS_OF_TAIL_OF;

    return Dispatch_Generic(TAIL_OF, Element_ARG(VALUE), LEVEL);
}


//
//  /head?: native:generic [
//
//  "Test if something is at the head position"
//
//      return: [logic!]
//      value [fundamental?]
//  ]
//
DECLARE_NATIVE(HEAD_Q)
{
    INCLUDE_PARAMS_OF_HEAD_Q;

    Element* elem = Element_ARG(VALUE);
    Clear_Cell_Sigil(elem);  // (head? @[a b c]) -> ~okay~

    return Dispatch_Generic(HEAD_Q, elem, LEVEL);
}


//
//  /tail?: native:generic [
//
//  "Test if something is at the tail position"
//
//      return: [logic!]
//      value [fundamental?]
//  ]
//
DECLARE_NATIVE(TAIL_Q)
{
    INCLUDE_PARAMS_OF_TAIL_Q;

    Element* elem = Element_ARG(VALUE);
    Clear_Cell_Sigil(elem);  // (tail? @[]) -> ~okay~

    return Dispatch_Generic(TAIL_Q, elem, LEVEL);
}


//
//  /past?: native:generic [
//
//  "Test if something is past the tail position"
//
//      return: [logic!]
//      value [fundamental?]
//  ]
//
DECLARE_NATIVE(PAST_Q)
{
    INCLUDE_PARAMS_OF_PAST_Q;

    Element* elem = Element_ARG(VALUE);
    Clear_Cell_Sigil(elem);  // (past? next of @[]) -> ~okay~

    return Dispatch_Generic(PAST_Q, elem, LEVEL);
}


IMPLEMENT_GENERIC(HEAD_OF, Any_Series)
{
    INCLUDE_PARAMS_OF_HEAD_OF;

    Element* ser = Element_ARG(VALUE);

    Copy_Cell(OUT, ser);
    SERIES_INDEX_UNBOUNDED(OUT) = 0;
    USED(Trust_Const(OUT));
    return BOUNCE_OUT;
}


IMPLEMENT_GENERIC(TAIL_OF, Any_Series)
{
    INCLUDE_PARAMS_OF_TAIL_OF;

    Element* ser = Element_ARG(VALUE);

    Copy_Cell(OUT, ser);
    SERIES_INDEX_UNBOUNDED(OUT) = Series_Len_Head(ser);
    USED(Trust_Const(OUT));
    return BOUNCE_OUT;
}


IMPLEMENT_GENERIC(HEAD_Q, Any_Series)
{
    INCLUDE_PARAMS_OF_HEAD_Q;

    Element* ser = Element_ARG(VALUE);

    return LOGIC_OUT(SERIES_INDEX_UNBOUNDED(ser) == 0);
}


IMPLEMENT_GENERIC(TAIL_Q, Any_Series)
{
    INCLUDE_PARAMS_OF_TAIL_Q;

    Element* ser = Element_ARG(VALUE);

    return LOGIC_OUT(
        SERIES_INDEX_UNBOUNDED(ser) == Series_Len_Head(ser)
    );
}


IMPLEMENT_GENERIC(PAST_Q, Any_Series)
{
    INCLUDE_PARAMS_OF_PAST_Q;

    Element* ser = Element_ARG(VALUE);

    return LOGIC_OUT(
        SERIES_INDEX_UNBOUNDED(ser) > Series_Len_Head(ser)
    );
}


IMPLEMENT_GENERIC(UNIQUE, Any_Series)  // single-arity set operation
{
    INCLUDE_PARAMS_OF_UNIQUE;

    Heart heart = Heart_Of_Builtin_Fundamental(Element_ARG(SERIES));

    Flex* flex = Make_Set_Operation_Flex(
        ARG(SERIES),
        nullptr,  // no ARG(VALUE2)
        SOP_NONE,
        ARG(CASE),
        ARG(SKIP) ? Int32s(unwrap ARG(SKIP), 1) : 1
    );

    Init_Series(OUT, heart, flex);
    return BOUNCE_OUT;
}


// The policy for what to do with (intersect '[a b c] '{b c d}) isn't set in
// stone yet.  R3-Alpha and Red prohibit anything but BLOCK!, while Ren-C
// has historically made the result the same type as the first argument.
//
Option(Error*) Trap_Resolve_Dual_Hearts(
    Sink(Heart) heart,
    Element* value1,
    Element* value2
){
    UNUSED(value2);
    *heart = Heart_Of_Builtin_Fundamental(value1);
    return SUCCESS;
}


IMPLEMENT_GENERIC(INTERSECT, Any_Series)
{
    INCLUDE_PARAMS_OF_INTERSECT;

    Heart heart;
    Option(Error*) e = Trap_Resolve_Dual_Hearts(
        &heart, Element_ARG(VALUE1), Element_ARG(VALUE2)
    );
    if (e)
        panic (unwrap e);

    Flex* flex = Make_Set_Operation_Flex(
        ARG(VALUE1),
        ARG(VALUE2),
        SOP_FLAG_CHECK,
        ARG(CASE),
        ARG(SKIP) ? Int32s(unwrap ARG(SKIP), 1) : 1
    );

    Init_Series(OUT, heart, flex);
    return BOUNCE_OUT;
}


IMPLEMENT_GENERIC(UNION, Any_Series)
{
    INCLUDE_PARAMS_OF_UNION;

    Heart heart;
    Option(Error*) e = Trap_Resolve_Dual_Hearts(
        &heart, Element_ARG(VALUE1), Element_ARG(VALUE2)
    );
    if (e)
        panic (unwrap e);

    Flex* flex = Make_Set_Operation_Flex(
        ARG(VALUE1),
        ARG(VALUE2),
        SOP_FLAG_BOTH,
        ARG(CASE),
        ARG(SKIP) ? Int32s(unwrap ARG(SKIP), 1) : 1
    );

    Init_Series(OUT, heart, flex);
    return BOUNCE_OUT;
}


IMPLEMENT_GENERIC(DIFFERENCE, Any_Series)
{
    INCLUDE_PARAMS_OF_DIFFERENCE;

    Heart heart;
    Option(Error*) e = Trap_Resolve_Dual_Hearts(
        &heart, Element_ARG(VALUE1), Element_ARG(VALUE2)
    );
    if (e)
        panic (unwrap e);

    Flex* flex = Make_Set_Operation_Flex(
        ARG(VALUE1),
        ARG(VALUE2),
        SOP_FLAG_BOTH | SOP_FLAG_CHECK | SOP_FLAG_INVERT,
        ARG(CASE),
        ARG(SKIP) ? Int32s(unwrap ARG(SKIP), 1) : 1
    );

    Init_Series(OUT, heart, flex);
    return BOUNCE_OUT;
}


IMPLEMENT_GENERIC(EXCLUDE, Any_Series)
{
    INCLUDE_PARAMS_OF_EXCLUDE;

    Heart heart;
    Option(Error*) e = Trap_Resolve_Dual_Hearts(
        &heart, Element_ARG(DATA), Element_ARG(EXCLUSIONS)
    );
    if (e)
        panic (unwrap e);

    Flex* flex = Make_Set_Operation_Flex(
        ARG(DATA),
        ARG(EXCLUSIONS),
        SOP_FLAG_CHECK | SOP_FLAG_INVERT,
        ARG(CASE),
        ARG(SKIP) ? Int32s(unwrap ARG(SKIP), 1) : 1
    );

    Init_Series(OUT, heart, flex);
    return BOUNCE_OUT;
}


//
//  Equal_Values: C
//
// Test to see if two values are equal.  Quoting level is heeded, and values
// at distinct quoting levels are not considered equal.
//
Result(bool) Equal_Values(const Stable* s, const Stable* t, bool strict)
{
    if (LIFT_BYTE(s) != LIFT_BYTE(t))
        return false;

    Option(Heart) s_heart = Heart_Of(s);
    Option(Heart) t_heart = Heart_Of(t);

    if (not s_heart and not t_heart)
        return fail ("Custom type Equal_Values not implemented yet");

    if (not s_heart or not t_heart)
        return false;  // one is a custom type, the other is not, so not equal

    if (
        unwrap s_heart != unwrap t_heart
        and not (Any_Number_Heart(s_heart) and Any_Number_Heart(t_heart))
    ){
        return false;
    }

    // !!! Apply accelerations here that don't need a frame?  :-/  I dislike
    // the idea of duplicating the work, but it is undoubtedly a bit more
    // costly to make and dispatch the frame, even if done elegantly.

    require (
      Level* const L = Make_End_Level(
        &Action_Executor,
        FLAG_STATE_BYTE(ST_ACTION_TYPECHECKING)
    ));
    Push_Level(L);

    require (
      Push_Action(L, LIB(EQUAL_Q), PREFIX_0)
    );

    USE_LEVEL_SHORTHANDS (L);
    INCLUDE_PARAMS_OF_EQUAL_Q;

    bool relax = not strict;

    Copy_Lifted_Cell(Erase_ARG(VALUE1), s);
    Copy_Lifted_Cell(Erase_ARG(VALUE2), t);
    Init_Logic(Erase_ARG(RELAX), relax);

    bool threw = Trampoline_With_Top_As_Root_Throws();
    if (threw)
        return fail (Error_No_Catch_For_Throw(TOP_LEVEL));

    bool logic;

    if (Is_Failure(Level_Out(L)))
        logic = false;
    else {
        require (
          Stable* out = Decay_If_Unstable(Level_Out(L))
        );

        logic = Cell_Logic(out);
    }

    Drop_Level(L);
    return logic;
}


//
//  Lesser_Value: C
//
// This dispatches to the LESSER? implementation.  It may not be able to
// compare the types, e.g. ("A" < 1) is an error, so you get a bool.
//
bool Try_Lesser_Value(Sink(bool) lesser, const Stable* s, const Stable* t)
{
    if (Type_Of_Raw(s) >= MIN_TYPE_ANTIFORM)
        return false;  // can't do less than on antiforms

    if (LIFT_BYTE(s) != LIFT_BYTE(t))
        return false;  // comparisons against different-quoting levels illegal

    Option(Heart) s_heart = Heart_Of(s);
    Option(Heart) t_heart = Heart_Of(t);

    if (not s_heart and not t_heart)
        panic ("Custom type Try_Lesser_Value not implemented yet");

    if (not s_heart or not t_heart)
        return false;  // one is a custom type, the other is not, so not equal

    if (
        unwrap s_heart != unwrap t_heart
        and not (Any_Number_Heart(s_heart) and Any_Number_Heart(t_heart))
    ){
        return false;
    }

    // !!! Apply accelerations here that don't need a frame?  :-/  I dislike
    // the idea of duplicating the work, but it is undoubtedly a bit more
    // costly to make and dispatch the frame, even if done elegantly.

    require (
      Level* const L = Make_End_Level(
        &Action_Executor,
        FLAG_STATE_BYTE(ST_ACTION_TYPECHECKING)
    ));
    Push_Level(L);
    require (
      Push_Action(L, LIB(LESSER_Q), PREFIX_0)
    );

    USE_LEVEL_SHORTHANDS (L);
    INCLUDE_PARAMS_OF_LESSER_Q;

    Copy_Cell(Erase_ARG(VALUE1), s);
    Copy_Cell(Erase_ARG(VALUE2), t);

    bool threw = Trampoline_With_Top_As_Root_Throws();
    if (threw)
        panic (Error_No_Catch_For_Throw(TOP_LEVEL));

    bool comparable;

    if (Is_Failure(Level_Out(L))) {
        comparable = false;
    } else {
        require (
          Stable* out = Decay_If_Unstable(Level_Out(L))
        );
        *lesser = Cell_Logic(out);
        comparable = true;
    }

    Drop_Level(L);
    return comparable;
}


//
//  Find_In_Array_Simple: C
//
// Simple search for a value in an array. Return the index of
// the value or the TAIL index if not found.
//
REBLEN Find_In_Array_Simple(
    const Array* array,
    Index index,
    const Element* target
){
    const Element* value = Array_Head(array);

    bool strict = false;
    for (; index < Array_Len(array); index++) {
        require (
          bool equal = Equal_Values(value + index, target, strict)
        );
        if (equal)
            return index;
    }

    return Array_Len(array);
}
