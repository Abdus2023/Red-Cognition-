//
//  file: %t-varargs.h
//  summary: "Variadic Argument Type and Services"
//  project: "Rebol 3 Interpreter and Run-time (Ren-C branch)"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2016-2017 Ren-C Open Source Contributors
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//
// The VARARGS! data type implements an abstraction layer over an eval level
// or arbitrary array of values.  All copied instances of a TYPE_VARARGS value
// remain in sync as values are TAKE-d out of them.  Once they report
// reaching a TAIL? they will always report TAIL?...until the call that
// spawned them is off the stack, at which point they will report an error.
//

#include "sys-core.h"


INLINE void Init_For_Vararg_End(Value* out, enum Reb_Vararg_Op op) {
    if (op == VARARG_OP_TAIL_Q)
        Init_Logic(out, true);
    else
        Init_Void(out);
}


// Some VARARGS! are generated from a block with no level, while others
// have a level.  It would be inefficient to force the creation of a level on
// each call for a BLOCK!-based varargs.  So rather than doing so, there's a
// prelude which sees if it can answer the current query just from looking one
// unit ahead.
//
INLINE bool Vararg_Op_If_No_Advance_Handled(
    Value* out,
    enum Reb_Vararg_Op op,
    Option(const Element*) opt_look, // the first value in the varargs input
    Context* binding,
    Option(const Param*) param
){
    if (not opt_look) {
        Init_For_Vararg_End(out, op); // exhausted
        return true;
    }

    const Element* look = unwrap opt_look;

    ParamClass pclass =
        param ? Parameter_Class(unwrap param) : PARAMCLASS_NORMAL;

    if (pclass == PARAMCLASS_NORMAL and Is_Blank(look)) {  // ","
        Init_For_Vararg_End(out, op);
        return true;
    }

    if (pclass == PARAMCLASS_NORMAL and Is_Word(look)) {
        //
        // When a variadic argument is being TAKE-n, deferred left hand side
        // argument needs to be seen as end of variadic input.  Otherwise,
        // `summation 1 2 3 |> 100` acts as `summation 1 2 (3 |> 100)`.
        // Deferred operators need to act somewhat as an expression barrier.
        //
        // Same rule applies for "tight" arguments, `sum 1 2 3 + 4` with
        // sum being variadic and tight needs to act as `(sum 1 2 3) + 4`
        //
        // Look ahead, and if actively bound see if it's to an infix function
        // and the rules apply.

        Meta_Get_Var(out, NO_STEPS, look, binding) except (Error* e) {
            // !!! this code tolerated with `not e`, review right answer
            UNUSED(e);
        }
        else if (Is_Action(out)) {
            Option(InfixMode) infix_mode = Frame_Infix_Mode(out);
            if (infix_mode) {
                if (
                    pclass == PARAMCLASS_NORMAL or
                    infix_mode == INFIX_DEFER
                ){
                    Init_For_Vararg_End(out, op);
                    return true;
                }
            }
        }

        Corrupt_Cell_If_Needful(out);
    }

    // The odd circumstances which make things simulate END--as well as an
    // actual END--are all taken care of, so we're not "at the TAIL?"
    //
    if (op == VARARG_OP_TAIL_Q) {
        Init_Logic(out, false);
        return true;
    }

    if (op == VARARG_OP_FIRST) {
        if (pclass != PARAMCLASS_LITERAL)
            panic (Error_Varargs_No_Look_Raw()); // hard quote only

        Copy_Cell_May_Bind(out, look, binding);
        if (param and Get_Parameter_Flag(unwrap param, UNBIND_ARG))
            Unbind_Cell_If_Bindable_Core(out);

        return true; // only a lookahead, no need to advance
    }

    return false; // must advance, may need to create a level to do so
}


//
//  Do_Vararg_Op_Maybe_End_Throws_Core: C
//
// Service routine for working with a VARARGS!.  Supports TAKE-ing or just
// returning whether it's at the end or not.  The TAKE is not actually a
// destructive operation on underlying data--merely a semantic chosen to
// convey feeding forward with no way to go back.
//
// Whether the parameter is quoted or evaluated is determined by the typeset
// information of the `param`.  The typeset in the param is also used to
// check the result, and if an error is delivered it will use the name of
// the parameter symbol in the panic() message.
//
// If op is VARARG_OP_TAIL_Q, then it will return OKAY or NULL and in this
// case cannot return a thrown value.
//
// For other ops, it will return END_NODE if at the end of variadic input,
// or OUT if there is a value.
//
// If an evaluation is involved, then a thrown value is possibly returned.
//
bool Do_Vararg_Op_Maybe_End_Throws(
    Sink(Value) out,
    enum Reb_Vararg_Op op,
    const Cell* vararg
){
    const Key* key;
    Option(const Param*) param =
        Param_For_Varargs_If_There_Is_One(&key, vararg);

    ParamClass pclass =
        param ? Parameter_Class(unwrap param) : PARAMCLASS_NORMAL;

    Option(Level*) vararg_level;

    Level* L;
    Element* shared;
    if (Is_Block_Style_Varargs(&shared, vararg)) {
        //
        // We are processing an ANY-LIST?-based varargs, which came from
        // either a MAKE VARARGS! on an ANY-LIST? value -or- from a
        // MAKE ANY-LIST? on a varargs (which reified the varargs into an
        // list during that creation, flattening its entire output).

        vararg_level = nullptr;

        if (Vararg_Op_If_No_Advance_Handled(
            out,
            op,
            Is_Cell_Poisoned(shared) ? nullptr : List_Item_At(shared),
            Is_Cell_Poisoned(shared) ? SPECIFIED : List_Binding(shared),
            param
        )){
            goto type_check_and_return;
        }

        // Note this may be Is_Varargs_Infix(), where the left hand side was
        // synthesized into an array-style varargs with either 0 or 1 item to
        // be taken.
        //
        // !!! Note also that if the argument is evaluative, it will be
        // evaluated when the TAKE occurs...which may be never, if no TAKE of
        // this argument happens.  Review if that should be an error.

        switch (pclass) {
        case PARAMCLASS_META:
            panic ("Variadic literal parameters not yet implemented");

        case PARAMCLASS_NORMAL: {
            require (
              Level* L_temp = Make_Level_At(
                &Stepper_Executor,
                shared,
                EVAL_EXECUTOR_FLAG_FULFILLING_ARG
            ));
            Push_Level(L_temp);

            // Note: a sublevel is not needed here because this is a single use
            // level, whose state can be overwritten.
            //
            if (Eval_Step_Throws(out, L_temp)) {
                Drop_Level(L_temp);
                return true;
            }

            if (Is_Level_At_End(L_temp)) {
                Poison_Cell(shared);
            }
            else {
                require (
                  Unlift_Cell_No_Decay(out)
                );

                // The indexor is "prefetched", so though the temp level would
                // be ready to use again we're throwing it away, and need to
                // effectively "undo the prefetch" by taking it down by 1.
                //
                assert(Level_Array_Index(L_temp) > 0);
                SERIES_INDEX_UNBOUNDED(shared) = Level_Array_Index(L_temp) - 1;
            }

            Drop_Level(L_temp);
            break; }

        case PARAMCLASS_LITERAL:
            Copy_Cell_May_Bind(
                out,
                List_Item_At(shared),
                List_Binding(shared)
            );
            SERIES_INDEX_UNBOUNDED(shared) += 1;
            break;


        case PARAMCLASS_SOFT:
            if (Is_Soft_Escapable_Group(List_Item_At(shared))) {
                if (Eval_Any_List_At_Throws(
                    out, List_Item_At(shared), List_Binding(shared)
                )){
                    return true;
                }
            }
            else { // not a soft-"exception" case, quote ordinarily
                Copy_Cell_May_Bind(
                    out,
                    List_Item_At(shared),
                    List_Binding(shared)
                );
            }
            SERIES_INDEX_UNBOUNDED(shared) += 1;
            break;

        default:
            panic ("Invalid variadic parameter class");
        }

        if (
            not Is_Cell_Poisoned(shared)
            and Series_Index(shared) >= Series_Len_Head(shared)
        ){
            Poison_Cell(shared);  // signal end to all varargs sharing value
        }
    }
    else if (Is_Level_Style_Varargs_May_Panic(&L, vararg)) {
        //
        // "Ordinary" case... use the original level implied by the VARARGS!
        // (so long as it is still live on the stack)

        // The infixed case always synthesizes an array to hold the evaluated
        // left hand side value.  (See notes on Is_Varargs_Infix().)
        //
        assert(not Is_Varargs_Infix(vararg));

        vararg_level = L;

        Option(const Element*) look = nullptr;
        if (not Is_Level_At_End(L))
            look = At_Level(L);

        if (Vararg_Op_If_No_Advance_Handled(
            out,
            op,
            look,
            Level_Binding(L),
            param
        )){
            goto type_check_and_return;
        }

        // Note that evaluative cases here need a sublevel, because a function
        // is running in L and its state can't be overwritten by an arbitrary
        // evaluation.
        //
        switch (pclass) {
          case PARAMCLASS_NORMAL:
          case PARAMCLASS_META: {
            Flags flags = EVAL_EXECUTOR_FLAG_FULFILLING_ARG;

            require (
              Level* sub = Make_Level(&Stepper_Executor, L->feed, flags)
            );
            Push_Level(sub);
            bool threw = Trampoline_With_Top_As_Root_Throws();
            if (not threw)
                Copy_Cell(out, Level_Out(sub));

            Drop_Level(sub);
            if (threw)  // !!! Stackful, should yield!
                return true;

            if (pclass != PARAMCLASS_META) {
                require (
                  Decay_If_Unstable(out)
                );
            }
            break; }

          case PARAMCLASS_LITERAL:
            The_Next_In_Feed(out, L->feed);
            break;

          case PARAMCLASS_SOFT:
            if (Is_Soft_Escapable_Group(At_Level(L))) {
                if (Eval_Any_List_At_Throws(
                    out,
                    At_Level(L),
                    Level_Binding(L)
                )){
                    return true;
                }
                Fetch_Next_In_Feed(L->feed);

              require (
                Decay_If_Unstable(out)
              );
            }
            else // not a soft-"exception" case, quote ordinarily
                The_Next_In_Feed(out, L->feed);
            break;

          default:
            panic ("Invalid variadic parameter class");
        }
    }
    else
        crash ("Malformed VARARG cell");

  type_check_and_return:;

    if (Is_Void(out))
        return false;

    if (op == VARARG_OP_TAIL_Q) {
        Stable* stable = As_Stable(out);
        assert(Is_Logic(stable));
        UNUSED(stable);
        return false;
    }

    if (param) {
        require (
          bool check = Typecheck_Coerce_Use_Toplevel(
            TOP_LEVEL, Known_Unspecialized(unwrap param), out
          )
        );
        if (not check) {
            // !!! Array-based varargs only store the parameter list they are
            // stamped with, not the level.  This is because storing non-reified
            // types in payloads is unsafe...only safe to store Level* in a
            // binding.  So that means only one level can be pointed to per
            // vararg.  Revisit the question of how to give better errors.
            //
            if (not vararg_level)
                panic (Error_Bad_Value(As_Stable(out)));

            panic (Error_Phase_Arg_Type(
                unwrap vararg_level, key, unwrap param, As_Stable(out))
            );
        }
    }

    // Note: may be at end now, but reflect that at *next* call

    return false; // not thrown
}


IMPLEMENT_GENERIC(MAKE, Is_Varargs)
{
    INCLUDE_PARAMS_OF_MAKE;

    assert(Datatype_Builtin_Heart(ARG(TYPE)) == HEART_VARARGS);

    Element* arg = ARG(DEF);

    // With MAKE VARARGS! on an ANY-LIST?, the array is the backing store
    // (shared) that the varargs interface cannot affect, but changes to
    // the array will change the varargs.
    //
    if (Any_List(arg)) {
        //
        // Make a single-element array to hold a reference+index to the
        // incoming ANY-LIST?.  This level of indirection means all
        // VARARGS! copied from this will update their indices together.
        // By protocol, if the array is exhausted then the shared element
        // should be an END marker (not an array at its end)
        //
        Array* array1 = Alloc_Singular(STUB_MASK_MANAGED_SOURCE);
        if (Series_Len_At(arg) == 0)
            Poison_Cell(Stub_Cell(array1));
        else
            Copy_Cell(Stub_Cell(array1), arg);

        Reset_Cell_Header(TRACK(OUT), CELL_MASK_VARARGS);
        Tweak_Cell_Varargs_Phase(OUT, nullptr);
        UNUSED(CELL_VARARGS_SIGNED_PARAM_INDEX(OUT));  // corrupts in C++11
        Tweak_Cell_Varargs_Origin(OUT, array1);

        return BOUNCE_OUT;
    }

    // !!! Permit FRAME! ?

    panic (Error_Bad_Make(HEART_VARARGS, arg));
}


// !!! It's not clear that TAKE is the best place to put the concept of
// getting the next value of a VARARGS!, though it seems to fit.
//
// 1. Usually TAKE has a series type which it can mirror on the output, e.g.
//    (take:part '{a b c d} 2) => {a b}.  But VARARGS! doesn't have a series
//    type so we just use BLOCK!.  Presumably that's the best answer?
//
IMPLEMENT_GENERIC(TAKE, Is_Varargs)
{
    INCLUDE_PARAMS_OF_TAKE;

    Element* varargs = cast(Element*, ARG(SERIES));

    if (ARG(DEEP))
        panic (Error_Bad_Refines_Raw());
    if (ARG(LAST))
        panic (Error_Varargs_Take_Last_Raw());

    if (not ARG(PART)) {
        if (Do_Vararg_Op_Maybe_End_Throws(
            OUT,
            VARARG_OP_TAKE,
            varargs
        )){
            return THROWN;
        }
        if (Is_Void(OUT))
            return fail (Error_Nothing_To_Take_Raw());
        return BOUNCE_OUT;
    }

    assert(TOP_INDEX == STACK_BASE);

    if (not Is_Integer(unwrap ARG(PART)))
        panic (PARAM(PART));

    REBINT limit = VAL_INT32(unwrap ARG(PART));
    if (limit < 0)
        limit = 0;

    while (limit-- > 0) {
        if (Do_Vararg_Op_Maybe_End_Throws(
            OUT,
            VARARG_OP_TAKE,
            varargs
        )){
            return THROWN;
        }
        if (Is_Void(OUT))
            break;

        require (
          Stable* out = Decay_If_Unstable(OUT)
        );
        if (Is_Antiform(out))
            panic (Error_Bad_Antiform_Raw(out));

        Move_Cell(PUSH(), As_Element(out));
    }

    Init_Block(OUT, Pop_Source_From_Stack(STACK_BASE));  // block? [1]
    return BOUNCE_OUT;
}


IMPLEMENT_GENERIC(TWEAK_P, Varargs)
{
    INCLUDE_PARAMS_OF_TWEAK_P;

    const Element* varargs = Element_ARG(LOCATION);
    const Stable* picker = Element_ARG(PICKER);

    if (not Is_Integer(picker))
        panic (PARAM(PICKER));

    Stable* dual = ARG(DUAL);
    if (Not_Lifted(dual)) {
        if (Is_Null_Signifying_Tweak_Is_Pick(dual))
            goto handle_pick;

        panic (Error_Bad_Poke_Dual_Raw(dual));
    }

    goto handle_poke;

  handle_pick: {

    if (VAL_INT32(picker) != 1)
        panic (Error_Varargs_No_Look_Raw());

    if (Do_Vararg_Op_Maybe_End_Throws(
        OUT,
        VARARG_OP_FIRST,
        varargs
    )){
        assert(false); // VARARG_OP_FIRST can't throw
        return THROWN;
    }
    if (Is_Void(OUT))
        return nullptr;

    return LIFT_OUT_FOR_DUAL_PICK;

} handle_poke: {

    panic ("VARARGS! does not support modification at this time");
}}


//
//  CT_Varargs: C
//
// Simple comparison function stub (required for every type--rules TBD for
// levels of "exactness" in equality checking, or sort-stable comparison.)
//
REBINT CT_Varargs(const Element* a, const Element* b, bool strict)
{
    UNUSED(strict);

    // !!! For the moment, say varargs are the same if they have the same
    // source feed from which the data comes.  (This check will pass even
    // expired varargs, because the expired stub should be kept alive as
    // long as its identity is needed).
    //
    if (Cell_Varargs_Origin(a) == Cell_Varargs_Origin(b))
        return 0;
    return Cell_Varargs_Origin(a) > Cell_Varargs_Origin(b) ? 1 : -1;
}


IMPLEMENT_GENERIC(TAIL_Q, Is_Varargs)
{
    INCLUDE_PARAMS_OF_TAIL_Q;

    Element* vararg = Element_ARG(VALUE);

    if (Do_Vararg_Op_Maybe_End_Throws(
        OUT,
        VARARG_OP_TAIL_Q,
        vararg
    )){
        assert(false);
        return THROWN;
    }
    assert(Is_Logic(As_Stable(OUT)));
    return BOUNCE_OUT;
}


IMPLEMENT_GENERIC(EQUAL_Q, Is_Varargs)
{
    INCLUDE_PARAMS_OF_EQUAL_Q;
    bool strict = not ARG(RELAX);

    Element* v1 = Element_ARG(VALUE1);
    Element* v2 = Element_ARG(VALUE2);

    return LOGIC_OUT(CT_Varargs(v1, v2, strict) == 0);
}


// The molding of a VARARGS! does not necessarily have complete information,
// because it doesn't want to perform evaluations...or advance any frame it
// is tied to.  However, a few things are knowable; such as if the varargs
// has reached its end, or if the frame the varargs is attached to is no
// longer on the stack.
//
IMPLEMENT_GENERIC(MOLDIFY, Is_Varargs)
{
    INCLUDE_PARAMS_OF_MOLDIFY;

    Element* v = Element_ARG(VALUE);
    Molder* mo = Cell_Handle_Pointer(Molder, ARG(MOLDER));
    bool form = ARG(FORM);

    UNUSED(form);

    Begin_Non_Lexical_Mold(mo, v);  // &[varargs!

    Append_Codepoint(mo->strand, '[');

    ParamClass pclass;
    const Key* key;
    Option(const Param*) param = Param_For_Varargs_If_There_Is_One(&key, v);
    if (not param) {
        pclass = PARAMCLASS_LITERAL;
        require (
          Append_Ascii(mo->strand, "???")  // never bound to arg
        );
    }
    else {
        DECLARE_ELEMENT (param_word);
        switch ((pclass = Parameter_Class(unwrap param))) {
          case PARAMCLASS_NORMAL: {
            Init_Word(param_word, Key_Symbol(key));
            break; }

          case PARAMCLASS_LITERAL: {
            Add_Cell_Sigil(Init_Word(param_word, Key_Symbol(key)), SIGIL_PIN);
            break; }

          case PARAMCLASS_SOFT: {
            require (
              Getify(Init_Word(param_word, Key_Symbol(key)))
            );
            Quote_Cell(param_word);
            break; }

          default:
            crash (nullptr);
        };

        if (Get_Parameter_Flag(unwrap param, UNBIND_ARG))
            Quote_Cell(param_word);

        Mold_Element(mo, param_word);
    }

    require (
      Append_Ascii(mo->strand, " => ")
    );

    Level* L;
    Element* shared;
    if (Is_Block_Style_Varargs(&shared, v)) {
        if (Is_Cell_Poisoned(shared)) {
            require (
              Append_Ascii(mo->strand, "[]")
            );
        }
        else if (pclass == PARAMCLASS_LITERAL)
            Mold_Element(mo, shared); // full feed can be shown if hard quoted
        else {
            require (
              Append_Ascii(mo->strand, "[...]")  // can't look ahead
            );
        }
    }
    else if (Is_Level_Style_Varargs_Maybe_Nullptr(&L, v)) {
        if (L == NULL) {
            require (
              Append_Ascii(mo->strand, "!!!")
            );
        }
        else if (Is_Feed_At_End(L->feed)) {
            require (
              Append_Ascii(mo->strand, "[]")
            );
        }
        else if (pclass == PARAMCLASS_LITERAL) {
            require (
              Append_Ascii(mo->strand, "[")
            );
            Mold_Element(mo, At_Feed(L->feed));  // 1 value shown if hard quote
            require (
              Append_Ascii(mo->strand, " ...]")
            );
        }
        else {
            require (
              Append_Ascii(mo->strand, "[...]")
            );
        }
    }
    else
        assert(false);

    Append_Codepoint(mo->strand, ']');

    End_Non_Lexical_Mold(mo);

    return TRASH_OUT;
}


//
//  /variadic?: native [
//
//  "Returns TRUE if a frame may take a variable number of arguments"
//
//      return: [logic!]
//      frame [frame!]
//  ]
//
DECLARE_NATIVE(VARIADIC_Q)
{
    INCLUDE_PARAMS_OF_VARIADIC_Q;

    Phase* phase = Frame_Phase(ARG(FRAME));

    const Key* key_tail;
    const Key* key = Phase_Keys(&key_tail, phase);
    const Param* param = Phase_Params_Head(phase);
    for (; key != key_tail; ++param, ++key) {
        if (Get_Parameter_Flag(param, VARIADIC))
            return LOGIC_OUT(true);
    }

    return LOGIC_OUT(false);
}
