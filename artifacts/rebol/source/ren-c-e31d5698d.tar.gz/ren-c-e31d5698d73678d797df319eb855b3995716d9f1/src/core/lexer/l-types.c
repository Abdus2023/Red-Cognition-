//
//  file: %l-types.c
//  summary: "special lexical type converters"
//  section: lexical
//  project: "Rebol 3 Interpreter and Run-time (Ren-C branch)"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012 REBOL Technologies
// Copyright 2012-2025 Ren-C Open Source Contributors
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information.
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//

#include "sys-core.h"
#include "sys-dec-to-char.h"
#include <errno.h>


//
//  /type-of: pure native [
//
//  "Type of a stable value (all quoted values return QUOTED!)"
//
//      return: [datatype!]  ; !!! propagate FAILURE! if input is FAILURE! ?
//      value [any-stable?]
//  ]
//
DECLARE_NATIVE(TYPE_OF)
//
// 1. Early thinking was that TYPE OF would give a FAILURE! on NULL, and you
//    would use `try type of x` to get a null if it was null.  This was deemed
//    too prescriptive since NULL is now a LOGIC!.  Allowing TYPE OF on all
//    stable values is in line with allowing conditional tests on all stable
//    values; this creates some risk but also feature contrast with something
//    that won't decay like VOID! or TRASH!.  (type of cond x) can also be
//    used for NULL-in-NULL-out if that is desired.
{
    INCLUDE_PARAMS_OF_TYPE_OF;

    Stable* v = ARG(VALUE);
    possibly(Is_Null(v));  // returns LOGIC! [1]

    return COPY_TO_OUT(Datatype_Of(v));
}


//
//  /heart-of: pure native [
//
//  "Give back a cell's heart (e.g. HEART OF ~FOO~ or ''FOO is WORD!)"
//
//      return: [datatype!]
//      value [any-stable?]
//  ]
//
DECLARE_NATIVE(HEART_OF)
{
    INCLUDE_PARAMS_OF_HEART_OF;

    Stable* v = ARG(VALUE);

    Option(Heart) heart = Heart_Of(v);
    if (heart)
        return COPY_TO_OUT(Datatype_From_Heart(unwrap heart));

    panic ("HEART OF not supported for extension types...yet!");
}


//
//  /quotes-of: pure native [
//
//  "Return how many quote levels are on a value (quasiforms have 0 quotes)"
//
//      return: [integer!]
//      value [element?]
//  ]
//
DECLARE_NATIVE(QUOTES_OF)
{
    INCLUDE_PARAMS_OF_QUOTES_OF;

    Init_Integer(OUT, Quotes_Of(ARG(VALUE)));
    return BOUNCE_OUT;
}


//
//  /sigil-of: pure native [
//
//  "Get the SIGIL! on a value, e.g. $WORD has the $ sigil, WORD has none"
//
//      return: [<null> sigil?]
//      value [fundamental?]
//  ]
//
DECLARE_NATIVE(SIGIL_OF)
{
    INCLUDE_PARAMS_OF_SIGIL_OF;

    Element* elem = Element_ARG(VALUE);

    Option(Sigil) sigil = Sigil_Of(elem);
    if (not sigil)
        return NULL_OUT;

    Init_Sigiled_Blank(OUT, unwrap sigil);
    return BOUNCE_OUT;
}


//
//  /sigil?: pure native:intrinsic [
//
//  "Test if a value is a SIGIL... e.g. pin, meta, or tie [@ ^ $]"
//
//      return: [logic!]
//      value '[fundamental?]
//  ]
//
DECLARE_NATIVE(SIGIL_Q)
{
    INCLUDE_PARAMS_OF_SIGIL_Q;

    require (
      Element* v = opt Typecheck_Element_Intrinsic_Arg(LEVEL)
    );
    if (not v)
        return NULL_OUT;

    return LOGIC_OUT(Any_Sigiled_Blank(v));
}



//
//  /any-sigiled?: pure native:intrinsic [
//
//  "Test if value has a sigil"
//
//      return: [logic!]
//      value '[any-stable?]
//      :type
//  ]
//
DECLARE_NATIVE(ANY_SIGILED_Q)  // !!! should %make-types.r produce this?
{
    INCLUDE_PARAMS_OF_ANY_SIGILED_Q;

    Stable* v = ARG(VALUE);

    if (LEVEL->executor != &Intrinsic_Executor) {
        if (ARG(TYPE)) {
            if (not Is_Datatype(v))
                return LOGIC_OUT(false);
            return LOGIC_OUT(Any_Sigiled_Type(Datatype_Type(v)));
        }
    }
    return LOGIC_OUT(Any_Sigiled_Type(Type_Of(v)));
}


//
//  /length-of: pure native:generic [
//
//  "Get the length (in series units, e.g. codepoints) of series or other type"
//
//      return: [integer!]
//      value [plain?]  ; not quoted/quasi/sigil'd [1]
//  ]
//
DECLARE_NATIVE(LENGTH_OF)
//
// 1. See remarks on Dispatch_Generic() for why we don't allow things
//    like (3 = length of ''[a b c]).  An exception is made for action
//    antiforms, because they cannot be put in blocks, so their impact
//    is limited...and we want things like (label of append/) to be able
//    to work.  So only those are turned into the plain form here.
{
    INCLUDE_PARAMS_OF_LENGTH_OF;

    return Dispatch_Generic(LENGTH_OF, Element_ARG(VALUE), LEVEL);
}


//
//  /size-of: pure native:generic [
//
//  "Get the size (in bytes, e.g. UTF-encoded bytes) of series or other type"
//
//      return: [<null> integer!]
//      value [fundamental?]
//  ]
//
DECLARE_NATIVE(SIZE_OF)
//
// 1. The SIZE-OF native used to be distinct from the SIZE OF reflector, but
//    now that these things are unified the usermode SIZE-OF for checking the
//    size of a file! or url! would conflict.  There's not currently a way
//    to write generics in usermode, but that ability is scheduled.  Hack
//    it in just for now.
{
    INCLUDE_PARAMS_OF_SIZE_OF;

    Element* elem = Element_ARG(VALUE);

    if (Is_File(elem) or Is_Url(elem))  // !!! hack in FILE! and URL! [1]
        return rebDelegate(
            "all {info: info?", elem, "info.size}"
        );

    return Dispatch_Generic(SIZE_OF, elem, LEVEL);
}


//
//  /index-of: pure native:generic [
//
//  "Get the index of a series type"
//
//      return: [integer!]
//      value [fundamental?]
//  ]
//
DECLARE_NATIVE(INDEX_OF)
//
// !!! Should there be a generalized error catch all for ANY-ELEMENT? which
// says `return fail (Error_Type_Has_No_Index_Raw(Datatype_Of(elem)));`?  Review.
{
    INCLUDE_PARAMS_OF_INDEX_OF;

    return Dispatch_Generic(INDEX_OF, Element_ARG(VALUE), LEVEL);
}


//
//  /offset-of: pure native:generic [
//
//  "Get the offset of a series type or port (zero-based?)"
//
//      return: [integer!]
//      value [fundamental?]
//  ]
//
DECLARE_NATIVE(OFFSET_OF)
{
    INCLUDE_PARAMS_OF_OFFSET_OF;

    return Dispatch_Generic(OFFSET_OF, Element_ARG(VALUE), LEVEL);
}


//
//  /address-of: impure native:generic [
//
//  "Get the memory address of a type's data (low-level, beware!)"
//
//      return: [<null> integer!]
//      value [fundamental?]
//  ]
//
DECLARE_NATIVE(ADDRESS_OF)
//
// !!! This really needs to lock types, so that the memory can't move.  But
// for now it's a hack just to get the FFI able to find out the buffer
// behind a VECTOR!, etc.
{
    INCLUDE_PARAMS_OF_ADDRESS_OF;

    Element* elem = Element_ARG(VALUE);

    return Dispatch_Generic(ADDRESS_OF, elem, LEVEL);
}


// Asking for the ADDRESS OF a FRAME! delegates that to the DetailsQuerier.
//
// !!! It's an open question of whether functions will use the new extended
// types system to add types for ROUTINE! and ENCLOSURE! and ADAPTATION! etc.
// such that the DetailsQuerier would be obsolete.
//
IMPLEMENT_GENERIC(ADDRESS_OF, Is_Frame)
{
    INCLUDE_PARAMS_OF_ADDRESS_OF;

    Element* frame = Element_ARG(VALUE);

    Phase* phase = Frame_Phase(frame);
    if (not Is_Stub_Details(phase))
        panic ("Phase isn't details, can't get ADDRESS-OF");

    Details* details = cast(Details*, phase);
    DetailsQuerier* querier = Details_Querier(details);
    if (not (*querier)(OUT, details, SYM_ADDRESS_OF))
        return fail (
            "Frame Details does not offer ADDRESS-OF, use TRY for NULL"
        );

    return BOUNCE_OUT;
}


//
//  /of: infix native [  ; may not give PURE answer (e.g. ADDRESS OF)
//
//  "Call XXX-OF functions without a hyphen, e.g. HEAD OF X => HEAD-OF X"
//
//      return: [any-stable?]
//      '@(property) "Escapable slot for WORD!"
//          [word!]
//      {property-of}
//  ]
//
DECLARE_NATIVE(OF)
{
    INCLUDE_PARAMS_OF_OF;

    Element* prop = Element_ARG(PROPERTY);
    assert(Is_Word(prop));
    const Symbol* sym = Word_Symbol(prop);
    const Symbol* sym_of;

    Option(SymId) id = Symbol_Id(sym);
    if (id and i_cast(SymId16, unwrap id) <= MAX_SYM_BUILTIN - 1)
        goto check_if_next_is_sym_of;

    goto no_optimization;

  check_if_next_is_sym_of: { /////////////////////////////////////////////////

  // In order to speed up the navigation from builtin symbols like HEAD to
  // find HEAD-OF, the %make-boot.r process attempts to reorder the symbols
  // in such a way that HEAD-OF is the SymId immediately after HEAD.
  //
  // This can't always be done.  e.g. if the symbol is in an order-dependent
  // range, such as datatypes: SIGIL can't be followed by SIGIL-OF because
  // SIGIL-OF is not a datatype.  It also obviously won't work for an -OF
  // function that the user (or unprocessed Mezzanine) comes up with after
  // the fact.  So we check to see if the next symbol is an -OF match and save
  // on symbol hashing and lookup.
  //
  // (This could be optimized at load time if symbols carried a flag that said
  // the next symbol was an -OF, but rather than take a symbol flag for now we
  // just do the relatively cheap check.)

    const Utf8Byte* utf8 = Strand_Head(Canon_Symbol(unwrap id));
    SymId next_id = i_cast(SymId, i_cast(SymId16, unwrap id) + 1);
    const Utf8Byte* maybe_utf8_of = Strand_Head(Canon_Symbol(next_id));
    while (true) {
        if (*maybe_utf8_of == '\0')  // hit end of what would be "longer"
            goto no_optimization;
        if (*utf8 == '\0')  // hit end of what would be "shorter"...
            break;  // might be a match if "-of" are next 3 chars!
        if (*utf8 != *maybe_utf8_of)  // mismatch before end of shorter
            goto no_optimization;
        ++utf8;
        ++maybe_utf8_of;
    }
    if (
        maybe_utf8_of[0] == '-'
        and maybe_utf8_of[1] == 'o'
        and maybe_utf8_of[2] == 'f'
        and maybe_utf8_of[3] == '\0'
    ){
        sym_of = Canon_Symbol(next_id);
        goto have_sym_of;
    }

} no_optimization: { /////////////////////////////////////////////////////////

    Byte buffer[256];
    Size size = Strand_Size(sym);
    Mem_Copy(buffer, Strand_Utf8(sym), size);
    buffer[size] = '-';
    ++size;
    buffer[size] = 'o';
    ++size;
    buffer[size] = 'f';
    ++size;
    assume (
      sym_of = Intern_Symbol(buffer, size)
    );

} have_sym_of: { /////////////////////////////////////////////////////////////

    Element* property_of = Init_Word(LOCAL(PROPERTY_OF), sym_of);
    Add_Cell_Sigil(property_of, SIGIL_META);
    Bind_Cell_If_Unbound(property_of, Level_Binding(LEVEL));

    heeded (Corrupt_Cell_If_Needful(SPARE));
    heeded (Corrupt_Cell_If_Needful(SCRATCH));

    STATE = ST_TWEAK_GETTING;

    require (
      Get_Var_To_Out_Use_Toplevel(property_of, GROUP_EVAL_NO)
    );

    if (not Is_Action(OUT))
        panic ("OF looked up to a value that wasn't an ACTION!");

    Flags flags = FLAG_STATE_BYTE(ST_STEPPER_REEVALUATING);

    require (
      Level* sub = Make_Level(&Stepper_Executor, level_->feed, flags)
    );
    Push_Level(sub);

    Copy_Plain_Cell(Evaluator_Level_Current(sub), OUT);
    assert(Is_Frame(Evaluator_Level_Current(sub)));
    Corrupt_Cell_If_Needful(OUT);

    return DELEGATE_SUBLEVEL;  // !!! could/should we replace this level?
}}


//
//  Try_Scan_Hex_Integer: C
//
// Scans hex while it is valid and does not exceed the maxlen.
// If the hex string is longer than maxlen - it's an error.
// If a bad char is found less than the minlen - it's an error.
// String must not include # - ~ or other invalid chars.
// If minlen is zero, and no string, that's a valid zero value.
//
Option(const Byte*) Try_Scan_Hex_Integer(
    Sink(Element) out,
    const Byte* cp,
    REBLEN minlen,
    REBLEN maxlen
){
    if (maxlen > MAX_HEX_LEN)
        return nullptr;

    REBI64 i = 0;
    REBLEN len = 0;
    Byte nibble;
    while (Try_Get_Lex_Hexdigit(&nibble, *cp)) {
        i = (i << 4) + nibble;
        cp++;
    }

    if (len < minlen)
        return nullptr;

    Init_Integer(out, i);
    return cp;
}


//
//  Try_Scan_Hex2: C
//
// Decode a %xx hex encoded sequence into a byte value.
//
// The % should already be removed before calling this.
//
// Returns new position after advancing or NULL.  On success, it always
// consumes two bytes (which are two codepoints).
//
Option(const Byte*) Try_Scan_Hex2(Byte* decoded_out, const Byte* bp)
{
    Byte nibble1;
    if (not Try_Get_Lex_Hexdigit(&nibble1, bp[0]))
        return nullptr;

    Byte nibble2;
    if (not Try_Get_Lex_Hexdigit(&nibble2, bp[1]))
        return nullptr;

    *decoded_out = cast(Codepoint, (nibble1 << 4) + nibble2);

    return bp + 2;
}


//
//  Try_Scan_Decimal_To_Stack: C
//
// Scan and convert a decimal value.  Return new character position or null.
//
Option(const Byte*) Try_Scan_Decimal_To_Stack(
    const Byte* cp,
    REBLEN len,
    bool dec_only
){
    Byte buf[MAX_NUM_LEN + 4];
    Byte* ep = buf;
    if (len > MAX_NUM_LEN)
        return nullptr;

    const Byte* bp = cp;

    if (*cp == '+' || *cp == '-')
        *ep++ = *cp++;

    bool digit_present = false;

    while (Is_Lex_Number(*cp) || *cp == '\'') {
        if (*cp != '\'') {
            *ep++ = *cp++;
            digit_present = true;
        }
        else
            ++cp;
    }

    if (*cp == ',' || *cp == '.')
        ++cp;

    *ep++ = '.';

    while (Is_Lex_Number(*cp) || *cp == '\'') {
        if (*cp != '\'') {
            *ep++ = *cp++;
            digit_present = true;
        }
        else
            ++cp;
    }

    if (not digit_present)
        return nullptr;

    if (*cp == 'E' || *cp == 'e') {
        *ep++ = *cp++;
        digit_present = false;

        if (*cp == '-' || *cp == '+')
            *ep++ = *cp++;

        while (Is_Lex_Number(*cp)) {
            *ep++ = *cp++;
            digit_present = true;
        }

        if (not digit_present)
            return nullptr;
    }

    if (*cp == '%') {
        if (dec_only)
            return nullptr;

        ++cp; // ignore it
    }

    *ep = '\0';

    if (cp - bp != len)
        return nullptr;

    char *se;
    double d = strtod(s_cast(buf), &se);
    if (fabs(d) == HUGE_VAL)  // !!! TBD: need check for NaN, and INF
        panic (Error_Overflow_Raw());

    Init_Decimal(PUSH(), d);
    return cp;
}


//
//  Try_Scan_Integer_To_Stack: C
//
// Scan and convert an integer value.  Return new position or null if error.
// Allow preceding + - and any combination of ' marks.
//
const Byte* Try_Scan_Integer_To_Stack(
    const Byte* cp,
    REBLEN len
){
    if (len == 1 and Is_Lex_Number(*cp)) {  // fast convert single digit #s
        Init_Integer(PUSH(), Get_Lex_Number(*cp));
        return cp + 1;
    }

    Byte buf[MAX_NUM_LEN + 4];
    if (len > MAX_NUM_LEN)
        return nullptr;  // prevent buffer overflow

    Byte* bp = buf;

    bool neg = false;

    REBINT num = len;

    // Strip leading signs:
    if (*cp == '-') {
        *bp++ = *cp++;
        --num;
        neg = true;
    }
    else if (*cp == '+') {
        ++cp;
        --num;
    }

    // Remove leading zeros:
    for (; num > 0; num--) {
        if (*cp == '0' || *cp == '\'')
            ++cp;
        else
            break;
    }

    if (num == 0) { // all zeros or '
        // return early to avoid platform dependant error handling in CHR_TO_INT
        Init_Integer(PUSH(), 0);
        return cp;
    }

    // Copy all digits, except ' :
    for (; num > 0; num--) {
        if (*cp >= '0' && *cp <= '9')
            *bp++ = *cp++;
        else if (*cp == '\'')
            ++cp;
        else
            return nullptr;
    }
    *bp = '\0';

    // Too many digits?
    len = bp - &buf[0];
    if (neg)
        --len;
    if (len > 19) {
        // !!! magic number :-( How does it relate to MAX_INT_LEN (also magic)
        return nullptr;
    }

    // Convert, check, and return:
    errno = 0;

    REBI64 i = CHR_TO_INT(buf);
    if (errno != 0)
        return nullptr;  // overflow

    if ((i > 0 and neg) or (i < 0 and not neg))
        return nullptr;

    Init_Integer(PUSH(), i);
    return cp;
}


//
//  Try_Scan_Date_To_Stack: C
//
// Scan and convert a date. Also can include a time and zone.
//
Option(const Byte*) Try_Scan_Date_To_Stack(const Byte* cp, REBLEN len) {
    const Byte* end = cp + len;

    // Skip spaces:
    for (; *cp == ' ' && cp != end; cp++);

    // Skip day name, comma, and spaces:
    const Byte* ep;
    for (ep = cp; *ep != ',' && ep != end; ep++);
    if (ep != end) {
        cp = ep + 1;
        while (*cp == ' ' && cp != end) cp++;
    }
    if (cp == end)
        return nullptr;

    REBINT num;

    if (not (ep = opt Try_Grab_Int(&num, cp)))  // Day or 4-digit year
        return nullptr;
    if (num < 0)
        return nullptr;

    REBINT day;
    REBINT month;
    REBINT year;
    REBINT tz = NO_DATE_ZONE;
    REBI64 nanoseconds = NO_DATE_TIME; // may be overwritten

    Size size = ep - cp;
    if (size >= 4) {
        // year is set in this branch (we know because day is 0)
        // Ex: 2009/04/20/19:00:00+0:00
        year = num;
        day = 0;
    }
    else {
        assert(size != 0);  // because Try_Grab_Int() succeeded

        // year is not set in this branch (we know because day ISN'T 0)
        // Ex: 12-Dec-2012
        day = num;
        if (day == 0)
            return nullptr;

        // !!! Clang static analyzer doesn't know from test of `day` below
        // how it connects with year being set or not.  Suppress warning.
        year = INT32_MIN; // !!! Garbage, should not be read.
    }

    cp = ep;

    // Determine field separator:
    if (*cp != '/' && *cp != '-' && *cp != '.' && *cp != ' ')
        return nullptr;

    Byte sep = *cp++;

    const Byte *ep_num = opt Try_Grab_Int(&num, cp);

    if (ep_num) {  // month was a number
        if (num < 0)
            return nullptr;

        month = num;
        ep = ep_num;
    }
    else { // month must be a word
        for (ep = cp; Is_Lex_Word(*ep); ep++)
            NOOP; // scan word

        size = ep - cp;
        if (size < 3)
            return nullptr;

        for (num = 0; num != 12; ++num) {
            const Byte* month_name = b_cast(g_month_names[num]);
            if (0 == Compare_Ascii_Uncased(month_name, cp, size))
                break;
        }
        month = num + 1;
    }

    if (month < 1 || month > 12)
        return nullptr;

    cp = ep;
    if (*cp++ != sep)
        return nullptr;

    ep = opt Try_Grab_Int(&num, cp);  // Year or day (if year was first)
    if (not ep or *cp == '-' or num < 0)
        return nullptr;

    size = ep - cp;
    assert(size > 0);  // because Try_Grab_Int() succeeded

    if (day == 0) {
        // year already set, but day hasn't been
        day = num;
    }
    else {
        // day has been set, but year hasn't been.
        if (size >= 3)
            year = num;
        else {
            // !!! Originally this allowed shorthands, so that 96 = 1996, etc.
            //
            //     if (num >= 70)
            //         year = 1900 + num;
            //     else
            //         year = 2000 + num;
            //
            // It was trickier than that, because it actually used the current
            // year (from the clock) to guess what the short year meant.  That
            // made it so the scanner would scan the same source code
            // differently based on the clock, which is bad.  By allowing
            // short dates to be turned into their short year equivalents, the
            // user code can parse such dates and fix them up after the fact
            // according to their requirements, `if date/year < 100 [...]`
            //
            year = num;
        }
    }

    if (year > MAX_YEAR || day < 1 || day > g_month_max_days[month-1])
        return nullptr;

    // Check February for leap year or century:
    if (month == 2 && day == 29) {
        if (
            ((year % 4) != 0) ||        // not leap year
            ((year % 100) == 0 &&       // century?
            (year % 400) != 0)
        ){
            return nullptr;  // not leap century
        }
    }

    cp = ep;

    if (cp >= end)
        goto end_date;

    if (*cp == '/' || *cp == ' ') {
        sep = *cp++;

        if (cp >= end)
            goto end_date;

        Option(Length) time_len = 0;  // !!! not used/required by time scan?
        if (not (cp = opt Try_Scan_Time_To_Stack(cp, time_len)))
            return nullptr;

        if (
            VAL_NANO(TOP) < 0
            or VAL_NANO(TOP) >= SECS_TO_NANO(24 * 60 * 60)
        ){
            return nullptr;
        }
        assert(TOP->payload.nanoseconds != NO_DATE_TIME);
        nanoseconds = VAL_NANO(TOP);
        DROP();  // !!! could reuse top cell for "efficiency"
    }

    // past this point, header is set, so `goto end_date` is legal.

    if (*cp == sep)
        ++cp;

    // Time zone can be 12:30 or 1230 (optional hour indicator)
    if (*cp == '-' || *cp == '+') {
        if (cp >= end)
            goto end_date;

        if (not (ep = opt Try_Grab_Int(&num, cp + 1)))
            return nullptr;

        if (*ep != ':') {
            if (num < -1500 || num > 1500)
                return nullptr;

            int h = (num / 100);
            int m = (num - (h * 100));

            tz = (h * 60 + m) / ZONE_MINS;
        }
        else {
            if (num < -15 || num > 15)
                return nullptr;

            tz = num * (60 / ZONE_MINS);

            if (*ep == ':') {
                ep = opt Try_Grab_Int(&num, ep + 1);
                if (not ep or num % ZONE_MINS != 0)
                    return nullptr;

                tz += num / ZONE_MINS;
            }
        }

        if (ep != end)
            return nullptr;

        if (*cp == '-')
            tz = -tz;

        cp = ep;
    }

  end_date: {

    // Overwriting scanned TYPE_TIME...
    // payload.time.nanoseconds set
    // may be NO_DATE_TIME, don't Freshen_Cell_Header()

    OnStack(Cell*) pushed = PUSH();
    USED(pushed);  // we are using this for tracking live cell on stack

    Sink(Element) top = TOP;  // workaround ambiguity in Ensure_Date()
    Reset_Cell_Header(top, CELL_MASK_DATE);
    VAL_YEAR(top) = year;
    VAL_MONTH(top) = month;
    VAL_DAY(top) = day;
    CELL_DATE_YMDZ(top).zone = NO_DATE_ZONE;  // Adjust_Date_Zone() needs
    Tweak_Cell_Nanoseconds(top, nanoseconds);

    Adjust_Date_Zone_Core(top, tz);

    CELL_DATE_YMDZ(top).zone = tz;

    return cp;
}}


//
//  Scan_Email_To_Stack: C
//
// Scan and convert email.
//
Result(const Byte*) Scan_Email_To_Stack(const Byte* cp, REBLEN len)
{
    trap (  // use mold buffer vs. guess size?
      Strand* s = Make_Strand(len * 2)
    );
    Utf8(*) up = Strand_Head(s);

    REBLEN num_chars = 0;

    bool found_at = false;
    for (; len > 0; len--) {
        if (*cp == '@') {
            if (found_at)
                return fail ("Email address cannot have multiple '@' symbols");
            found_at = true;
        }

        if (*cp == '%') {
            if (len <= 2)
                return fail ("Email must have at least 2 characters after %");

            Byte decoded;
            if (not (cp = opt Try_Scan_Hex2(&decoded, cp + 1)))
                return fail ("Coudn't Scan_Hex() in email address");

            up = Write_Codepoint(up, decoded);
            ++num_chars;
            len -= 2;
        }
        else {
            up = Write_Codepoint(up, *cp++);
            ++num_chars;
        }
    }

    if (not found_at)
        return fail ("Email address must contain an '@' symbol");

    Term_Strand_Len_Size(s, num_chars, up - Strand_Head(s));

    if (Try_Init_Small_Utf8(
        PUSH(),
        HEART_EMAIL,
        Strand_Head(s),
        Strand_Len(s),
        Strand_Size(s)
    )){
        Free_Unmanaged_Flex(s);
        return cp;
    }

    DROP();  // didn't write, try again (stack may have moved...!)

    Freeze_Flex(s);
    Init_String(PUSH(), HEART_EMAIL, s);
    return cp;
}


//
//  Try_Scan_URL_To_Stack: C
//
// While Rebol2, R3-Alpha, and Red attempted to apply some amount of decoding
// (e.g. how %20 is "space" in http:// URL!s), Ren-C leaves URLs "as-is".
// This means a URL may be copied from a web browser bar and pasted back.
// It also means that the URL may be used with custom schemes (odbc://...)
// that have different ideas of the meaning of characters like `%`.
//
// !!! The current concept is that URL!s typically represent the *decoded*
// forms, and thus express unicode codepoints normally...preserving either of:
//
//     https://duckduckgo.com/?q=hergé+&+tintin
//     https://duckduckgo.com/?q=hergé+%26+tintin
//
// Then, the encoded forms with UTF-8 bytes expressed in %XX form would be
// converted as TEXT!, where their datatype suggests the encodedness:
//
//     {https://duckduckgo.com/?q=herg%C3%A9+%26+tintin}
//
// (This is similar to how local FILE!s, where e.g. slashes become backslash
// on Windows, are expressed as TEXT!.)
//
// 1. The code wasn't set up to do validation of URLs, it just assumed that
//    Prescan_Token() had done the necessary checking.  But this routine
//    is used in TO URL! conversion as well, where validation is necessary.
//    All this needs review after more fundamental questions shake out,
//    but for now we add a check.
//
Option(const Byte*) Try_Scan_URL_To_Stack(const Byte* cp, REBLEN len)
{
    const Byte* t = cp;
    const Byte* tail = cp + len;
    while (true) {
        if (t == tail)
            return nullptr;  // didn't find "://"

        if (*t != ':') {
            ++t;
            continue;
        }
        ++t;  // found :
        if (t == tail)
            return nullptr;
        if (*t == ':')   // log::foo style URL legal as well
            break;
        if (*t != '/')
            return nullptr;
        ++t;  // found :/
        if (t == tail or *t != '/')
            return nullptr;
        break;  // found ://
    }

    Strand* s = Append_UTF8_May_Panic(
        nullptr,
        s_cast(cp),
        len,
        STRMODE_NO_CR
    );

    if (Try_Init_Small_Utf8(
        PUSH(),
        HEART_URL,
        Strand_Head(s),
        Strand_Len(s),
        Strand_Size(s)
    )){
        Free_Unmanaged_Flex(s);  // !!! direct mold buffer use would be better
        return cp + len;
    }

    DROP();  // didn't write, try again (stack may have moved...!)

    Freeze_Flex(s);
    Init_String(PUSH(), HEART_URL, s);

    return cp + len;
}


//
//  Try_Scan_Pair_To_Stack: C
//
// Scan and convert a pair
//
Option(const Byte*) Try_Scan_Pair_To_Stack(
    const Byte* cp,
    REBLEN len
){
    const Byte* bp = cp;

    REBINT x;
    if (not (cp = opt Try_Grab_Int(&x, cp)))
        return nullptr;
    if (*cp != 'x' and *cp != 'X')
        return nullptr;

    cp++;

    REBINT y;
    if (not (cp = opt Try_Grab_Int(&y, cp)))
        return nullptr;

    if (len > cp - bp)  // !!! scanner checks if not precisely equal...
        return nullptr;

    Init_Pair(PUSH(), x, y);
    return cp;
}


//
//  Try_Scan_Binary_To_Stack: C
//
// Scan and convert binary strings.
//
Option(const Byte*) Try_Scan_Binary_To_Stack(
    const Byte* cp,
    REBLEN len
){
    REBINT base = 16;

    if (*cp != '#') {
        const Byte* ep = opt Try_Grab_Int(&base, cp);
        if (not ep or *ep != '#')
            return nullptr;
        len -= ep - cp;
        cp = ep;
    }

    cp++;  // skip #
    if (*cp++ != '{')
        return nullptr;

    len -= 2;

    Binary* decoded = opt Decode_Enbased_Utf8_As_Binary(&cp, len, base, '}');
    if (not decoded)
        return nullptr;

    cp = opt Skip_To_Byte(cp, cp + len, '}');
    if (not cp) {
        Free_Unmanaged_Flex(decoded);
        return nullptr;
    }

    Init_Blob(PUSH(), decoded);

    return cp + 1;  // include the "}" in the scan total
}


//
//  /scan-net-header: native [
//
//  "Scan an Internet-style header (HTTP, SMTP)"
//
//      return: [block!]
//      header "Fields with duplicate words will be merged into a block"
//          [blob!]
//  ]
//
DECLARE_NATIVE(SCAN_NET_HEADER)
//
// !!! This routine used to be a feature of CONSTRUCT in R3-Alpha, and was
// used by %prot-http.r.  The idea was that instead of providing a parent
// object, a STRING! or BLOB! could be provided which would be turned
// into a block by this routine.
//
// It doesn't make much sense to have this coded in C rather than using PARSE
// It's only being converted into a native to avoid introducing bugs by
// rewriting it as Rebol in the middle of other changes.
{
    INCLUDE_PARAMS_OF_SCAN_NET_HEADER;

    Source* result = Make_Source_Managed(10);  // Guess at size (data stack?)

    Stable* header = ARG(HEADER);
    Size size;
    const Byte* cp = Cell_Bytes_At(&size, header);
    UNUSED(size);  // !!! Review semantics

    while (Is_Lex_Whitespace(*cp)) cp++; // skip white space

    const Byte* start;
    REBINT len;

    while (true) {
        // Scan valid word:
        if (Is_Lex_Word(*cp)) {
            start = cp;
            while (
                Is_Lex_Word_Or_Number(*cp)
                || *cp == '.'
                || *cp == '-'
                || *cp == '_'
            ) {
                cp++;
            }
        }
        else break;

        if (*cp != ':')
            break;

        Sink(Element) val = nullptr;  // suppress maybe uninitialized warning

        require (
          const Symbol* name = Intern_Symbol(start, cp - start)
        );

        cp++;
        // Search if word already present:

        const Element* item_tail = Array_Tail(result);
        Element* item = Array_Head(result);

        for (; item != item_tail; item += 2) {
            assert(Is_Text(item + 1) || Is_Block(item + 1));
            if (Are_Synonyms(Word_Symbol(item), name)) {
                // Does it already use a block?
                if (Is_Block(item + 1)) {
                    // Block of values already exists:
                    require (
                      val =Alloc_Tail_Array(Cell_Array_Ensure_Mutable(item + 1))
                    );
                }
                else {
                    // Create new block for values:
                    Source* a = Make_Source_Managed(2);
                    require (
                      Sink(Element) prior = Alloc_Tail_Array(a)
                    );
                    Copy_Cell_May_Bind(
                        prior,
                        item + 1,  // prior value
                        SPECIFIED  // no relative values added
                    );
                    require (
                      val = Alloc_Tail_Array(a)
                    );
                    Init_Block(item + 1, a);
                }
                break;
            }
        }

        if (item == item_tail) {  // didn't break, add space for new word/value
            require (
              Sink(Element) cell = Alloc_Tail_Array(result)
            );
            Init_Set_Word(cell, name);
            require (
              val = Alloc_Tail_Array(result)
            );
        }

        while (Is_Lex_Space(*cp)) cp++;
        start = cp;
        len = 0;
        while (!ANY_CR_LF_END(*cp)) {
            len++;
            cp++;
        }
        // Is it continued on next line?
        while (*cp) {
            if (*cp == CR)
                ++cp;
            if (*cp == LF)
                ++cp;
            if (not Is_Lex_Space(*cp))
                break;
            while (Is_Lex_Space(*cp))
                ++cp;
            while (!ANY_CR_LF_END(*cp)) {
                ++len;
                ++cp;
            }
        }

        // Create string value (ignoring lines and indents):
        //
        // !!! This is written to deal with unicode lengths in terms of *size*
        // in bytes, not *length* in characters.  If it were to be done
        // correctly, it would need to use Utf8_Next to count the characters
        // in the loop above.  Better to convert to usermode.

        require (
          Strand* strand = Make_Strand(len * 2)
        );
        Utf8(*) at = Strand_Head(strand);
        cp = start;

        // "Code below *MUST* mirror that above:"

        while (!ANY_CR_LF_END(*cp))
            at = Write_Codepoint(at, *cp++);
        while (*cp != '\0') {
            if (*cp == CR)
                ++cp;
            if (*cp == LF)
                ++cp;
            if (not Is_Lex_Space(*cp))
                break;
            while (Is_Lex_Space(*cp))
                ++cp;
            while (!ANY_CR_LF_END(*cp))
                at = Write_Codepoint(at, *cp++);
        }
        Term_Strand_Len_Size(strand, len, at - Strand_Head(strand));
        Init_Text(val, strand);
    }

    Init_Block(OUT, result);
    return BOUNCE_OUT;
}
