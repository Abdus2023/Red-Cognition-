//
//  file: %n-bitwise.c
//  summary: "Native functions for bitwise math"
//  section: natives
//  project: "Rebol 3 Interpreter and Run-time (Ren-C branch)"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012 REBOL Technologies
// Copyright 2012-2017 Ren-C Open Source Contributors
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information.
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Note: Instead of individual functions, it was thought that there might
// be a dialect called BITWISE more generically suited to bitwise manipuation,
// where words like AND, OR, etc. would not be logic based but bitwise based.
//
//     foo: bitwise [(a and b) or c]
//
// This idea was held up by questions about binding, e.g. whether the AND,
// OR, etc. would be keywords or if binding would just override in the
// block.  With pure virtual binding, it may be feasible to do this using
// binding instead of recognizing 'and 'or etc. literally.
//

#include "sys-core.h"


//
//  /bitwise-not: native:generic [
//
//  "Returns the one's complement value"
//
//      return: [logic! integer! tuple! blob!]
//      value [logic! integer! tuple! blob!]
//  ]
//
DECLARE_NATIVE(BITWISE_NOT)
{
    INCLUDE_PARAMS_OF_BITWISE_NOT;

    Stable* v = ARG(VALUE);

    if (Is_Logic(v)) {
        bool b1 = Cell_Logic(v);
        return LOGIC_OUT(not b1);
    }

    return Old_Dispatch_Generic(BITWISE_NOT, As_Element(v), LEVEL);
}


//
//  /bitwise-and: native:generic [
//
//  "Bitwise AND of two values"
//
//      return: [logic! integer! char? tuple! blob!]
//      value1 [logic! integer! char? tuple! blob!]
//      value2 [logic! integer! char? tuple! blob!]
//  ]
//
DECLARE_NATIVE(BITWISE_AND)
{
    INCLUDE_PARAMS_OF_BITWISE_AND;

    Stable* v1 = ARG(VALUE1);
    Stable* v2 = ARG(VALUE2);

    if (Is_Logic(v1)) {
        if (not Is_Logic(v2))
            panic (PARAM(VALUE2));
        bool b1 = Cell_Logic(v1);
        bool b2 = Cell_Logic(v2);
        return LOGIC_OUT(b1 and b2);
    }
    else if (Is_Logic(v2))
        panic (PARAM(VALUE2));

    return Old_Dispatch_Generic(BITWISE_AND, As_Element(v1), LEVEL);
}


//
//  /bitwise-or: native:generic [
//
//  "Bitwise OR of two values"
//
//      return: [logic! integer! char? tuple! blob!]
//      value1 [logic! integer! char? tuple! blob!]
//      value2 [logic! integer! char? tuple! blob!]
//  ]
//
DECLARE_NATIVE(BITWISE_OR)
{
    INCLUDE_PARAMS_OF_BITWISE_OR;

    Stable* v1 = ARG(VALUE1);
    Stable* v2 = ARG(VALUE2);

    if (Is_Logic(v1)) {
        if (not Is_Logic(v2))
            panic (PARAM(VALUE2));
        bool b1 = Cell_Logic(v1);
        bool b2 = Cell_Logic(v2);
        return LOGIC_OUT(b1 or b2);
    }
    else if (Is_Logic(v2))
        panic (PARAM(VALUE2));

    return Old_Dispatch_Generic(BITWISE_OR, As_Element(v1), LEVEL);
}


//
//  /bitwise-xor: native:generic [
//
//  "Bitwise XOR of two values"
//
//      return: [logic! integer! char? tuple! blob!]
//      value1 [logic! integer! char? tuple! blob!]
//      value2 [logic! integer! char? tuple! blob!]
//  ]
//
DECLARE_NATIVE(BITWISE_XOR)
{
    INCLUDE_PARAMS_OF_BITWISE_XOR;

    Stable* v1 = ARG(VALUE1);
    Stable* v2 = ARG(VALUE2);

    if (Is_Logic(v1)) {
        if (not Is_Logic(v2))
            panic (PARAM(VALUE2));
        bool b1 = Cell_Logic(v1);
        bool b2 = Cell_Logic(v2);
        return LOGIC_OUT(b1 != b2);
    }
    else if (Is_Logic(v2))
        panic (PARAM(VALUE2));

    return Old_Dispatch_Generic(BITWISE_XOR, As_Element(v1), LEVEL);
}


//
//  /bitwise-and-not: native:generic [
//
//  "Bitwise AND NOT of two values"
//
//      return: [logic! integer! char? tuple! blob!]
//      value1 [logic! integer! char? tuple! blob!]
//      value2 [logic! integer! char? tuple! blob!]
//  ]
//
DECLARE_NATIVE(BITWISE_AND_NOT)
{
    INCLUDE_PARAMS_OF_BITWISE_AND_NOT;

    Stable* v1 = ARG(VALUE1);
    Stable* v2 = ARG(VALUE2);

    if (Is_Logic(v1)) {
        if (not Is_Logic(v2))
            panic (PARAM(VALUE2));
        bool b1 = Cell_Logic(v1);
        bool b2 = Cell_Logic(v2);
        return LOGIC_OUT(b1 and not b2);
    }
    else if (Is_Logic(v2))
        panic (PARAM(VALUE2));

    return Old_Dispatch_Generic(BITWISE_AND_NOT, As_Element(v1), LEVEL);
}


//
// The SHIFT native uses negation of an unsigned number.  Although the
// operation is well-defined in the C language, it is usually a mistake.
// MSVC warns about it, so temporarily disable that.
//
// !!! The usage of negation of unsigned in SHIFT is from R3-Alpha.  Should it
// be rewritten another way?
//
// http://stackoverflow.com/a/36349666/211160
//
#if defined(_MSC_VER) && _MSC_VER > 1800
    #pragma warning (disable : 4146)
#endif


//
//  /shift: native [
//
//  "Shifts an integer left or right by a number of bits"
//
//      return: [integer!]
//      value [integer!]
//      bits "Positive for left shift, negative for right shift"
//          [integer!]
//      :logical "Logical shift (sign bit ignored)"
//  ]
//
DECLARE_NATIVE(SHIFT)
{
    INCLUDE_PARAMS_OF_SHIFT;

    REBI64 b = VAL_INT64(ARG(BITS));
    Stable* a = ARG(VALUE);

    if (b < 0) {
        REBU64 c = (- i_cast(REBU64, b)); // defined, see note on #pragma above
        if (c >= 64) {
            if (ARG(LOGICAL))
                mutable_VAL_INT64(a) = 0;
            else
                mutable_VAL_INT64(a) >>= 63;
        }
        else {
            if (ARG(LOGICAL))
                mutable_VAL_INT64(a) = i_cast(REBU64, VAL_INT64(a)) >> c;
            else
                mutable_VAL_INT64(a) >>= i_cast(REBI64, c);
        }
    }
    else {
        if (b >= 64) {
            if (ARG(LOGICAL))
                mutable_VAL_INT64(a) = 0;
            else if (VAL_INT64(a) != 0)
                panic (Error_Overflow_Raw());
        }
        else {
            if (ARG(LOGICAL))
                mutable_VAL_INT64(a) = i_cast(REBU64, VAL_INT64(a)) << b;
            else {
                REBU64 c = i_cast(REBU64, INT64_MIN) >> b;
                REBU64 d = VAL_INT64(a) < 0
                    ? - i_cast(REBU64, VAL_INT64(a)) // again, see #pragma
                    : i_cast(REBU64, VAL_INT64(a));
                if (c <= d) {
                    if ((c < d) || (VAL_INT64(a) >= 0))
                        panic (Error_Overflow_Raw());

                    mutable_VAL_INT64(a) = INT64_MIN;
                }
                else
                    mutable_VAL_INT64(a) <<= b;
            }
        }
    }

    return COPY_TO_OUT(ARG(VALUE));
}


// See above for the temporary disablement and reasoning.
//
#if defined(_MSC_VER) && _MSC_VER > 1800
    #pragma warning (default : 4146)
#endif
