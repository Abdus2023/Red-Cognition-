//
//  file: %n-do.c
//  summary: "native functions for DO, EVAL, APPLY"
//  section: natives
//  project: "Rebol 3 Interpreter and Run-time (Ren-C branch)"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012 REBOL Technologies
// Copyright 2012-2017 Ren-C Open Source Contributors
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information.
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Ren-C's philosophy of DO is that the argument to it represents a place to
// find source code.  Hence `DO 3` does not evaluate to the number 3, any
// more than `DO "print hello"` would evaluate to `"print hello"`.  If a
// generalized evaluator is needed, use the special-purpose REEVAL(UATE).
//
// Note that although the code for running blocks and frames is implemented
// here as C, the handler for processing STRING!, FILE!, TAG!, URL!, etc. is
// dispatched out to some Rebol code that implements DO.
//

#include "sys-core.h"


//
//  /reeval: native [
//
//  "Process an evaluated argument *inline* as an evaluator step would"
//
//      return: [any-value?]
//      value "BLOCK! passes-thru, FRAME! runs, SET-WORD! assigns..."
//          [element?]
//      expressions "Depending on VALUE, more expressions may be consumed"
//          [<opt> element? <variadic>]
//  ]
//
DECLARE_NATIVE(REEVAL)
{
    INCLUDE_PARAMS_OF_REEVAL;

    // REEVAL only *acts* variadic, but uses ST_STEPPER_REEVALUATING
    //
    UNUSED(ARG(EXPRESSIONS));

    Element* v = ARG(VALUE);

    Flags flags = FLAG_STATE_BYTE(ST_STEPPER_REEVALUATING);

    require (
      Level* sub = Make_Level(&Stepper_Executor, level_->feed, flags)
    );
    Push_Level(sub);

    Copy_Cell(Evaluator_Level_Current(sub), v);  // evaluator's CURRENT

    return DELEGATE_SUBLEVEL;
}


//
//  /shove: native [
//
//  "Shove a parameter into an ACTION! as its first argument"
//
//      return: [any-value?]
//      @left "Hard literal, will be processed according to right's first arg"
//          [element?]
//      @right "Arbitrary variadic feed of expressions on the right"
//          [<variadic> element?]
//  ]
//
DECLARE_NATIVE(SHOVE)
//
// PATH!s do not do infix lookup in Rebol, and there are good reasons for this
// in terms of both performance and semantics.  However, it is sometimes
// needed to dispatch via a path--for instance to call an infix function that
// lives in a context.
//
// The SHOVE operation is used to push values from the left to act as the
// first argument of an operation, e.g.:
//
//      >> 10 ->- lib/(print "Hi!" first [multiply]) 20
//      Hi!
//      200
//
// It's becoming more possible to write something like this in usermode, but
// it would be inefficient, and there are binding problems to worry about
// in macro-like code.
{
    INCLUDE_PARAMS_OF_SHOVE;

    Level* L;
    if (not Is_Level_Style_Varargs_May_Panic(&L, ARG(RIGHT)))
        panic ("SHOVE (->-) not implemented for MAKE VARARGS! [...] yet");

    Element* left = ARG(LEFT);

    if (Is_Level_At_End(L))  // shouldn't be for WORD!/PATH! unless APPLY
        return COPY_TO_OUT(ARG(LEFT));  // evaluator wants `help <-` to work

  //=//// RESOLVE ACTION ON RIGHT (LOOKUP VAR, EVAL GROUP...) /////////////=//
  //
  // 1. At one point, it was allowed to shove into set-words etc:
  //
  //        >> 10 ->- x:
  //        >> x
  //        == 10
  //
  //    Is that useful enough to bother supporting?

    Stable* shovee = ARG(RIGHT); // reuse variadic arg cell for the shoved-into
    Option(const Symbol*) label = nullptr;

    const Element* right = At_Level(L);
    if (
        Is_Word(right) or Is_Tuple(right)
        or Is_Path(right) or Is_Chain(right)
    ){
        require (
          Stable* out = Get_Var(
            OUT,  // can't eval directly into arg slot
            NO_STEPS,
            At_Level(L),
            Level_Binding(L)
        ));

        Move_Cell(shovee, out);  // variable contents always stable
    }
    else if (Is_Group(right)) {
        if (Eval_Any_List_At_Throws(OUT, right, Level_Binding(L)))
            return THROWN;

        require (
          Stable* decayed = Decay_If_Unstable(OUT)
        );
        Move_Cell(shovee, decayed);
    }
    else
        Copy_Cell(shovee, right);

    Option(InfixMode) infix_mode;
    if (Is_Frame(shovee)) {
        if (not label)
            label = Frame_Label_Deep(shovee);
        infix_mode = Frame_Infix_Mode(shovee);
    }
    else {
        panic (  // used to allow shoving into set-words, but... [1]
            "SHOVE's immediate right must be FRAME! at this time"
        );
    }

    Fetch_Next_In_Feed(L->feed);

  //=//// PROCESS LITERALLY-TAKEN LEFT FOR PARAMETER CONVENTION ///////////=//
  //
  // 1. Because the SHOVE operator takes the left hand side as a hard literal,
  //    evaluating that and shoving into a right hand infix function will
  //    out-prioritize an infix operation's completion on the left:
  //
  //        >> 1 + (1 + 1) * 3
  //        == 9  ; e.g. (1 + (1 + 1)) * 3
  //
  //        >> 1 + (1 + 1) ->- lib/* 3
  //        == 7  ; e.g. 1 + ((1 + 1) * 3)
  //
  //    So it's not a precise match for evaluative left hand side semantics.
  //    Offering any alternatives or workarounds besides "put your left hand
  //    side in a group" is more complicated than it's possibly worth.
  //
  // 2. It's considered a generally bad idea to allow functions to get access
  //    to the binding environment of the callsite.  That interferes with
  //    abstraction, so any binding should

    const Param* param = First_Unspecialized_Param(
        nullptr, Frame_Phase(shovee)
    );
    ParamClass pclass = Parameter_Class(param);

    switch (Parameter_Class(param)) {
      case PARAMCLASS_NORMAL:  // we can't *quite* match evaluative infix [1]
      case PARAMCLASS_META: {
        Flags flags = LEVEL_MASK_NONE;
        if (Eval_Element_Core_Throws(OUT, flags, left, Level_Binding(L)))
            return THROWN;
        if (pclass == PARAMCLASS_NORMAL) {
            require (
              Decay_If_Unstable(OUT)
            );
        }
        else {
            // The infix fulfillment code will Lift_Cell() OUT
        }
        break; }

      case PARAMCLASS_LITERAL:  // cheat and do something usermode can't ATM [2]
        Copy_Cell_May_Bind(OUT, left, Level_Binding(L));
        break;

      case PARAMCLASS_SOFT:  // !!! can we trust infix to just do this part?
        Copy_Cell_May_Bind(OUT, left, Level_Binding(L));
        break;

      default:
        assert(false);
        break;
    }

  //=//// DISPATCH WITH FIRST ARG IN OUT SLOT /////////////////////////////=//
  //
  // 1. This uses the infix mechanic regardless of whether the function we are
  //    shoving into is infix or not.  It's the easiest way to get the
  //    argument into the first slot of the function.
  //
  // 2. While the evaluator state may be geared to running infix parameter
  //    acquisition, we still pass in a flag to Begin_Action() so that it
  //    knows whether it was infix or not.  This makes a difference, e.g.:
  //
  //        >> 1 + 2 ->- negate * 3
  //

    Flags flags = FLAG_STATE_BYTE(ST_ACTION_INITIAL_ENTRY_INFIX)
        | LEVEL_FLAG_DEBUG_STATE_0_OUT_NOT_ERASED_OK;  // [1]

    require (
      Level* sub = Make_Level(&Action_Executor, level_->feed, flags)
    );
    Push_Level(sub);
    require (
      Push_Action(sub, shovee, infix_mode)  // know if it's infix [2]
    );
    dont(Erase_Cell(OUT));  // infix wants OUT, LEVEL_STATE_BYTE not STATE_0
    return DELEGATE_SUBLEVEL;
}


//
//  /evaluate: native [
//
//  "Run a list through the evaluator iteratively, or take a single step"
//
//      return: [
//          any-value?              "Evaluation product"
//          ~(block! any-value?)~   "[position product] pack if :STEP"  ; [1]
//      ]
//      value [
//          block!  "always 'void suppression' semantics, :STEP ok"
//          fence!  "WRAP semantics, produces BLOCK!, :STEP ok"
//          group!  "must eval to end, only suppress voids after value seen"
//          frame!  "invoke the frame (no arguments, see RUN and APPLY)"
//          error!  "panic on the error (prefer PANIC)"
//          varargs!  "simulates as if BLOCK! is being executed"
//      ]
//      :step "Do one step of evaluation (return null position if at tail)"
//  ]
//
DECLARE_NATIVE(EVALUATE)  // synonym as EVAL in mezzanine
//
// 1. When operating stepwise, the primary result shifts to be the position,
//    to be more useful for knowing if there are more steps to take.  It also
//    helps prevent misunderstandings when the first value of a multi-return
//    cannot itself be a multi-return pack:
//
//      https://forum.rebol.info/t/re-imagining-eval-next/767
//
// 2. PANIC is the preferred operation for raising divergent errors, as it has
//    a natural behavior for blocks passed to construct readable messages and
//    (PANIC X) more clearly communicates a panic than (EVAL X).  But EVAL of
//    a FAILURE! would have to panic anyway, so it might as well use the one
//    it is given.
//
// 3. It might seem that since EVAL [] has an answer (VOID! or HEAVY VOID
//    depending on the call), that EVAL:STEP [] should also have an answer...
//
//    *BUT* in practice, there's a dummy step at the end of every enumeration,
//    e.g. EVAL [1 + 2 10 + 20] goes through three steps, where the third step
//    is a termination signal with no synthesized product.  The null return
//    value signals this termination.
{
    INCLUDE_PARAMS_OF_EVALUATE;

    Element* source = Element_ARG(VALUE);

    enum {
        ST_EVALUATE_INITIAL_ENTRY = STATE_0,
        ST_EVALUATE_SINGLE_STEPPING,
        ST_EVALUATE_RUNNING_TO_END
    };

    switch (STATE) {
      case ST_EVALUATE_INITIAL_ENTRY: {
        if (Is_Fence(source)) {  // BLOCKWRAP semantics
            const Element* tail;
            const Element* at = List_At(&tail, source);
            VarList* parent = nullptr;

            VarList* varlist = Make_Varlist_Detect_Managed(
                COLLECT_ONLY_SET_WORDS,
                HEART_OBJECT,  // !!! Presume object?
                at,
                tail,
                parent
            );
            Tweak_Link_Inherit_Bind(varlist, Cell_Binding(source));
            Tweak_Cell_Binding(source, varlist);
            Tweak_Cell_Type_Matching_Heart(source, HEART_BLOCK);

            Remember_Cell_Is_Lifeguard(source);  // may be only reference!
            goto initial_entry_list;
        }

        Remember_Cell_Is_Lifeguard(source);  // may be only reference!

        if (Is_Block(source) or Is_Group(source))
            goto initial_entry_list;

        if (Is_Frame(source))
            goto initial_entry_frame;

        if (Is_Varargs(source))
            goto initial_entry_varargs;

        assert(Is_Error(source));
        panic (source); }  // would panic anyway [2]

      case ST_EVALUATE_SINGLE_STEPPING:
        goto single_step_result_in_subout;

      default: assert(false);
    }

  initial_entry_list: {  /////////////////////////////////////////////////////

  // 1. EVAL effectively has two modes of operation:
  //
  //    * "transparent" mode like how GROUP! works, where `(expr)` and `expr`
  //      behave the same, at the cost of having distinct behavior for all
  //      steps producing VOID! up until the first non-VOID! value.  (No
  //      need to use the `^` operator in those initial steps.)
  //
  //    * "regimented" mode like how `eval block` is expected to work, where
  //      every step has the same "afraid of voids" behavior, even before
  //      the first non-VOID! value is seen.  This enables simulating the
  //      answer of a full EVAL using just sequential EVAL:STEP calls, and
  //      just throwing away any voids.
  //
  //    To understand why these are different, consider:
  //
  //        eval:step [eval [comment "hi"] ...]    ; must make HEAVY VOID
  //        eval:step [^ eval [comment "hi"] ...]  ; must make VOID!
  //
  //    By contrast, you wouldn't want `void? (eval [^ comment "hi"])` to be
  //    false.  It has the same answer as `void? eval [^ comment "hi"]` which
  //    is true.  Merely parenthesizing a single expression isn't expected to
  //    change what it produces.
  //
  //    We could ignore the datatype of the input list and use a refinement
  //    to allow you to use either mode with any list type.  But that would
  //    require coming up with a name...and also wouldn't draw attention to
  //    the *reason* the modes are distinct, and specially fit to their types.
  //    This increases the odds that people will use the right evaluation.

    Flags flags = LEVEL_MASK_NONE;

    if (Is_Block(source))
        flags |= LEVEL_FLAG_VANISHABLE_VOIDS_ONLY;  // consistent EVAL:STEP [1]
    else {
        assert(Is_Group(source));
        if (ARG(STEP))
            panic (
                ":STEP only BLOCK!s in EVALUATE (use AS BLOCK! if intentional)"
            );
    }

    require (
      Level* sub = Make_Level_At(
        ARG(STEP) ? &Stepper_Executor : &Evaluator_Executor,
        source,  // all lists treated the same [1]
        flags
    ));
    Push_Level(sub);

    if (not ARG(STEP))  // plain evaluation to end, maybe void/none
        return DELEGATE_SUBLEVEL;

    if (Is_Level_At_End(sub)) {
        Drop_Level(sub);
        return NULL_OUT;
    }

    STATE = ST_EVALUATE_SINGLE_STEPPING;
    return CONTINUE_SUBLEVEL;

} initial_entry_frame: { /////////////////////////////////////////////////////

    // 1. It's an open question of whether something like a BLOCK! is a good
    //    enough encoder of the evaluator state to be the result of an
    //    operation like EVAL:STEP, or if something like a FRAME! would be
    //    a better way to abstract things like "accumulated LETs".  It may
    //    evolve that EVAL:STEP on a BLOCK! actually produces a FRAME!...

    if (ARG(STEP))  // !!! may be legal (or mandatory) in the future [1]
        panic (":STEP not implemented for FRAME! in EVALUATE");

    if (Not_Base_Readable(CELL_FRAME_PAYLOAD_1_PHASE(source)))
        panic (Error_Series_Data_Freed_Raw());

    Option(const Value*) with = nullptr;
    Push_Frame_Continuation(
        LEVEL_MASK_NONE,
        source,
        with
    );
    return DELEGATE_SUBLEVEL;

} initial_entry_varargs: { ///////////////////////////////////////////////////

    // 1. We can execute the array, but we must "consume" elements out of it
    //    (e.g. advance the index shared across all instances)
    //
    //    !!! If any VARARGS! op does not honor the "locked" flag on the
    //    array during execution, there will be problems if it is TAKE'n
    //    or EVAL'd while this operation is in progress.
    //
    // 2. A BLOCK! varargs doesn't technically need to "go bad" on a throw,
    //    since the block is still around.  But a FRAME! varargs does.
    //
    // 3. By definition, we are in the middle of a function call in the level
    //    the varargs came from.  It's still on the stack, and we don't want
    //    to disrupt its state.  Use a sublevel.

    if (ARG(STEP))
        panic (":STEP not implemented for VARARGS! in EVALUATE");

    Element* position;
    if (Is_Block_Style_Varargs(&position, source)) {  // must consume [1]
        if (Eval_Any_List_At_Throws(OUT, position, SPECIFIED)) {
            Init_Unreadable(position);  // "goes bad" for consistency [2]
            return THROWN;
        }

        Erase_Cell(position); // convention for shared data at endpoint

        return BOUNCE_OUT;
    }

    Level* L;
    if (not Is_Level_Style_Varargs_May_Panic(&L, source))
        crash (source); // Frame is the only other type

    if (Is_Level_At_End(L))
        return VOID_OUT;

    require (
      Level* sub = Make_Level(  // need evaluation in a sublevel [3]
        &Evaluator_Executor, L->feed, LEVEL_MASK_NONE
    ));
    Push_Level(sub);
    return DELEGATE_SUBLEVEL;

} single_step_result_in_subout: {  ///////////////////////////////////////////

  // 1. There may have been a LET statement in the code.  If there was, we
  //    have to incorporate the binding it added into the reported state
  //    *somehow*.  Right now we add it to the block we give back...this gives
  //    rise to questionable properties, such as if the user goes backward in
  //    the block and were to evaluate it again:
  //
  //      https://forum.rebol.info/t/1496
  //
  //    Right now we can politely ask "don't do that".  But better would
  //    probably be to make EVALUATE return something with more limited
  //    privileges... more like a FRAME!/VARARGS!.

    assert(ARG(STEP));

    Forget_Cell_Was_Lifeguard(source);  // unprotect so we can edit for return

    Context* binding = Level_Binding(SUBLEVEL);
    SERIES_INDEX_UNBOUNDED(source) = Level_Array_Index(SUBLEVEL);  // new index

    Tweak_Cell_Binding(source, binding);  // integrate LETs [1]

    if (ARG(STEP)) {
        Source* pack = Make_Source_Managed(2);
        Set_Flex_Len(pack, 2);
        Copy_Lifted_Cell(Array_At(pack, 0), source);  // pack wants META values
        Copy_Lifted_Cell(Array_At(pack, 1), SUBOUT);  // may be FAILURE!

        Init_Pack(OUT, pack);
    }
    else {
        Copy_Cell(OUT, SUBOUT);
    }

    Drop_Level(SUBLEVEL);

    return BOUNCE_OUT;
}}


//
//  /eval-free: native [
//
//  "Optimized version of EVAL that frees its target frame"
//
//      return: [any-value?]
//      frame [frame!]
//  ]
//
DECLARE_NATIVE(EVAL_FREE)
{
    INCLUDE_PARAMS_OF_EVAL_FREE;

    Stable* frame = ARG(FRAME);

    enum {
        ST_EVAL_FREE_INITIAL_ENTRY = STATE_0,
        ST_EVAL_FREE_EVALUATING
    };

    switch (STATE) {
      case ST_EVAL_FREE_INITIAL_ENTRY: goto initial_entry;
      case ST_EVAL_FREE_EVALUATING: goto result_in_subout;
      default: assert(false);
    }

  initial_entry: { ///////////////////////////////////////////////////////////

    if (Not_Base_Readable(CELL_FRAME_PAYLOAD_1_PHASE(frame)))
        panic (Error_Series_Data_Freed_Raw());

    if (Is_Stub_Details(Frame_Phase(frame)))
        panic ("Can't currently EVAL-FREE a Details-based Stub");

    VarList* varlist = Cell_Varlist(frame);

    if (Level_Of_Varlist_If_Running(varlist))
        panic ("Use REDO to restart a running FRAME! (not EVAL-FREE)");

    require (
      Level* L = Make_End_Level(
        &Action_Executor,
        FLAG_STATE_BYTE(ST_ACTION_TYPECHECKING)
    ));
    Push_Level(L);

    Set_Action_Level_Label(L, Frame_Label_Deep(frame));

    L->varlist = raw_cast(ParamList*, varlist);
    L->rootvar = Rootvar_Of_Varlist(varlist);
    if (MISC_VARLIST_ADJUNCT(varlist) != nullptr)  // might have adjunct
        assert(Get_Stub_Flag(varlist, MISC_NEEDS_MARK));
    Clear_Stub_Flag(varlist, MISC_NEEDS_MARK);
    Tweak_Misc_Runlevel(varlist, L);  // wipes out any adjunct

    Phase* phase = Level_Phase(L);
    assert(phase == Frame_Phase(
        Phase_Archetype(cast(ParamList*, varlist)))
    );
    Tweak_Level_Coupling(L, Frame_Coupling(frame));

    L->u.action.original = phase;

    L->u.action.key = Phase_Keys(&L->u.action.key, phase);
    L->u.action.param = Phase_Params_Head(phase);
    L->u.action.arg = L->rootvar + 1;

    Begin_Action(L, PREFIX_0);

    STATE = ST_EVAL_FREE_EVALUATING;
    return CONTINUE_SUBLEVEL;

} result_in_subout: { ////////////////////////////////////////////////////////

    Copy_Cell(OUT, SUBOUT);
    Drop_Level(SUBLEVEL);

    Diminish_Stub(Frame_Phase(frame));  // the "FREE" of EVAL-FREE

    return BOUNCE_OUT;
}}


//
//  /applique: native [
//
//  "Invoke an ACTION! with all required arguments specified"
//
//      return: [any-value?]
//      operation [frame!]
//      def "Frame definition block (will be bound and evaluated)"
//          [block!]
//      {frame}  ; GC-safe cell for frame
//  ]
//
DECLARE_NATIVE(APPLIQUE)
//
// 1. Make a FRAME! for the ACTION!, weaving in the ordered refinements
//    collected on the stack (if any).  Any refinements that are used in any
//    specialization level will be pushed as well, which makes them out
//    prioritize (e.g. higher-ordered) than any used in a PATH! that were
//    pushed during the Get of the ACTION!.
{
    INCLUDE_PARAMS_OF_APPLIQUE;

    Element* op = ARG(OPERATION);
    Element* def = Element_ARG(DEF);

    enum {
        ST_APPLIQUE_INITIAL_ENTRY = STATE_0,
        ST_APPLIQUE_RUNNING_DEF_BLOCK
    };

    switch (STATE) {
      case ST_APPLIQUE_INITIAL_ENTRY :
        goto initial_entry;

      case ST_APPLIQUE_RUNNING_DEF_BLOCK :
        goto definition_result_in_spare;

      default: assert(false);
    }

  initial_entry: {  //////////////////////////////////////////////////////////

    ParamList* exemplar = Make_Varlist_For_Action_Push_Partials(  // [1]
        op,
        STACK_BASE,  // lowest_stackindex of refinements to weave in
        nullptr  // no binder needed
    );
    Manage_Stub(exemplar);
    Init_Frame_Core(
        LOCAL(FRAME),
        exemplar,
        Frame_Lens_Or_Label(op),
        Frame_Coupling(op)
    );

    Drop_Data_Stack_To(STACK_BASE);  // refinement order unimportant

    require (
      Use* use = Alloc_Use_Inherits(List_Binding(def))
    );
    Copy_Cell(Stub_Cell(use), Element_LOCAL(FRAME));

    Tweak_Cell_Binding(def, use);

    STATE = ST_APPLIQUE_RUNNING_DEF_BLOCK;
    return CONTINUE(def);  // first run block bound to frame

} definition_result_in_spare: {  /////////////////////////////////////////////

    UNUSED(SUBOUT);
    Drop_Level(SUBLEVEL);

    return DELEGATE(Element_LOCAL(FRAME));  // now run the frame
}}


//
//  Native_Frame_Filler_Core: C
//
// This extracts the code for turning a BLOCK! into a partially (or fully)
// filled FRAME!.  It's shared between SPECIALIZE and APPLY.
//
Bounce Native_Frame_Filler_Core(Level* level_)
{
    INCLUDE_PARAMS_OF_APPLY;

    Value* op = LOCAL(OPERATION);
    assert(
        Is_Possibly_Unstable_Value_Frame(op)  // APPLY's expectation
        or Is_Action(op)  // loosen requirement for other callers
    );

    Element* args = Element_ARG(ARGS);

    Element* frame;
    Stable* iterator;  // HANDLE! or NULLED (once initialized)

    Slot* slot;  // may come from evars iterator or found by index
    const Param* param;  // (same)

    assert(STATE != STATE_0);  // actual initial entry is in caller

    if (STATE != ST_FRAME_FILLER_MIN)
        goto not_initial_entry;

  initial_entry: {  //////////////////////////////////////////////////////////

  // 1. Make a FRAME! for the ACTION!, weaving in the ordered refinements
  //    collected on the stack (if any).  Any refinements that are used in any
  //    specialization level will be pushed, which makes them out-prioritize
  //    (e.g. higher-ordered) than any used in a CHAIN! that were pushed
  //    during the Get of the ACTION!.
  //
  // 2. Binders cannot be held across evaluations at this time.  Do slow
  //    lookups for refinements, but this is something that needs rethinking.

    ParamList* exemplar = Make_Varlist_For_Action_Push_Partials(  // [1]
        op,
        STACK_BASE,  // lowest_stackindex of refinements to weave in
        nullptr  // doesn't use a Binder [2]
    );
    Manage_Stub(exemplar); // Putting into a frame
    frame = Init_Frame(
        LOCAL(FRAME),
        exemplar,
        Frame_Label(op),  // label means no lens (we don't need to see locals)
        Frame_Coupling(op)
    );
    Remember_Cell_Is_Lifeguard(frame);

    Drop_Data_Stack_To(STACK_BASE);  // partials ordering unimportant

    require (
      Level* L = Make_Level_At(
        &Stepper_Executor,
        args,
        LEVEL_MASK_NONE
    ));
    Push_Level(L);

    require (
      EVARS *e = Alloc_On_Heap(EVARS)
    );
    Init_Evars(e, frame);

    iterator = Init_Handle_Cdata(LOCAL(ITERATOR), e, sizeof(EVARS));
    STATE = ST_FRAME_FILLER_INITIALIZED_ITERATOR;
    Enable_Dispatcher_Catching_Of_Throws(LEVEL);  // finalize_maybe_throwing

    goto handle_next_item;

} not_initial_entry: { ///////////////////////////////////////////////////////

    // After the initial entry, we can take for granted that the FRAME and
    // ITERATOR locals are initialized.

    frame = Element_LOCAL(FRAME);
    iterator = Stable_LOCAL(ITERATOR);

    switch (STATE) {
      case ST_FRAME_FILLER_INITIALIZED_ITERATOR:
        assert(Is_Throwing_Panic(LEVEL));  // this dispatcher panic()'d
        goto finalize_maybe_throwing;

      case ST_FRAME_FILLER_LABELED_EVAL_STEP:
        if (THROWING)
            goto finalize_maybe_throwing;
        goto labeled_step_result_in_subout;

      case ST_FRAME_FILLER_UNLABELED_EVAL_STEP:
        if (THROWING)
            goto finalize_maybe_throwing;
        if (Is_Null(iterator)) {
            assert(ARG(RELAX));
            goto handle_next_item;
        }
        goto unlabeled_step_result_in_subout;

      default : assert(false);
    }

} handle_next_item: {  ///////////////////////////////////////////////////////

    Level* L = SUBLEVEL;

    if (Is_Level_At_End(L))
        goto finalize_maybe_throwing;

    const Element* at = At_Level(L);

    if (Is_Blank(at)) {  // ","
        Fetch_Next_In_Feed(L->feed);
        goto handle_next_item;
    }

  #if RUNTIME_CHECKS
    Corrupt_If_Needful(param);
  #endif

    Option(SingleHeart) single;
    if (
        not Is_Chain(at)
        or not (single = Try_Get_Sequence_Singleheart(at))
        or not (Singleheart_Has_Trailing_Blank(unwrap single))
    ){
        if (Is_Null(iterator))
            goto handle_discarded_item;

        goto handle_unlabeled_item;
    }

  handle_labeled_item: {  // REFINEMENT: names next arg

  // 1. We could do (negate // [('number): 10]) or (negate // [1: 10]) etc.
  //    Not a priority at the moment--higher priority is to share this code
  //    with SPECIALIZE.
  //
  // 2. Two argument-name labels in a row is not legal...treat it like the
  //    next refinement is reaching a comma or end of block.  (Though this
  //    could be treated as an <end> case?)

    if (single != TRAILING_BLANK_AND(WORD))  // more possibilities later [1]
        panic ("Only WORD!: labels handled in APPLY at this time");

    STATE = ST_FRAME_FILLER_LABELED_EVAL_STEP;

    const Symbol* symbol = Word_Symbol(At_Level(L));

    Option(Ordinal) n = Find_Symbol_In_Context(frame, symbol, false);
    if (not n)
        panic (Error_Bad_Parameter_Raw(at));

    slot = Varlist_Slot(Cell_Varlist(frame), unwrap n);
    param = Phase_Param(Frame_Phase(op), unwrap n);

    if (not Is_Cell_A_Bedrock_Hole(slot))
        panic (Error_Bad_Parameter_Raw(at));

    Sink(Stable) lookback = SCRATCH;  // for error
    Copy_Cell(lookback, At_Level(L));
    Fetch_Next_In_Feed(L->feed);
    at = Try_At_Level(L);

    if (at == nullptr or Is_Blank(at))  // ","
        panic (Error_Need_Non_End_Raw(lookback));

    if (  // catch e.g. DUP: LINE: [2]
        Is_Chain(at)
        and (single = Try_Get_Sequence_Singleheart(at))
        and Singleheart_Has_Trailing_Blank(unwrap single)
    ){
        panic (Error_Need_Non_End_Raw(lookback));
    }

    Init_Integer(LOCAL(INDEX), unwrap n);
    goto eval_step_maybe_labeled;

}} handle_unlabeled_item: { //////////////////////////////////////////////////

    STATE = ST_FRAME_FILLER_UNLABELED_EVAL_STEP;

    EVARS *e = Cell_Handle_Pointer(EVARS, iterator);

    while (true) {
        if (not Try_Advance_Evars(e)) {
            if (not ARG(RELAX))
                panic (Error_Apply_Too_Many_Raw());

            Shutdown_Evars(e);
            Free_Memory(EVARS, e);
            Init_Null(iterator);
            param = nullptr;  // we're throwing away the evaluated product
            break;
        }

        if (Get_Parameter_Flag(e->param, REFINEMENT))
            continue;

        if (Is_Cell_A_Bedrock_Hole(e->slot)) {
            param = e->param;
            break;
        }
    }

    goto eval_step_maybe_labeled;

} handle_discarded_item: { ///////////////////////////////////////////////////

    STATE = ST_FRAME_FILLER_UNLABELED_EVAL_STEP;
    param = nullptr;  // throw away result
    goto eval_step_maybe_labeled;

} eval_step_maybe_labeled: { /////////////////////////////////////////////////

    assert(
        STATE == ST_FRAME_FILLER_LABELED_EVAL_STEP
        or STATE == ST_FRAME_FILLER_UNLABELED_EVAL_STEP
    );

  #if NEEDFUL_DOES_CORRUPTIONS
    assert(not param or Readable_Cell(param));  // nullptr means toss result
  #endif

    Reset_Stepper_Erase_Out(SUBLEVEL);
    return CONTINUE_SUBLEVEL;

} labeled_step_result_in_subout: {  //////////////////////////////////////////

    Index index = VAL_UINT32(ARG(INDEX));

    slot = Varlist_Slot(Cell_Varlist(frame), index);
    param = Phase_Param(Frame_Phase(op), index);

    goto copy_subout_to_var_in_frame;

} unlabeled_step_result_in_subout: {  ////////////////////////////////////////

    EVARS *e = Cell_Handle_Pointer(EVARS, iterator);

    slot = e->slot;
    param = e->param;

    goto copy_subout_to_var_in_frame;

} copy_subout_to_var_in_frame: {  ////////////////////////////////////////////

  // 1. If you were invoking a function normally, then passing in a void to
  //    an <opt> parameter would get turned into a NULL.  The NULL is the
  //    "language of the frame" and what all phases expect to see.  Which
  //    raises the question of if the VOID=>NULL should be done by typechecks
  //    or by frame builders.  It probably makes the most sense if the type
  //    check is willing to do it as a canonization; this is still in flux.

    possibly(raw_cast(Cell*, param) == raw_cast(Cell*, slot));  // !!! really?
    possibly(Get_Parameter_Flag(param, UNDO_OPT));  // our responsibility? [1]
    USED(param);

    Move_Cell(Slot_Init_Hack(slot), SUBOUT);
    goto handle_next_item;

} finalize_maybe_throwing: { /////////////////////////////////////////////////

  // 1. We don't want to get any further notifications of abrupt panics that
  //    happen after we have delegated to the function.  But should DELEGATE()
  //    itself rule that out automatically?  It asserts for now.

    if (Is_Null(iterator))
        assert(ARG(RELAX));
    else {
        EVARS *e = Cell_Handle_Pointer(EVARS, iterator);
        Shutdown_Evars(e);
        Free_Memory(EVARS, e);
        Init_Null(iterator);
    }

    if (THROWING)
        return THROWN;

    Drop_Level(SUBLEVEL);

    Disable_Dispatcher_Catching_Of_Throws(LEVEL);  // no more finalize needed

    return BOUNCE_FRAME_FILLER_FINISHED;
}}


//
//  /apply: native [  ; !!! MUST UPDATE SPEC FOR `//` NATIVE IF CHANGED [1]
//
//  "Invoke an action with all required arguments specified"
//
//      return: [any-value?]
//      operation [frame!]
//      args "Arguments and Refinements, e.g. [arg1 arg2 ref: refine1]"
//          [block!]
//      :relax "Don't worry about too many arguments to the APPLY"
//      {frame index iterator}  ; update `//` native if this changes [1]
//  ]
//
DECLARE_NATIVE(APPLY)
//
// 1. For efficiency, the // infix version of APPLY is native, and just calls
//    right through to the apply code without going through any "Bounce"
//    or specialization code.  But that means the frame pushed for // must
//    be directly usable by APPLY.  Keep them in sync.
{
    INCLUDE_PARAMS_OF_APPLY;

    if (STATE == STATE_0)
        STATE = ST_FRAME_FILLER_MIN;
    else
        assert(STATE >= ST_FRAME_FILLER_MIN and STATE <= ST_FRAME_FILLER_MAX);

    Bounce b = Native_Frame_Filler_Core(LEVEL);
    if (b != BOUNCE_FRAME_FILLER_FINISHED) {
        possibly(THROWING);
        return b;
    }

    return DELEGATE(Element_LOCAL(FRAME));
}


//
//  //: infix native [  ; !!! MUST UPDATE SPEC FOR APPLY NATIVE IF CHANGED [1]
//
//  "Infix version of APPLY with name of thing to apply literally on left"
//
//      return: [any-value?]
//      @(operation) [word! tuple! chain! path! frame! action!]
//      args "Arguments and Refinements, e.g. [arg1 arg2 :ref refine1]"
//          [block!]
//      :relax "Don't worry about too many arguments to the APPLY"
//      {frame index iterator}  ; need frame compatibility with APPLY [1]
//  ]
//
DECLARE_NATIVE(_S_S)  // [_s]lash [_s]lash (see TO-C-NAME)
//
// 1. See notes on APPLY for the required frame compatibility.
{
    INCLUDE_PARAMS_OF_APPLY;  // needs to be frame-compatible [1]

    enum {
        ST__S_S_INITIAL_ENTRY = STATE_0,

        ST__S_S_MIN_RESERVED = ST_FRAME_FILLER_MIN,
        ST__S_S_MAX_RESERVED = ST_FRAME_FILLER_MAX,

        ST__S_S_GETTING_OPERATION  // not used as a continuation yet
    };

    switch (STATE) {
      case ST__S_S_INITIAL_ENTRY: goto initial_entry;
      default:
        assert(STATE >= ST_FRAME_FILLER_MIN and STATE <= ST_FRAME_FILLER_MAX);
        goto delegate_to_frame_filler;
    }

  initial_entry: {

    Element* operation = ARG(OPERATION);

    STATE = ST__S_S_GETTING_OPERATION;  // will be necessary in the future...

    heeded (Copy_Cell(SCRATCH, operation));
    heeded (Corrupt_Cell_If_Needful(SPARE));

    require (
      Meta_Get_Var(
        OUT,
        NO_STEPS,
        operation,
        SPECIFIED
      )
    );

    if (Is_Action(OUT)) {
        Copy_Plain_Cell(ARG(OPERATION), OUT);  // APPLY expects FRAME!
    }
    else {
        require (
          Stable* stable_out = Decay_If_Unstable(OUT)
        );
        if (not Is_Frame(stable_out))
            panic (Error_Bad_Value(stable_out));

        Copy_Cell(ARG(OPERATION), As_Element(stable_out));
    }

} reset_level_for_frame_filler: {

  // Clear out cells we used for temporary storage.

    assert(Not_Cell_Erased(SPARE));
    Erase_Cell(SPARE);
    assert(Not_Cell_Erased(OUT));
    Erase_Cell(OUT);
    assert(Not_Cell_Erased(SCRATCH));
    Erase_Cell(SCRATCH);

    STATE = ST_FRAME_FILLER_MIN;

    goto delegate_to_frame_filler;

} delegate_to_frame_filler: { ////////////////////////////////////////////////

  // Once the operator has finished doing its prep work, we tunnel through
  // to APPLY for whatever it would do, reusing the same frame.

    Bounce b = Native_Frame_Filler_Core(LEVEL);
    if (b != BOUNCE_FRAME_FILLER_FINISHED) {
        possibly(THROWING);
        return b;
    }

    return DELEGATE(Element_LOCAL(FRAME));
}}


// From %c-eval.c -- decide if this should be shared or otherwise.
//
#define Make_Action_Sublevel(parent) \
    Make_Level(&Action_Executor, (parent)->feed, LEVEL_MASK_NONE)



//
//  /run: native [
//
//  "Invoke code inline as if it had been invoked via a WORD!"
//
//      return: [any-value?]
//      frame [frame!]
//      args [any-stable? <variadic>]
//  ]
//
DECLARE_NATIVE(RUN)
{
    INCLUDE_PARAMS_OF_RUN;

    Stable* action = ARG(FRAME);
    UNUSED(ARG(ARGS));  // uses internal mechanisms to act variadic

    require (
      Level* sub = Make_Action_Sublevel(level_)
    );
    Push_Level(sub);
    require (
      Push_Action(sub, action, PREFIX_0)
    );
    return DELEGATE_SUBLEVEL;
}
