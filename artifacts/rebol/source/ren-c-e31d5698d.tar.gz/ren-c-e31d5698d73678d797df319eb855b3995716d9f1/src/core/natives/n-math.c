//
//  file: %n-math.c
//  summary: "native functions for math"
//  section: natives
//  project: "Rebol 3 Interpreter and Run-time (Ren-C branch)"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012 REBOL Technologies
// Copyright 2012-2017 Ren-C Open Source Contributors
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information.
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//
// See also: the numeric datatypes
//

#include "sys-core.h"

#include <math.h>
#include <float.h>

#define LOG2    0.6931471805599453
#define EPS     2.718281828459045235360287471

#ifndef PI
    #define PI 3.14159265358979323846E0
#endif

#ifndef DBL_EPSILON
    #define DBL_EPSILON 2.2204460492503131E-16
#endif

#define AS_DECIMAL(n) (Is_Integer(n) ? (REBDEC)VAL_INT64(n) : VAL_DECIMAL(n))


//
//  /negate: pure native:generic [
//
//  "Changes the sign of a number (see COMPLEMENT for inversion of sets)"
//
//      return: [any-number? pair! time!]
//      value [any-number? pair! time!]
//  ]
//
DECLARE_NATIVE(NEGATE)
{
    INCLUDE_PARAMS_OF_NEGATE;

    Element* v = Element_ARG(VALUE);
    return Dispatch_Generic(NEGATE, v, LEVEL);
}


//
//  /add: pure native:generic [
//
//  "Returns the addition of two values"
//
//      return: [char? any-scalar? date!]
//      value1 [char? any-scalar? date!]
//      value2 [char? any-scalar? date!]
//  ]
//
DECLARE_NATIVE(ADD)
//
// 1. See comments on Is_Blob_And_Is_Zero() about #{00} as a NUL? state for
//    the CHAR? type constraint.  We preserve (NUL + 65) -> #A and
//    (#A - NUL) -> 0 partially because they were in the tests, but also
//    because it may find use in generalized code.  But we don't dispatch to
//    BLOB! or RUNE! to handle SYM_ADD for this case, instead localizing it
//    here so it's easier to reason about or delete.
{
    INCLUDE_PARAMS_OF_ADD;

    Element* e1 = Element_ARG(VALUE1);
    Element* e2 = Element_ARG(VALUE2);

    if (Is_Blob_And_Is_Zero(e1)) {  // localize NUL to ADD native [1]
        if (not Is_Integer(e2))
            panic ("Can only add INTEGER! to NUL #{00} state");
        REBINT i = VAL_INT32(e2);
        if (i < 0)
            panic (Error_Codepoint_Negative_Raw());
        trap (
          Init_Single_Codepoint_Rune(OUT, i)
        );
        return BOUNCE_OUT;
    }

    if (Is_Blob_And_Is_Zero(e2)) {  // localize NUL to ADD native [1]
        if (not Is_Integer(e1))
            panic ("Can only add INTEGER! to NUL #{00} state");
        REBINT i = VAL_INT32(e1);
        if (i < 0)
            panic (Error_Codepoint_Negative_Raw());
        trap (
          Init_Single_Codepoint_Rune(OUT, i)
        );
        return BOUNCE_OUT;
    }

    return Old_Dispatch_Generic(ADD, e1, LEVEL);
}


//
//  /subtract: pure native:generic [
//
//  "Returns the second value subtracted from the first"
//
//      return: [char? any-scalar? date! ]
//      value1 [char? any-scalar? date!]
//      value2 [char? any-scalar? date!]
//  ]
//
DECLARE_NATIVE(SUBTRACT)
//
// 1. Preservation of R3-Alpha's NUL math behaviors is narrow, isolated here
//    for easy review and/or removal.
{
    INCLUDE_PARAMS_OF_SUBTRACT;

    Element* e1 = Element_ARG(VALUE1);
    Element* e2 = Element_ARG(VALUE2);

    if (Is_Blob_And_Is_Zero(e1)) {  // localize NUL to SUBTRACT native [1]
        if (Is_Blob_And_Is_Zero(e2)) {
            Init_Integer(OUT, 0);
            return BOUNCE_OUT;
        }
        if (Is_Rune_And_Is_Char(e2)) {
            Codepoint c2 = Rune_Known_Single_Codepoint(e2);
            Init_Integer(OUT, i_cast(REBINT, 0) - c2);
            return BOUNCE_OUT;
        }
        return fail (Error_Codepoint_Negative_Raw());
    }

    if (Is_Blob_And_Is_Zero(e2)) {  // localize NUL to SUBTRACT native [1]
        if (Is_Rune_And_Is_Char(e1)) {
            Codepoint c1 = Rune_Known_Single_Codepoint(e1);
            Init_Integer(OUT, c1);
            return BOUNCE_OUT;
        }
        panic ("Only CHAR? can have NUL? #{00} state subtracted");
    }

    return Old_Dispatch_Generic(SUBTRACT, e1, LEVEL);
}


//
//  /multiply: pure native:generic [
//
//  "Returns the second value multiplied by the first"
//
//      return: [char? any-scalar? element?]
//      value1 [char? any-scalar? element?]  ; !!! expand types for DECI!
//      value2 [char? any-scalar? element?]
//  ]
//
DECLARE_NATIVE(MULTIPLY)
//
// 1. Most languages want multiplication to be commutative (exceptions like
//    matrix multiplication do exist, though that likely should be a different
//    operation and reserve MULTIPLY for element-wise multiplication).  To
//    ensure commutativity, we swap the arguments if their heart bytes are
//    not in "canon order".
//
//    (Using the HEARTSIGIL_BYTE as the canon order is a bit of a hack, as the
//    table can be reordered.  But we try to order the types in %types.r
//    such that more complex types come later, so that we dispatch to the
//    more complex type...e.g. multiplying a PAIR! by a DECIMAL! should
//    should dispatch to the PAIR! code.)
{
    INCLUDE_PARAMS_OF_MULTIPLY;

    Element* e1 = Element_ARG(VALUE1);
    Element* e2 = Element_ARG(VALUE2);

    if (
        not Heart_Of(e1)  // left is not an extension type v-- see [1]
        and i_cast(HeartByte, Heart_Of(e1)) < i_cast(HeartByte, Heart_Of(e2))
    ){
        Element* spare = Move_Cell(SPARE, e2);
        Move_Cell(e2, e1);  // ...so move simpler type to be on the right
        Move_Cell(e1, spare);
    }

    return Dispatch_Generic(MULTIPLY, e1, LEVEL);
}


//
//  /divide: pure native:generic [
//
//  "Returns the first value divided by the second"
//
//      return: [char? any-scalar?]
//      value1 [char? any-scalar?]
//      value2 [char? any-scalar?]
//  ]
//
DECLARE_NATIVE(DIVIDE)
{
    INCLUDE_PARAMS_OF_DIVIDE;

    Element* v1 = Element_ARG(VALUE1);
    return Old_Dispatch_Generic(DIVIDE, v1, LEVEL);
}



//
//  /remainder: pure native:generic [
//
//  "Returns the remainder of first value divided by second"
//
//      return: [char? any-scalar?]
//      value1 [char? any-scalar?]
//      value2 [char? any-scalar?]
//  ]
//
DECLARE_NATIVE(REMAINDER)
{
    INCLUDE_PARAMS_OF_REMAINDER;

    Element* v1 = Element_ARG(VALUE1);
    return Old_Dispatch_Generic(REMAINDER, v1, LEVEL);
}


//
//  /power: pure native:generic [
//
//  "Returns the first number raised to the second number"
//
//      return: [any-number?]
//      value [any-number?]
//      exponent [any-number?]
//  ]
//
DECLARE_NATIVE(POWER)
{
    INCLUDE_PARAMS_OF_POWER;

    Element* v = Element_ARG(VALUE);
    return Old_Dispatch_Generic(POWER, v, LEVEL);
}


//
//  /absolute: pure native:generic [
//
//  "Returns the absolute value"
//
//      return: [any-number? pair! time!]
//      value [any-number? pair! time!]
//  ]
//
DECLARE_NATIVE(ABSOLUTE)
{
    INCLUDE_PARAMS_OF_ABSOLUTE;

    Element* v = Element_ARG(VALUE);
    return Dispatch_Generic(ABSOLUTE, v, LEVEL);
}


//
//  /round: pure native:generic [
//
//  "Returns the first number raised to the second number"
//
//      return: [any-number? pair! time!]
//      value [any-number? pair! time!]
//      :to "Return the nearest multiple of the parameter (must be non-zero)"
//          [any-number? time!]
//      :even "Halves round toward even results"
//      :down "Round toward zero, ignoring discarded digits. (truncate)"
//      :half-down "Halves round toward zero"
//      :floor "Round in negative direction"
//      :ceiling "Round in positive direction"
//      :half-ceiling "Halves round in positive direction"
//  ]
//
DECLARE_NATIVE(ROUND)
{
    INCLUDE_PARAMS_OF_ROUND;

    USED(ARG(TO));  // passed through via LEVEL

    Count num_refinements = 0;
    if (ARG(EVEN))
        ++num_refinements;
    if (ARG(DOWN))
        ++num_refinements;
    if (ARG(HALF_DOWN))
        ++num_refinements;
    if (ARG(FLOOR))
        ++num_refinements;
    if (ARG(CEILING))
        ++num_refinements;
    if (ARG(HALF_CEILING))
        ++num_refinements;

    if (num_refinements > 1)
        return fail ("ROUND only accepts one of EVEN, DOWN, HALF-DOWN,"
            " FLOOR, CEILING, or HALF-CEILING refinements");

    Element* elem = Element_ARG(VALUE);
    return Dispatch_Generic(ROUND, elem, LEVEL);
}


//
//  /even?: pure native:generic [
//
//  "Returns OKAY if the number is even"
//
//      return: [logic!]
//      value [integer! time!]
//  ]
//
DECLARE_NATIVE(EVEN_Q)  // Note: ODD? is defined as NOT EVEN?
//
// Narrowed considerably from historical types, but left as a generic as a
// placeholder for further thought:
//
//   https://rebol.metaeducation.com/t/odd-defined-in-terms-of-even/2521
{
    INCLUDE_PARAMS_OF_EVEN_Q;

    Element* v = Element_ARG(VALUE);
    return Dispatch_Generic(EVEN_Q, v, LEVEL);
}


//
//  /randomize: impure native:generic [
//
//  "Seed random number generator"
//
//      return: [trash!]
//      seed "Pass e.g. NOW:TIME:PRECISE for nondeterminism"
//          [plain?]
//  ]
//
DECLARE_NATIVE(RANDOMIZE)
//
// Note: It may not be a great idea to allow randomization on lists, it
// may be the case that there's some kind of "randomize dialect" in which a
// a block specification could be meaningful.  If someone wants to use a
// block as a random seed they could randomize on the mold of it... but
// also we may want to expose the hash of a block for other reasons.
{
    INCLUDE_PARAMS_OF_RANDOMIZE;

    Element* seed = Element_ARG(SEED);
    return Dispatch_Generic(RANDOMIZE, seed, LEVEL);
}


//
//  /random: impure native:generic [
//
//  "Returns random value of the given type, 'zero' to max (see also SHUFFLE)"
//
//      return: [plain?]
//      max "Maximum value of result (inclusive)"
//          [plain?]
//      :secure "Old refinement from R3-Alpha: Review"
//  ]
//
DECLARE_NATIVE(RANDOM)
//
// RANDOM may be a good candidate for a dialect, e.g.:
//
//     random [between 10 and 20 distribution 'normal]
//
// This application opens up now, since RANDOM-PICK is used to pick a random
// item out of a block, and SHUFFLE and SHUFFLE-OF give you shuffled lists.
{
    INCLUDE_PARAMS_OF_RANDOM;

    Element* max = Element_ARG(MAX);
    return Dispatch_Generic(RANDOM, max, LEVEL);
}


//
//  /random-between: impure native:generic [
//
//  "Random value of the given type between min and max (inclusive)"
//
//      return: [element?]
//      min [fundamental?]
//      max [fundamental?]
//      :secure "Old refinement from R3-Alpha: Review"
//  ]
//
DECLARE_NATIVE(RANDOM_BETWEEN)
//
// !!! Should this function make sure the types are comparable, and that max
// is greater than min, before dispatching?  Probably not, that's exppensive.
{
    INCLUDE_PARAMS_OF_RANDOM_BETWEEN;

    Element* min = Element_ARG(MIN);
    Element* max = Element_ARG(MAX);
    USED(ARG(SECURE));  // passed through via LEVEL

    if (not Have_Same_Type(min, max))
        return fail ("RANDOM-BETWEEN requires MIN and MAX of same type");

    return Dispatch_Generic(RANDOM_BETWEEN, min, LEVEL);
}


//
//  /random-pick: impure native:generic [
//
//  "Picks an arbitrary member out of a collection (see also SHUFFLE, RANDOM)"
//
//      return: [
//          element?
//          failure! "if empty collection (use TRY RANDOM-PICK to get NULL)"
//      ]
//      collection [fundamental?]
//      :secure "Old refinement from R3-Alpha: Review"
//  ]
//
DECLARE_NATIVE(RANDOM_PICK)
//
// While RANDOM_PICK is written as its own generic that can be optimized, for
// most types it can easily be implemented based on RANDOM + LENGTH_OF + PICK.
// The choice to have specialized implementations for ANY-LIST? and BLOB?
// and ANY-STRING? are mostly based on history.  However there was no code
// for RUNE!, and the details of cells that don't have nodes make it such
// that it makes more sense to avoid the pitfallls of reimplementing all that.
//
// It may be that the RANDOM_PICK specializations should be deleted where
// they are not necessary, to cut down on the total amount of code and
// potential for error.
{
    INCLUDE_PARAMS_OF_RANDOM_PICK;

    Element* collection = Element_ARG(COLLECTION);

    Bounce bounce;
    if (Try_Dispatch_Generic(&bounce, RANDOM_PICK, collection, LEVEL))
        return bounce;

    const Stable* datatype = Datatype_Of_Builtin_Fundamental(collection);
    if (not Handles_Generic(LENGTH_OF, datatype))
        panic (UNHANDLED);

    Quote_Cell(collection);
    return rebDelegate(
        CANON(PICK), collection, CANON(RANDOM), CANON(LENGTH_OF), collection
    );
}


//
//  /shuffle: impure native:generic [
//
//  "Randomly shuffle the contents of a series in place (see also RANDOM)"
//
//      return: [element?]
//      series [fundamental?]
//      :secure "Old refinement from R3-Alpha: Review"
//  ]
//
DECLARE_NATIVE(SHUFFLE)
{
    INCLUDE_PARAMS_OF_SHUFFLE;

    Element* series = Element_ARG(SERIES);
    return Dispatch_Generic(SHUFFLE, series, LEVEL);
}


//
//  /shuffle-of: impure native:generic [
//
//  "Give back a shuffled copy of the argument (can be immutable)"
//
//      return: [element?]
//      value [fundamental?]
//      :secure "Returns a cryptographically secure random number"
//      :part "Limits to a given length or position"
//          [any-number? any-series?]
//  ]
//
DECLARE_NATIVE(SHUFFLE_OF)
{
    INCLUDE_PARAMS_OF_SHUFFLE_OF;

    Element* elem = cast(Element*, ARG(VALUE));
    USED(ARG(SECURE));  // other args get passed via LEVEL
    USED(ARG(PART));

    Bounce bounce;
    if (Try_Dispatch_Generic(&bounce, SHUFFLE_OF, elem, LEVEL))
        return bounce;

    const Stable* datatype = Datatype_Of_Fundamental(elem);
    if (
        not Handles_Generic(SHUFFLE, datatype)
        or not Handles_Generic(COPY, datatype)
    ){
        panic (UNHANDLED);
    }

    Quote_Cell(elem);
    return rebDelegate(CANON(SHUFFLE), CANON(COPY), elem);
}


//
//  Trig_Value: C
//
// Convert integer arg, if present, to decimal and convert to radians
// if necessary.  Clip ranges for correct REBOL behavior.
//
static REBDEC Trig_Value(
    const Stable* value,
    bool radians,
    SymId which
){
    REBDEC dval = AS_DECIMAL(value);

    if (not radians) {
        /* get dval between -360.0 and 360.0 */
        dval = fmod (dval, 360.0);

        /* get dval between -180.0 and 180.0 */
        if (fabs (dval) > 180.0)
            dval += dval < 0.0 ? 360.0 : -360.0;
        if (which == SYM_TANGENT) {
            /* get dval between -90.0 and 90.0 */
            if (fabs (dval) > 90.0)
                dval += dval < 0.0 ? 180.0 : -180.0;
        } else if (which == SYM_SINE) {
            /* get dval between -90.0 and 90.0 */
            if (fabs (dval) > 90.0)
                dval = (dval < 0.0 ? -180.0 : 180.0) - dval;
        }
        dval = dval * PI / 180.0; // to radians
    }

    return dval;
}


//
//  Arc_Trans: C
//
static Result(None) Arc_Trans(
    Sink(Stable) out,
    const Stable* value,
    bool radians,
    SymId which
){
    REBDEC dval = AS_DECIMAL(value);
    if (which != SYM_TANGENT and (dval < -1 or dval > 1))
        return fail (Error_Overflow_Raw());

    if (which == SYM_SINE)
        dval = asin(dval);
    else if (which == SYM_COSINE)
        dval = acos(dval);
    else {
        assert(which == SYM_TANGENT);
        dval = atan(dval);
    }

    if (not radians)
        dval = dval * 180.0 / PI; // to degrees

    Init_Decimal(out, dval);
    return none;
}


//
//  /cosine: pure native [
//
//  "Returns the trigonometric cosine"
//
//      return: [decimal!]
//      angle [any-number?]
//      :radians "ANGLE is specified in radians (in degrees by default)"
//  ]
//
DECLARE_NATIVE(COSINE)
{
    INCLUDE_PARAMS_OF_COSINE;

    REBDEC dval = cos(Trig_Value(ARG(ANGLE), ARG(RADIANS), SYM_COSINE));
    if (fabs(dval) < DBL_EPSILON)
        dval = 0.0;

    Init_Decimal(OUT, dval);
    return BOUNCE_OUT;
}


//
//  /sine: pure native [
//
//  "Returns the trigonometric sine"
//
//      return: [decimal!]
//      angle [any-number?]
//      :radians "ANGLE is specified in radians (in degrees by default)"
//  ]
//
DECLARE_NATIVE(SINE)
{
    INCLUDE_PARAMS_OF_SINE;

    REBDEC dval = sin(Trig_Value(ARG(ANGLE), ARG(RADIANS), SYM_SINE));
    if (fabs(dval) < DBL_EPSILON)
        dval = 0.0;

    Init_Decimal(OUT, dval);
    return BOUNCE_OUT;
}


//
//  /tangent: pure native [
//
//  "Returns the trigonometric tangent"
//
//      return: [decimal!]
//      angle [any-number?]
//      :radians "ANGLE is specified in radians (in degrees by default)"
//  ]
//
DECLARE_NATIVE(TANGENT)
{
    INCLUDE_PARAMS_OF_TANGENT;

    REBDEC dval = Trig_Value(ARG(ANGLE), ARG(RADIANS), SYM_TANGENT);
    if (Eq_Decimal(fabs(dval), PI / 2.0))
        panic (Error_Overflow_Raw());

    Init_Decimal(OUT, tan(dval));
    return BOUNCE_OUT;
}


//
//  /arccosine: pure native [
//
//  "Returns the trigonometric arccosine"
//
//      return: [decimal!]
//      cosine [any-number?]
//      :radians "Returns result in radians (in degrees by default)"
//  ]
//
DECLARE_NATIVE(ARCCOSINE)
{
    INCLUDE_PARAMS_OF_ARCCOSINE;

    require (
      Arc_Trans(OUT, ARG(COSINE), ARG(RADIANS), SYM_COSINE)
    );
    return BOUNCE_OUT;
}


//
//  /arcsine: pure native [
//
//  "Returns the trigonometric arcsine"
//
//      return: [decimal!]
//      sine [any-number?]
//      :radians "Returns result in radians (in degrees by default)"
//  ]
//
DECLARE_NATIVE(ARCSINE)
{
    INCLUDE_PARAMS_OF_ARCSINE;

    require (
      Arc_Trans(OUT, ARG(SINE), ARG(RADIANS), SYM_SINE)
    );
    return BOUNCE_OUT;
}


//
//  /arctangent: pure native [
//
//  "Returns the trigonometric arctangent"
//
//      return: [decimal!]
//      tangent [any-number?]
//      :radians "Returns result in radians (in degrees by default)"
//  ]
//
DECLARE_NATIVE(ARCTANGENT)
{
    INCLUDE_PARAMS_OF_ARCTANGENT;

    require (
        Arc_Trans(OUT, ARG(TANGENT), ARG(RADIANS), SYM_TANGENT)
    );
    return BOUNCE_OUT;
}


//
//  /exp: pure native [
//
//  "Raises E (the base of natural logarithm) to the power specified"
//
//      return: [decimal!]
//      power [any-number?]
//  ]
//
DECLARE_NATIVE(EXP)
{
    INCLUDE_PARAMS_OF_EXP;

    static REBDEC eps = EPS;
    REBDEC dval = pow(eps, AS_DECIMAL(ARG(POWER)));

    // !!! Check_Overflow(dval);

    Init_Decimal(OUT, dval);
    return BOUNCE_OUT;
}


//
//  /log-10: pure native [
//
//  "Returns the base-10 logarithm"
//
//      return: [decimal!]
//      value [any-number?]
//  ]
//
DECLARE_NATIVE(LOG_10)
{
    INCLUDE_PARAMS_OF_LOG_10;

    REBDEC dval = AS_DECIMAL(ARG(VALUE));
    if (dval <= 0)
        panic (Error_Positive_Raw());

    Init_Decimal(OUT, log10(dval));
    return BOUNCE_OUT;
}


//
//  /log-2: pure native [
//
//  "Return the base-2 logarithm"
//
//      return: [decimal!]
//      value [any-number?]
//  ]
//
DECLARE_NATIVE(LOG_2)
{
    INCLUDE_PARAMS_OF_LOG_2;

    REBDEC dval = AS_DECIMAL(ARG(VALUE));
    if (dval <= 0)
        panic (Error_Positive_Raw());

    Init_Decimal(OUT, log(dval) / LOG2);
    return BOUNCE_OUT;
}


//
//  /log-e: pure native [
//
//  "Returns the natural (base-E) logarithm of the given value"
//
//      return: [decimal!]
//      value [any-number?]
//  ]
//
DECLARE_NATIVE(LOG_E)
{
    INCLUDE_PARAMS_OF_LOG_E;

    REBDEC dval = AS_DECIMAL(ARG(VALUE));
    if (dval <= 0)
        panic (Error_Positive_Raw());

    Init_Decimal(OUT, log(dval));
    return BOUNCE_OUT;
}


//
//  /square-root: pure native [
//
//  "Returns the square root of a number"
//
//      return: [decimal!]
//      value [any-number?]
//  ]
//
DECLARE_NATIVE(SQUARE_ROOT)
{
    INCLUDE_PARAMS_OF_SQUARE_ROOT;

    REBDEC dval = AS_DECIMAL(ARG(VALUE));
    if (dval < 0)
        panic (Error_Positive_Raw());

    Init_Decimal(OUT, sqrt(dval));
    return BOUNCE_OUT;
}


//
//  /vacancy?: pure native [
//
//  "Tells you if default would overwrite a value (TRASH!, NULL?, VOID!)"
//
//      return: [logic!]
//      ^value [any-value?]
//  ]
//
DECLARE_NATIVE(VACANCY_Q)
{
    INCLUDE_PARAMS_OF_VACANCY_Q;

    Value* v = ARG(VALUE);
    if (Any_Void(v) or Is_Trash(v))
        return LOGIC_OUT(true);

    require (
      Stable* stable = Decay_If_Unstable(v)
    );

    return LOGIC_OUT(Is_Null(stable) or Is_None(stable));
}


//=////////////////////////////////////////////////////////////////////////=//
//
//  EQUAL? and LESSER?: BASIS FOR ALL COMPARISONS
//
//=/////////////////////////////////////////////////////////////////////////=//
//
// The way things work in Ren-C are similar to Ord and Eq in Haskell, or how
// C++ standard library sorts solely in terms of operator< and operator==.
//
// So GREATER? is defined as just NOT LESSER? and NOT EQUAL?.
//
// LESSER? is more limited in Ren-C than in R3-Alpha or Red.  You can only
// compare like types, and you can only compare blocks that are element-wise
// comparable.
//
//     >> [1 "a"] < [1 "b"]
//     == ~okay~  ; anti
//
//     >> ["a" 1] < [1 "b"]
//     ** Error: Non-comparable types (e.g. "a" < 1 is nonsensical)
//
// Hence you cannot sort an arbitrary block by the default LESSER? comparator.
// If you want to impose order on non-comparable types, you must use a custom
// comparison function that knows how to compare them.
//


//
//  /equal?: pure native:generic [
//
//  "TRUE if the values are equal"
//
//      return: [logic!]
//      value1 [any-stable?]
//      value2 [any-stable?]
//      :relax "Use less strict comparison rules (e.g. caseless comparison)"
//  ]
//
DECLARE_NATIVE(EQUAL_Q)
{
    INCLUDE_PARAMS_OF_EQUAL_Q;

    bool relax = ARG(RELAX);

    if (not Have_Matching_Lift_Levels(ARG(VALUE1), ARG(VALUE2)))
        return LOGIC_OUT(false);

    Normalize_Cell(ARG(VALUE1));
    Normalize_Cell(ARG(VALUE2));

    Element* v1 = Element_ARG(VALUE1);
    Element* v2 = Element_ARG(VALUE2);

    if (Sigil_Of(v1) != Sigil_Of(v2))
        return LOGIC_OUT(false);

    Clear_Cell_Sigil(v1);
    Clear_Cell_Sigil(v2);

    if (not Have_Same_Type(v1, v2)) {  // !!! need generic "coercibility"
        if (not relax)
            return LOGIC_OUT(false);

        if (Is_Integer(v1) and Is_Decimal(v2))
            Init_Decimal(v1, cast(REBDEC, VAL_INT64(v1)));
        else if (Is_Decimal(v1) and Is_Integer(v2))
            Init_Decimal(v2, cast(REBDEC, VAL_INT64(v2)));
        else
            return LOGIC_OUT(false);
    }

    return Dispatch_Generic(EQUAL_Q, v1, LEVEL);
}


//
//  /lesser?: pure native:generic [
//
//  "TRUE if the first value is less than the second value"
//
//      return: [logic!]
//      value1 [fundamental?]  ; !!! Don't allow antiforms? [1]
//      value2 [fundamental?]
//  ]
//
DECLARE_NATIVE(LESSER_Q)
//
// 1. Although EQUAL? has to allow antiforms, e.g. for (value = null), it's
//    not clear that LESSER? should accept them.
{
    INCLUDE_PARAMS_OF_LESSER_Q;

    Element* v1 = Element_ARG(VALUE1);
    Element* v2 = Element_ARG(VALUE2);

    if (not Have_Matching_Lift_Levels(v1, v2))
        return fail ("Differing lift levels are not comparable");

    Clear_Cell_Quotes_And_Quasi(v1);
    Clear_Cell_Quotes_And_Quasi(v2);

    if (Sigil_Of(v1) != Sigil_Of(v2))
        return fail ("Differing sigils are not comparable");

    Clear_Cell_Sigil(v1);
    Clear_Cell_Sigil(v2);

    if (not Have_Same_Type(v1, v2)) {  // !!! need generic "coercibility"
        if (Is_Integer(v1) and Is_Decimal(v2))
            Init_Decimal(v1, cast(REBDEC, VAL_INT64(v1)));
        else if (Is_Decimal(v1) and Is_Integer(v2))
            Init_Decimal(v2, cast(REBDEC, VAL_INT64(v2)));
        else
            return fail ("Types are not comparable");
    }

    return Dispatch_Generic(LESSER_Q, v1, LEVEL);
}


// We want LESSER? to always give a soft failure through an error antiform, so
// that we can fall back on EQUAL?.  e.g.
//
//    >> [1 -> "a"] < [2 -> "b"]
//    == ~okay~  ; null
//
// Even though -> can't be compared with less than, the equality means
// we let the test go through.
//
IMPLEMENT_GENERIC(LESSER_Q, Any_Element)
{
    INCLUDE_PARAMS_OF_LESSER_Q;

    UNUSED(ARG(VALUE1));
    UNUSED(ARG(VALUE2));

    return fail ("Types are not comparable");
}


//
//  /same?: pure native [
//
//  "TRUE if the values are identical"
//
//      return: [logic!]
//      value1 [any-stable?]
//      value2 [any-stable?]
//  ]
//
DECLARE_NATIVE(SAME_Q)
//
// !!! It's not clear that SAME? should be answering for types like INTEGER!
// or other immediates with the same answer as EQUAL?.  It might should be
// that SAME? only works on things that are references, like series and
// objects, and gives you an error antiform that you can TRY on to then fall
// back on equality if that is meaningful to your situation.
{
    INCLUDE_PARAMS_OF_SAME_Q;

    if (not Have_Matching_Lift_Levels(ARG(VALUE1), ARG(VALUE2)))
        return LOGIC_OUT(false);

    Normalize_Cell(ARG(VALUE1));
    Normalize_Cell(ARG(VALUE2));

    Element* v1 = Element_ARG(VALUE1);
    Element* v2 = Element_ARG(VALUE2);

    if (not Have_Same_Type(v1, v2))
        return LOGIC_OUT(false);  // not "same" value if not same type

    if (Is_Bitset(v1))  // same if binaries are same
        return LOGIC_OUT(VAL_BITSET(v1) == VAL_BITSET(v2));

    if (Any_Series(v1))  // pointers -and- indices must match
        return LOGIC_OUT(
            Cell_Flex(v1) == Cell_Flex(v2)  // v-- permissive w.r.t. index
            and SERIES_INDEX_UNBOUNDED(v1) == SERIES_INDEX_UNBOUNDED(v2)
        );

    if (Any_Context(v1))  // same if varlists match
        return LOGIC_OUT(Cell_Varlist(v1) == Cell_Varlist(v2));

    if (Is_Map(v1))  // same if map pointer matches
        return LOGIC_OUT(VAL_MAP(v1) == VAL_MAP(v2));

    if (Any_Word(v1))  // !!! "same" was spelling -and- binding in R3-Alpha
        return LOGIC_OUT(
            Word_Symbol(v1) == Word_Symbol(v2)
            and Cell_Binding(v1) == Cell_Binding(v2)
        );

    if (Is_Decimal(v1) or Is_Percent(v1)) {
        //
        // !!! R3-Alpha's STRICT-EQUAL? for DECIMAL! did not require *exactly*
        // the same bits, but SAME? did.  :-/
        //
        return LOGIC_OUT(
            0 == memcmp(&VAL_DECIMAL(v1), &VAL_DECIMAL(v2), sizeof(REBDEC))
        );
    }

    Lift_Cell(v1);
    Lift_Cell(v2);
    return rebDelegate(CANON(EQUAL_Q), v1, v2);
}


//
//  /greater?: pure native [
//
//  "TRUE if the first value is greater than the second value"
//
//      return: [logic!]
//      value1 [fundamental?]
//      value2 [fundamental?]
//  ]
//
DECLARE_NATIVE(GREATER_Q)
{
    INCLUDE_PARAMS_OF_GREATER_Q;

    Element* v1 = Element_ARG(VALUE1);
    Element* v2 = Element_ARG(VALUE2);

    Quote_Cell(v1);
    Quote_Cell(v2);

    return rebDelegate(
        "not any [equal?", v1, v2, "lesser?", v1, v2, "]"
    );
}


//
//  /equal-or-lesser?: pure native [
//
//  "TRUE if the first value is equal to or less than the second value"
//
//      return: [logic!]
//      value1 [fundamental?]
//      value2 [fundamental?]
//  ]
//
DECLARE_NATIVE(EQUAL_OR_LESSER_Q)
{
    INCLUDE_PARAMS_OF_EQUAL_OR_LESSER_Q;

    Element* v1 = Element_ARG(VALUE1);
    Element* v2 = Element_ARG(VALUE2);

    Quote_Cell(v1);
    Quote_Cell(v2);

    return rebDelegate(
        "any [equal?", v1, v2, "lesser?", v1, v2, "]"
    );
}


//
//  /greater-or-equal?: pure native [
//
//  "TRUE if the first value is greater than or equal to the second value"
//
//      return: [logic!]
//      value1 [fundamental?]
//      value2 [fundamental?]
//  ]
//
DECLARE_NATIVE(GREATER_OR_EQUAL_Q)
{
    INCLUDE_PARAMS_OF_GREATER_OR_EQUAL_Q;

    Element* v1 = Element_ARG(VALUE1);
    Element* v2 = Element_ARG(VALUE2);

    Quote_Cell(v1);
    Quote_Cell(v2);

    return rebDelegate(
        "any [equal?", v1, v2, "not lesser?", v1, v2, "]"
    );
}


//
//  /maximum: pure native [
//
//  "Returns the greater of the two values"
//
//      return: [any-scalar? date! any-series?]
//      value1 [any-scalar? date! any-series?]
//      value2 [any-scalar? date! any-series?]
//  ]
//
DECLARE_NATIVE(MAXIMUM)
{
    INCLUDE_PARAMS_OF_MAXIMUM;

    Element* v1 = Element_ARG(VALUE1);
    Element* v2 = Element_ARG(VALUE2);

    Quote_Cell(v1);
    Quote_Cell(v2);

    return rebDelegate(
        "either lesser?", v1, v2,
            v2,  // quoted, so acts as "soft quoted branch"
            v1
    );
}


//
//  /minimum: pure native [
//
//  "Returns the lesser of the two values"
//
//      return: [any-scalar? date! any-series?]
//      value1 [any-scalar? date! any-series?]
//      value2 [any-scalar? date! any-series?]
//  ]
//
DECLARE_NATIVE(MINIMUM)
{
    INCLUDE_PARAMS_OF_MINIMUM;

    Element* v1 = Element_ARG(VALUE1);
    Element* v2 = Element_ARG(VALUE2);

    Quote_Cell(v1);
    Quote_Cell(v2);

    return rebDelegate(
        "either lesser?", v1, v2,
            v1,  // quoted, so acts as "soft quoted branch"
            v2
    );
}


//
//  /zeroify: pure native:generic [
//
//  "Zeroed value of the same type and length (1.5 => 1.0, 1.2.3 => 0.0.0)"
//
//     return: [any-element?]
//     example [any-element?]
//  ]
//
DECLARE_NATIVE(ZEROIFY)
{
    INCLUDE_PARAMS_OF_ZEROIFY;

    Element* example = Element_ARG(EXAMPLE);

    return Dispatch_Generic(ZEROIFY, example, LEVEL);
}


//
//  /negative?: pure native [
//
//  "Returns TRUE if the value is negative"
//
//      return: [logic!]
//      value [any-number? time! pair!]
//  ]
//
DECLARE_NATIVE(NEGATIVE_Q)
{
    INCLUDE_PARAMS_OF_NEGATIVE_Q;

    Element* v = Element_ARG(VALUE);

    Quote_Cell(v);  // not necessary for scalars, but futureproof it
    return rebDelegate(CANON(LESSER_Q), v, CANON(ZEROIFY), v);
}


//
//  /positive?: pure native [
//
//  "Returns TRUE if the value is positive"
//
//      return: [logic!]
//      value [any-number? time! pair!]
//  ]
//
DECLARE_NATIVE(POSITIVE_Q)
{
    INCLUDE_PARAMS_OF_POSITIVE_Q;

    Element* v = Element_ARG(VALUE);

    Quote_Cell(v);  // not necessary for scalars, but futureproof it
    return rebDelegate(CANON(GREATER_Q), v, CANON(ZEROIFY), v);
}


//
//  /zero?: pure native [
//
//  "Returns TRUE if the value is zero (for its datatype)"
//
//      return: [logic!]
//      value [any-scalar? pair! char?]
//  ]
//
DECLARE_NATIVE(ZERO_Q)
{
    INCLUDE_PARAMS_OF_ZERO_Q;

    Element* v = Element_ARG(VALUE);

    Quote_Cell(v);  // not necessary for scalars, but futureproof it
    return rebDelegate(CANON(EQUAL_Q), v, CANON(ZEROIFY), v);
}
