//
//  file: %c-specialize.c
//  summary: "Routines for Creating Function Variations with Fixed Parameters"
//  section: datatypes
//  project: "Rebol 3 Interpreter and Run-time (Ren-C branch)"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2015-2020 Ren-C Open Source Contributors
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information.
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//
// A specialization is an Action which has some of its parameters fixed.
// e.g. (ap10: specialize append/ [value: 5 + 5]) makes ap10 have all the same
// refinements available as APPEND, but otherwise just takes one series arg,
// as it will always be appending 10.
//
// Specialization is done by means of making a new "exemplar" frame for the
// action.  Slots in that frame that would have held PARAMETER! antiforms to
// indicate they should gather arguments ("Holes") are replaced by the fixed
// value, which is type checked.
//
// Partial specialization uses a different mechanism.  FILE-TO-LOCAL:PASS
// fulfills a frame slot value since :PASS has no arguments, but APPEND:PART
// does not.  Distinctions of (get $append:dup:part) and (get $append:part:dup)
// require ordering information that has to be tracked outside of the
// exemplar frame.
//

#include "sys-core.h"


//
//  Make_Varlist_For_Action_Push_Partials: C
//
// For partial refinement specializations in the action, this will push the
// refinement to the stack.  In this way it retains the ordering information
// implicit in the partial refinements of an action's existing specialization.
//
// It is able to take in more specialized refinements on the stack.  These
// will be ordered *after* partial specializations in the function already.
// The caller passes in the stack pointer of the lowest priority refinement,
// which goes up to TOP_INDEX for the highest of those added specializations.
//
// Since this is walking the parameters to make the frame already--and since
// we don't want to bind to anything specialized out (including the ad-hoc
// refinements added on the stack) we go ahead and collect bindings from the
// frame if needed.
//
ParamList* Make_Varlist_For_Action_Push_Partials(
    const Value* action,  // need ->binding, so can't just be a Phase*
    StackIndex lowest_stackindex,  // caller can add refinements
    Option(Binder*) binder
){
    StackIndex highest_stackindex = TOP_INDEX;

    Phase* phase = Frame_Phase(action);

    REBLEN num_slots = Phase_Num_Params(phase) + 1;  // +1 for rootvar
    Array* a = Make_Array_Core(
        STUB_MASK_VARLIST
            | (phase->header.bits & (  // propagate
                STUB_FLAG_PHASE_IMPURE | STUB_FLAG_PHASE_PURE
            )),
        num_slots
    );
    Set_Flex_Len(a, num_slots);

    Tweak_Bonus_Keylist_Shared(a, Phase_Keylist(phase));

    assert(Is_Action(action) or Is_Possibly_Unstable_Value_Frame(action));
    Cell* rootvar = Flex_Head_Dynamic(Element, a);
    Copy_Cell(rootvar, action);
    Tweak_Cell_Lift_Byte(rootvar, TYPE_FRAME);  // make sure it's a plain FRAME
    Shield_Rootvar_If_Tracking(rootvar);

    const Key* tail;
    const Key* key = Phase_Keys(&tail, phase);
    const Param* param = Phase_Params_Head(phase);

    Arg* arg = Flex_At(Arg, a, 1);

    Ordinal n = 1;  // used to bind REFINEMENT? cells to parameter slots

    for (; key != tail; ++key, ++param, ++arg, ++n) {
        if (Is_Specialized(param)) {  // includes locals
            Blit_Cell(arg, param);
            Clear_Param_Shield_If_Tracking(arg);

          continue_specialized:

            continue;
        }

        const Symbol* symbol = Key_Symbol(key);  // added to binding
        if (Not_Parameter_Flag(param, REFINEMENT)) {  // nothing to push

          continue_unspecialized:

            assert(Not_Cell_Flag(param, PARAM_MARKED_SEALED));
            Blit_Cell(arg, param);
            Clear_Param_Shield_If_Tracking(arg);

            if (binder)
                Add_Binder_Index(unwrap binder, symbol, n);

            continue;
        }

        // Unspecialized refinement slot.  It may be partially specialized,
        // e.g. we may have pushed to the stack from the PARTIALS for it.
        //
        // Check the passed-in refinements on the stack for usage.
        //
        StackIndex stackindex = highest_stackindex;
        for (; stackindex != lowest_stackindex; --stackindex) {
            OnStack(Element*) ordered = Data_Stack_At(Element, stackindex);
            if (Word_Symbol(ordered) != symbol)
                continue;  // just continuing this loop

            assert(Cell_Binding(ordered) == UNBOUND);  // we bind only one
            Tweak_Word_Index(ordered, n);
            Tweak_Cell_Relative_Binding(ordered, cast(Details*, phase));

            if (not Is_Parameter_Unconstrained(param))  // needs argument
                goto continue_unspecialized;

            // If refinement named on stack takes no arguments, then it can't
            // be partially specialized...only fully, and won't be bound:
            //
            //     >> specialize skip:unbounded/ [unbounded: ok]
            //     ** Error: unbounded not bound
            //
            Erase_Cell(arg);
            Init_Okay(arg);
            goto continue_specialized;
        }

        goto continue_unspecialized;
    }

    Tweak_Misc_Varlist_Adjunct_Raw(a, nullptr);
    Tweak_Link_Inherit_Bind_Raw(a, nullptr);

    return cast(ParamList*, a);
}


//
//  Make_Varlist_For_Action: C
//
// This creates a FRAME! context with parameter antiforms in all unspecialized
// slots.
//
// !!! The ultimate concept is that it would be possible for a FRAME! to
// preserve ordering information such that an ACTION! could be made from it.
// Right now the information is the stack ordering numbers of the refinements
// which to make it usable should be relative to the lowest ordered StackIndex
// and not absolute.
//
ParamList* Make_Varlist_For_Action(
    const Value* action, // need ->binding, so can't just be a Phase*
    StackIndex lowest_stackindex,
    Option(Binder*) binder
){
    ParamList* exemplar = Make_Varlist_For_Action_Push_Partials(
        action,
        lowest_stackindex,
        binder
    );

    Manage_Stub(exemplar);  // !!! was needed before, review
    Drop_Data_Stack_To(lowest_stackindex);
    return exemplar;
}


//
//  Specialize_Action_Throws: C
//
// Create a new ACTION! value that uses the same implementation as another,
// but just takes fewer arguments or refinements.  It does this by storing a
// heap-based "exemplar" FRAME! in the specialized action; this stores the
// values to preload in the stack frame cells when it is invoked.
//
// The caller may provide information on the order in which refinements are
// to be specialized, using the data stack.  These refinements should be
// pushed in the *reverse* order of their invocation, so APPEND:DUP:PART
// has :DUP at TOP, and :PART under it.  List stops at lowest_stackindex.
//
bool Specialize_Action_Throws(
    Sink(Value) out,
    const Value* specializee,
    Option(Element*) def,  // !!! REVIEW: binding modified directly, not copied
    StackIndex lowest_stackindex
){
    assert(out != specializee);

    Option(const Symbol*) label = Frame_Label(specializee);
    Option(VarList*) coupling = Frame_Coupling(specializee);

    Phase* unspecialized = Frame_Phase(specializee);

  make_exemplar_context: {

    // This produces a context where partially specialized refinement slots
    // will be on the stack (including any we are adding "virtually", from
    // the current TOP_INDEX down to the lowest_stackindex).

    ParamList* exemplar = Make_Varlist_For_Action_Push_Partials(
        specializee,
        lowest_stackindex,
        nullptr  // no binder
    );
    Manage_Stub(exemplar);  // destined to be managed, guarded

  run_code_that_fills_frame_fully_or_partially: {

  // 1. At one time, SET-WORD would bind to the frame and WORD would not,
  //    which let you write things like [value: value] and it could be
  //    meaningful.  But this was deemed to not fit the binding model for how
  //    USE works.  The SPECIALIZE primitive achieves this goal without USE,
  //    by going one step at a time (like APPLY) and doing its own lookup
  //    on the key values.

    if (def) {
        require (  // [value: value] will both refer into frame [1]
          Use* use = Alloc_Use_Inherits(List_Binding(unwrap def))
        );
        Lens* lens = Lens_Inputs(unspecialized);
        Init_Frame(Stub_Cell(use), exemplar, lens, coupling);

        Tweak_Cell_Binding(unwrap def, use);
        Remember_Cell_Is_Lifeguard(Stub_Cell(use));  // protects exemplar

        bool threw = Eval_Any_List_At_Throws(
            raw_cast(Value*, out),  // use as temporary output
            unwrap def,
            SPECIFIED
        );

        if (threw) {
            Drop_Data_Stack_To(lowest_stackindex);
            return true;
        }

        Erase_Cell(out);  // ignore result of specialization code
    }

} do_specialization: {

    const Key* tail;
    const Key* key = Phase_Keys(&tail, unspecialized);
    const Param* param = Phase_Params_Head(unspecialized);

    Arg* arg = raw_cast(Arg*, Varlist_Slots_Head(exemplar));

    StackIndex ordered_stackindex = lowest_stackindex;

    // If you specialize out the first argument of an infixed function, then
    // it ceases being infix.
    //
    // !!! Needs handling for interaction with REORDER.
    //
    bool first_param = true;
    Option(InfixMode) infix_mode = Frame_Infix_Mode(specializee);

    for (; key != tail; ++key, ++param, ++arg) {
        if (Is_Specialized(param))  // was specialized in underlying phase
            continue;

        if (Is_Cell_A_Bedrock_Hole(arg)) {  // no specialized assignment
            if (first_param)
                first_param = false;  // leave infix as is
            continue;
        }

        // !!! If argument was previously specialized, should have been type
        // checked already... don't type check again (?)
        //
        if (Get_Parameter_Flag(param, VARIADIC))
            panic ("Cannot currently SPECIALIZE variadic arguments.");

        heeded (Corrupt_Cell_If_Needful(Level_Scratch(TOP_LEVEL)));
        heeded (Corrupt_Cell_If_Needful(Level_Spare(TOP_LEVEL)));

        Value* v = As_Value(arg);

        require (
          bool check = Typecheck_Coerce_Use_Toplevel(
            TOP_LEVEL, Known_Unspecialized(param), v
          )
        );
        if (not check) {
            assert(Is_Cell_Stable(v));  // had to decay before rejecting
            panic (Error_Arg_Type(label, key, param, v));
        }

        Mark_Typechecked(arg);

        if (first_param) {
            first_param = false;
            infix_mode = PREFIX_0;  // specialized out the first parameter
        }
    }

    // Everything should have balanced out for a valid specialization.
    // Turn partial refinements into an array of things to push.
    //
    Source* partials;
    if (ordered_stackindex == TOP_INDEX)
        partials = nullptr;
    else {
        // The list of ordered refinements may contain some cases like /ONLY
        // which aren't considered partial because they have no argument.
        // If that's the only kind of partial we hvae, we'll free this array.
        //
        // !!! This array will be allocated too big in cases like /dup/only,
        // review how to pick the exact size efficiently.  There's also the
        // case that duplicate refinements or non-existent ones create waste,
        // but since we error and throw those arrays away it doesn't matter.
        //
        partials = Make_Source(
            TOP_INDEX - ordered_stackindex  // maximum partial count possible
        );

        while (ordered_stackindex != TOP_INDEX) {
            ordered_stackindex += 1;
            OnStack(Element*) ordered = Data_Stack_At(
                Element, ordered_stackindex
            );
            if (not Cell_Binding(ordered)) {  // specialize print:asdf/
                assume (
                  Refinify_Pushed_Refinement(ordered)
                );
                panic (Error_Bad_Parameter_Raw(ordered));
            }

            Param* ordered_slot = raw_cast(Param*,
                Varlist_Slot(exemplar, VAL_WORD_INDEX(ordered))
            );
            if (not Is_Specialized(ordered_slot)) {
                //
                // It's still partial...
                //
                assert(VAL_WORD_INDEX(ordered) != 0);
                require (
                  Sink(Element) cell = Alloc_Tail_Array(partials)
                );
                Init_Pushable_Refinement_Bound(
                    cell,
                    Key_Symbol(Varlist_Key(exemplar, VAL_WORD_INDEX(ordered))),
                    exemplar,
                    VAL_WORD_INDEX(ordered)
                );
            }
        }
        Drop_Data_Stack_To(lowest_stackindex);

        if (Array_Len(partials) == 0) {
            Free_Unmanaged_Flex(partials);
            partials = nullptr;
        }
        else {
            Manage_Stub(partials);
            panic ("Refinement Promotion is being rethought");
        }
    }

    Init_Frame(out, exemplar, label, coupling);

    if (Is_Action(specializee))
        Activate_Frame(out);

    Tweak_Frame_Infix_Mode(out, infix_mode);
    Copy_Vanishability(out, specializee);

    return false;  // code block did not throw
}}}


//
//  /specialize: native [
//
//  "Create a new action through partial or full specialization of another"
//
//      return: [action! frame!]
//      ^operation [action! frame!]
//      args "Arguments and Refinements, e.g. [arg1 arg2 ref: refine1]"
//          [block!]
//      :relax "Don't worry about too many arguments to the SPECIALIZE"
//      {frame index iterator}  ; update `//` native if this changes [1]
//  ]
//
DECLARE_NATIVE(SPECIALIZE)
//
// 1. Refinement specializations via path are pushed to the stack, giving
//    order information that can't be meaningfully gleaned from an arbitrary
//    code block (specialize append/ [dup: x, if y [part: z]]), we shouldn't
//    think that intends any ordering of :dup:part or :part:dup)
{
    INCLUDE_PARAMS_OF_SPECIALIZE;

    enum {
        ST_SPECIALIZE_INITIAL_ENTRY = STATE_0,

        ST_SPECIALIZE_RESERVED_MIN = ST_FRAME_FILLER_MIN,
        ST_SPECIALIZE_RESERVED_MAX = ST_FRAME_FILLER_MAX,

        ST_SPECIALIZE_FINISHED_FILLING
    };

    switch (STATE) {
      case ST_SPECIALIZE_INITIAL_ENTRY: goto initial_entry;
      case ST_SPECIALIZE_FINISHED_FILLING: goto finished_filling_frame;
      default:
        assert(STATE >= ST_FRAME_FILLER_MIN and STATE <= ST_FRAME_FILLER_MAX);
        goto fill_frame_using_common_code_with_apply;
    }

  initial_entry: { ///////////////////////////////////////////////////////////

    STATE = ST_FRAME_FILLER_MIN;
    goto fill_frame_using_common_code_with_apply;

} fill_frame_using_common_code_with_apply: { /////////////////////////////////

  // This work is shared with APPLY.  We keep passing whatever the frame
  // filler Bounce is back up to the Trampoline until we get a signal that
  // it is finished, at which point we take over.

    Bounce b = Native_Frame_Filler_Core(LEVEL);
    if (b != BOUNCE_FRAME_FILLER_FINISHED) {
        possibly(THROWING);
        return b;
    }

    STATE = ST_SPECIALIZE_FINISHED_FILLING;
    goto finished_filling_frame;

} finished_filling_frame: { //////////////////////////////////////////////////

    Value* specializee = ARG(OPERATION);

    Option(InfixMode) infix_mode = Frame_Infix_Mode(specializee);

    Copy_Cell(OUT, Element_LOCAL(FRAME));

    Tweak_Frame_Infix_Mode(OUT, infix_mode);
    Copy_Vanishability(OUT, specializee);
    Proxy_Frame_Activation(OUT, specializee);

    return BOUNCE_OUT;
}}


//
//  First_Unspecialized_Param_Core: C
//
// Note that refinement promotion can make this a bit strange:
//
//     >> foo: func [:a [block!] :b [block!] :c [block!] :d [block!]] [...]
//     >> foo-d: foo:d/
//
// This means that the last parameter (D) is actually the first of FOO-D.
//
const Param* First_Unspecialized_Param_Core(
    Sink(const Key*) key_out,
    Phase* phase
){
    const Key* key_tail;
    const Key* key = Phase_Keys(&key_tail, phase);
    Param* param = Phase_Params_Head(phase);
    for (; key != key_tail; ++key, ++param) {
        if (Is_Specialized(param))
            continue;
        if (Get_Parameter_Flag(param, REFINEMENT))
            continue;
        if (key_out)
            *key_out = key;
        return param;
    }
    return nullptr;
}


//
//  Get_First_Param_Literal_Class: C
//
// !!! This is very inefficient, and the parameter class should be cached
// in the frame somehow.
//
Option(ParamClass) Get_First_Param_Literal_Class(Phase* phase) {
    ParamList* paramlist = Phase_Paramlist(phase);
    if (Not_Flavor_Flag(VARLIST, paramlist, PARAMLIST_LITERAL_FIRST))
        return PARAMCLASS_0;

    ParamClass pclass = Parameter_Class(
        First_Unspecialized_Param(nullptr, phase)
    );
    assert(  // !!! said first parameter was literal!
        pclass == PARAMCLASS_LITERAL
        or pclass == PARAMCLASS_SOFT
    );
    return pclass;
}


//
//  Last_Unspecialized_Param: C
//
// See notes on First_Unspecialized_Param() regarding complexity
//
const Param* Last_Unspecialized_Param(Sink(const Key*) key_out, Phase* act)
{
    const Key* key;
    const Key* key_head = Phase_Keys(&key, act);
    Param* param = Phase_Params_Head(act) + (key - key_head);

    while (key != key_head) {
        --key;
        --param;
        if (Is_Specialized(param))
            continue;
        if (Get_Parameter_Flag(param, REFINEMENT))
            continue;
        if (key_out)
            *key_out = key;
        return param;
    }
    return nullptr;
}

//
//  First_Unspecialized_Arg: C
//
// Helper built on First_Unspecialized_Param(), can also give you the param.
//
Arg* First_Unspecialized_Arg(Option(const Param* *) param_out, Level* L)
{
    Phase* phase = Level_Phase(L);
    const Param* param = First_Unspecialized_Param(nullptr, phase);
    if (param_out)
        *(unwrap param_out) = param;

    if (param == nullptr)
        return nullptr;

    Index index = param - Phase_Params_Head(phase);
    return Level_Args_Head(L) + index;
}


//
//  Force_Phase_Final_Core: C
//
// When you make a FRAME!, you can freely modify it up to the point where it
// is used as the basis for other frames--that rely on its definition for
// type checking and such.  Hence doing something like an ADAPT or ENCLOSE
// will forcibly finalize a ParamList-based FRAME! if it wasn't already.
//
// An additional constraint is that antiform ACTION! must hold a finalized
// Phase, as we expect STUB_FLAG_PHASE_LITERAL_FIRST to be set correctly, in
// order to accelerate the dispatch of infix in %c-step.c
//
// !!! This is one reason why plain FRAME! is not considered to be used for
// infix (though we could Force_Phase_Final() on any frame we encountered
// spliced in the evaluator that we executed...or do a slow check of the
// arguments in that case; review necessity).
//
Phase* Force_Phase_Final_Core(Phase* phase)
{
    if (Is_Stub_Details(phase)) {
        possibly(Get_Flavor_Flag(DETAILS, phase, LITERAL_FIRST));  // inherited
        return phase;  // already final, nothing to do
    }

    if (Get_Flavor_Flag(VARLIST, phase, IMMUTABLE)) {
        possibly(Get_Flavor_Flag(DETAILS, phase, LITERAL_FIRST));  // decided
        return phase;
    }

    ParamList* paramlist = cast(ParamList*, phase);

    assert(Not_Flavor_Flag(VARLIST, paramlist, PARAMLIST_LITERAL_FIRST));

    const Param* first = First_Unspecialized_Param(nullptr, paramlist);
    if (first) {
        ParamClass pclass = Parameter_Class(first);
        switch (pclass) {
          case PARAMCLASS_NORMAL:
          case PARAMCLASS_META:
            break;

          case PARAMCLASS_SOFT:
          case PARAMCLASS_LITERAL:
            Set_Flavor_Flag(VARLIST, paramlist, PARAMLIST_LITERAL_FIRST);
            break;

          default:
            assert(false);
        }
    }

    dont(Set_Flex_Flag(Varlist_Array(paramlist), FIXED_SIZE));  // should we?

    Set_Flavor_Flag(VARLIST, phase, IMMUTABLE);  // don't cache flag again
    return phase;
}
