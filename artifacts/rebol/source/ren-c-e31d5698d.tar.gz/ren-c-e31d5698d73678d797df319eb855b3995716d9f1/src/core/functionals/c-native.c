//
//  file: %c-native.c
//  summary: "Function that executes implementation as native code"
//  section: datatypes
//  project: "Ren-C Language Interpreter and Run-time Environment"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012 REBOL Technologies
// Copyright 2012-2025 Ren-C Open Source Contributors
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information.
//
// Licensed under the GNU Lesser General Public License (LGPL), Version 3.0.
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.en.html
//
//=////////////////////////////////////////////////////////////////////////=//
//
// A native is unique from other function types, because instead of there
// being a "Native_Dispatcher()", each native has a C function that acts as
// its dispatcher.
//
// Also unique about natives is that the native function constructor must be
// built "by hand", since it is required to get the ball rolling on having
// functions to call at all.  See %make-natives.r
//

#include "sys-core.h"


//
//  Raw_Native_Details_Querier: C
//
// See DETAILS_FLAG_RAW_NATIVE for explanation of why raw natives do not
// have per-Dispatcher Details Queriers.
//
bool Raw_Native_Details_Querier(
    Sink(Stable) out,
    Details* details,
    SymId property
){
    switch (property) {
      case SYM_RETURN_OF: {
        Stable* param = Details_At(details, IDX_RAW_NATIVE_RETURN);
        assert(Is_Parameter(param));
        Copy_Cell(out, param);
        return true; }

      default:
        break;
    }

    return false;
}


//
//  Make_Native_Dispatch_Details_May_Update_Spec: C
//
// Reused function in Startup_Natives() as well as extensions loading natives.
//
Result(Details*) Make_Native_Dispatch_Details_May_Update_Spec(
    Element* spec,  // e.g. COMBINATOR may expand it
    NativeType native_type,
    Dispatcher* dispatcher
){
  expand_spec_if_combinator: {

  // There are implicit parameters to both NATIVE:COMBINATOR and usermode
  // COMBINATOR.  The native needs the full spec.
  //
  // !!! Note: Will manage the combinator's array.  Changing this would need
  // a version of Make_Paramlist_Managed() which took an array + index

    if (native_type == NATIVE_COMBINATOR) {
        Init_Block(spec, Expanded_Combinator_Spec(spec));
        Tweak_Cell_Binding(spec, g_lib_context);
    }

} generate_native: {

  // With the components extracted, generate the native and add it to the
  // Natives table.  The associated C function is provided by a table built
  // in the bootstrap scripts, `g_core_native_dispatchers`.

    StackIndex base = TOP_INDEX;

    Element* gather = nullptr;

    require (
      ParamList* paramlist = Make_Paramlist_Managed(
        spec,
        MKF_DONT_POP_RETURN,  // we put it in Details, not ParamList
        SYM_RETURN,  // native RETURN: types checked only if RUNTIME_CHECKS
        gather
    ));

    Assert_Flex_Term_If_Needed(Varlist_Array(paramlist));

    Flags details_flags = (
        BASE_FLAG_MANAGED
            | DETAILS_FLAG_RAW_NATIVE
            | DETAILS_FLAG_API_CONTINUATIONS_OK
    );

    if (native_type == NATIVE_INTRINSIC)
        details_flags |= DETAILS_FLAG_CAN_DISPATCH_AS_INTRINSIC;

    Details* details = Make_Dispatch_Details(
        details_flags,
        Phase_Archetype(paramlist),
        dispatcher,  // dispatcher is unique to this native
        MAX_IDX_RAW_NATIVE  // details array capacity
    );

    Pop_Unpopped_Return(Details_At(details, IDX_RAW_NATIVE_RETURN), base);

  dispatch_finalization: {

    switch (native_type) {
      case NATIVE_NORMAL: break;
      case NATIVE_COMBINATOR: goto finalize_combinator;
      case NATIVE_INTRINSIC: goto finalize_intrinsic;
      default: assert(false);
    }

    goto return_details;

} finalize_combinator: { /////////////////////////////////////////////////////

  // NATIVE-COMBINATORs actually aren't *quite* their own dispatchers, they
  // all share a common hook to help with tracing and doing things like
  // calculating the furthest amount of progress in the parse.  We wrap the
  // native implementation inside of that hook.
  //
  // 1. Technically, we're already storing the the information for the
  //    implementation native inside the hook.  So we would seem to not need
  //    to put it in the combinator's body as well.  However, it's more
  //    "obvious" to do so--and it also permits the hook to be used to wrap
  //    non-native combinators as well.

    DECLARE_ELEMENT (native);
    Init_Frame(native, details, ANONYMOUS, UNCOUPLED);
    details = Make_Dispatch_Details(
        BASE_FLAG_MANAGED,  // *not* a native, calls one...
        native,  // reuse the args/types on native's interface [1]
        &Combinator_Dispatcher,
        MAX_IDX_COMBINATOR  // details array capacity
    );

    Copy_Cell(Details_At(details, IDX_COMBINATOR_BODY), native);  // [1]

    goto return_details;

} finalize_intrinsic: { //////////////////////////////////////////////////////

  // 1. Intrinsics are designed to be fast, and also can't invoke nested
  //    evaluation layers.  They are expected to handle typechecking in their
  //    own native code, so the type spec should have had the argument marked
  //    as not checked (by having the block be quoted).
  //
  // 2. As of yet, there's been no motivation for arity-0 intrinsics, nor
  //    arity-1-or-0 intrinsics.  They'd be possible, but the complexity
  //    to support them does not seem justified at this time.
  //
  // 3. An arity-1 intrinsic that is willing to still run if it reaches the
  //    end of evaluation is another thing that's possible, but complicating
  //    the intrinsic machinery does not seem worth it.  Review if needed.

    if (native_type == NATIVE_INTRINSIC) {
        const Param* param = Phase_Param(details, 1);
        assert(Not_Parameter_Checked_Or_Coerced(param));  // [1]
        assert(Not_Parameter_Flag(param, REFINEMENT));  // [2]
        assert(Not_Parameter_Flag(param, HOLE_OK));  // [3]
        UNUSED(param);
    }
    goto return_details;

} return_details: { //////////////////////////////////////////////////////////

    return details;
}}}


//
//  /native: native [  ; not PURE, mutates global state [1]
//
//  "(Internal Function) Create a native, using compiled C code"
//
//      return: [action!]
//      spec [block!]
//      :combinator "This native is an implementation of a PARSE keyword"
//      :intrinsic "This native can be called without building a frame"
//      :generic "This native delegates to type-specific code"
//  ]
//
DECLARE_NATIVE(NATIVE)
//
// 1. Outside of the bootstrapping issues of needing NATIVE to make the PURE
//    native in the first place--there's also the situation that each call
//    to NATIVE mutates global state by advancing the pointer to the next
//    C function to use as the implementation.  This could be changed to
//    where an index to that table is passed in instead, but even then it
//    would be dependent on which table was being used...so it would be
//    consulting global state anyway.
{
    INCLUDE_PARAMS_OF_NATIVE;

    UNUSED(ARG(GENERIC));  // only heeded by %make-natives.r to make tables

    if (not g_native_cfunc_pos)
        panic (
            "NATIVE is for internal use during boot and extension loading"
        );

    Element* spec = Element_ARG(SPEC);

    if (ARG(COMBINATOR) and ARG(INTRINSIC))
        panic (Error_Bad_Refines_Raw());

    NativeType native_type = ARG(COMBINATOR) ? NATIVE_COMBINATOR
        : ARG(INTRINSIC) ? NATIVE_INTRINSIC
        : NATIVE_NORMAL;

    CFunction* cfunc = *g_native_cfunc_pos;
    ++g_native_cfunc_pos;

    if (g_current_uses_librebol) {
        UNUSED(native_type);  // !!! no :INTRINSIC, but what about :COMBINATOR?
        Api(Value*) action = rebFunctionCore(
            upcast(RebolContext*, g_currently_loading_module),
            spec,
            f_cast(RebolActionCFunction*, cfunc)
        );
        Copy_Cell(OUT, action);
        rebRelease(action);
    }
    else {
        require (
          Details* details = Make_Native_Dispatch_Details_May_Update_Spec(
            spec,
            native_type,
            f_cast(Dispatcher*, cfunc)
        ));

        Init_Action(OUT, details, ANONYMOUS, UNCOUPLED);
    }

    return BOUNCE_OUT;
}


//
//  /native-unchecked: native [
//
//  "(Bootstrap Variation) Version of NATIVE with no typechecking"
//
//      spec
//      :combinator
//      :intrinsic
//      :generic
//  ]
//
DECLARE_NATIVE(NATIVE_UNCHECKED)
//
// This variation of NATIVE has no typechecking.  During bootstrap it is put
// in LIB(NATIVE) to use while TWEAK* is unavailable to look up the words in
// type specs.  Once TWEAK* is available, LIB(NATIVE) is overwritten by the
// typechecked version defined in DECLARE_NATIVE(NATIVE).
//
// 1. To minimize visibility of the trick, there is no LIB(NATIVE_UNCHECKED)
{
    STATIC_ASSERT(SYM_NATIVE_UNCHECKED > MAX_SYM_LIB_PREMADE);  // [1]

    return Apply_Cfunc(NATIVE_CFUNC(NATIVE), LEVEL);
}


//
//  Register_Generics: C
//
// This is called from the extension's startup function, and it registers
// the generics that have IMPLEMENT_GENERIC() from that extension.
//
void Register_Generics(const ExtraGenericTable* generics)
{
    const ExtraGenericTable* entry = generics;
    for (; entry->table != nullptr; ++entry) {
        assert(entry->ext_info->ext_heart == nullptr);
        entry->ext_info->ext_heart = Datatype_Extra_Heart(
            As_Stable(*entry->datatype_ptr)
        );

        assert(entry->ext_info->next == nullptr);
        entry->ext_info->next = entry->table->ext_info;
        entry->table->ext_info = entry->ext_info;
        assert(entry->ext_info->next != entry->ext_info);
    }
    assert(entry->ext_info == nullptr);
    assert(entry->datatype_ptr == nullptr);
}


//
//  Unregister_Generics: C
//
// 1. We want to make it possible to cleanly Unregister_Generics() and then
//    call Register_Generics() again.  So we have to return ExtraGenericInfo
//    to its default state that we assert() on... that the ext_heart is null
//    and the ->next is null.
//
void Unregister_Generics(const ExtraGenericTable* generics)
{
    const ExtraGenericTable* entry = generics;
    for (; entry->table != nullptr; ++entry) {
        assert(entry->ext_info->ext_heart == Datatype_Extra_Heart(
            As_Stable(*entry->datatype_ptr)
        ));
        assert(Stub_Flavor(entry->ext_info->ext_heart) == FLAVOR_PATCH);
        entry->ext_info->ext_heart = nullptr;  // null out datatype [1]

        ExtraGenericInfo* seek = entry->table->ext_info;
        if (seek == nullptr) {
            assert(false);
            panic ("Unregister_Generics: no ext_info in table");
        }
        if (seek == entry->ext_info)  // have to update list head
            entry->table->ext_info = seek->next;
        else
            while (seek != entry->ext_info) {
                if (seek->next == entry->ext_info) {
                    seek->next = seek->next->next;
                    break;
                }
                seek = seek->next;
                if (seek == nullptr) {
                    assert(false);
                    panic ("Unregister_Generics: ext_info not found");
                }
            }
        entry->ext_info->next = nullptr;  // null out list link [1]
    }
    assert(entry->ext_info == nullptr);
    assert(entry->datatype_ptr == nullptr);
}


//
//  Dispatch_Generic_Core: C
//
// When you define a native as `native:generic`, this means you can register
// hooks for that native based on a type with IMPLEMENT_GENERIC().  In the
// generic native's implementation you choose when to actually dispatch on
// that type, and you can implement a generic for a single type like INTEGER!
// or for builtin typesets like ANY-LIST?.
//
// 1. Generally speaking, generics (and most functions in the system) do
//    not work on antiforms, quasiforms, or quoted datatypes.
//
//    For one thing, this would introduce uncomfortable questions, like:
//    should the NEXT of ''[a b c] be [b c] or ''[b c] ?  This would take the
//    already staggering combinatorics of the system up a notch by forcing
//    "quote propagation" policies to be injected everywhere.
//
//    Yet there's another danger: if quoted/quasi items wind up giving an
//    answer instead of an error for lots of functions, this will lead to
//    carelessness in propagation of the marks...not stripping them off when
//    they aren't needed.  This would lead to an undisciplined hodgepodge of
//    marks that are effectively meaningless.  In addition to being ugly, that
//    limits the potential for using the marks intentionally in a dialect
//    later, if you're beholden to treating leaky quotes and quasis as if
//    they were not there.
//
// 2. R3-Alpha PORT! really baked in the concept of the switch()-based
//    dispatch, and an "actor" model depending on it.  It's going to take
//    a bit longer to break it out of that idea.  Bridge for the meantime
//    to translate new calls into old calls using the passed-in SymId.
//
bool Try_Dispatch_Generic_Core(
    Sink(Bounce) bounce,
    SymId symid,
    const GenericTable* table,
    const Stable* datatype,  // no quoted/quasi/anti [1]
    Level* const L
){
    Option(Heart) heart = Datatype_Heart(datatype);
    if (not heart) {
        ExtraGenericInfo* ext_info = table->ext_info;
        const ExtraHeart* ext_heart = Datatype_Extra_Heart(datatype);
        while (ext_info) {
            if (ext_info->ext_heart == ext_heart) {
                L->u.action.label = Canon_Symbol(symid);  // !!! Level_Verb()
                *bounce = Apply_Cfunc(ext_info->dispatcher, L);
                return true;
            }
            ext_info = ext_info->next;
        }

        UNUSED(ext_heart);  // should check extension generics
        NOOP;  // fall through to default for ANY-ELEMENT?, ANY-FUNDAMENTAL?
    }
    else if (
        heart == HEART_PORT
        and symid != SYM_OLDGENERIC  // !!! legacy generics for port [2]
    ){
        // !!! skip bad port check for now
        /*if (symid != SYM_MAKE) {
            VarList* ctx = Cell_Varlist(Required_Arg_Of_Level(L, 1));
            if (
                Varlist_Len(ctx) < MAX_STD_PORT
                or not Is_Object(Slot_Hack(Varlist_Slot(ctx, STD_PORT_SPEC)))
            ){
                *bounce = Native_Fail_Result(L, Error_Invalid_Port_Raw());
            }  // "old check" for invalid port
        }*/

        switch (symid) {  // exempt port's IMPLEMENT_GENERIC() cases
          case SYM_MAKE:
          case SYM_EQUAL_Q:
          case SYM_TWEAK_P:
          case SYM_MOLDIFY:
            break;  // fall through to modern dispatch

          default:
            L->u.action.label = Canon_Symbol(symid);  // !!! Level_Verb() hack
            *bounce = GENERIC_CFUNC(OLDGENERIC, Is_Port)(L);
            return true;
        }
    }

    Option(Dispatcher*) dispatcher = Get_Builtin_Generic_Dispatcher(
        table,
        heart  // maybe fallthrough of TYPE_0 for ELEMENT?/FUNDAMENTAL?
    );
    if (not dispatcher)
        return false;  // not handled--some clients want to try more things

    *bounce = Apply_Cfunc(unwrap dispatcher, L);
    return true;  // handled, even if it threw
}


//
//   Delegate_Operation_With_Part: C
//
// There's a common pattern in functions like REVERSE-OF or APPEND-OF which
// is that they're willing to run on immutable types, but delegate to running
// on a copy of the data aliased as a mutable type.
//
// It's easiest to build that pattern on top of functions that exist, as there
// isn't a strong need to write error-prone "efficient" code to do it.
//
// 1. To speed up slightly, callers are expected to quote (or lift) the
//    cells so they can be passed to the API without rebQ() calls.
//
Bounce Delegate_Operation_With_Part(
    SymId operation,
    SymId delegate,
    // arguments are passed as quoted/lifted [1]
    const Element* lifted_datatype,
    const Element* quoted_element,
    const Element* lifted_part
){
    assert(delegate == SYM_TEXT_X or delegate == SYM_BLOCK_X);

    assert(Any_Lifted(lifted_datatype));  // note: likely only quasiform soon
    assert(Is_Quoted(quoted_element));
    assert(Any_Lifted(lifted_part));

    return rebDelegate(
        CANON(AS), lifted_datatype, Canon_Symbol(operation),
            CANON(COPY), CANON(_S_S), "[",
                CANON(AS), Canon_Symbol(delegate), quoted_element,
                "part:", lifted_part,
            "]"
    );
}


//
//  /oldgeneric: native:generic [
//
//  "Generic aggregator for the old-style generic dispatch"
//
//      return: []
//  ]
//
DECLARE_NATIVE(OLDGENERIC)
{
    INCLUDE_PARAMS_OF_OLDGENERIC;

    panic ("This should never be called");
}


// Create a native in the library without using the evaluator.
//
static void Make_Native_In_Lib_By_Hand(Level* const L, SymId id)
{
    USE_LEVEL_SHORTHANDS (L);

    assert(Is_Set_Run_Word(At_Level(L)));  // a `/name:` assignment...
    Flags details_flags;  // ...but we may overwrite during boot
    Flags cell_flags;

    const Symbol* at_symbol = unwrap Try_Get_Settable_Word_Symbol(
        nullptr, At_Level(L)
    );

  skip_to_spec_block: {

    switch (id) {

    // /native-unchecked: native [...]

      case SYM_NATIVE:
        assert(Symbol_Id(at_symbol) == SYM_NATIVE_UNCHECKED);
        details_flags = 0;
        cell_flags = (not CELL_FLAG_FINAL);  // overwritten by checked version
        break;

    // /tweak*-unchecked: native [...]

      case SYM_TWEAK_P:
        assert(Symbol_Id(at_symbol) == SYM_TWEAK_P_UNCHECKED);
        details_flags = 0;
        cell_flags = (not CELL_FLAG_FINAL);  // overwritten by checked version
        break;

    // /c-debug-break: vanishable native [...]

      case SYM_C_DEBUG_BREAK:
        assert(Symbol_Id(at_symbol) == SYM_C_DEBUG_BREAK);
        details_flags = 0;

        Fetch_Next_In_Feed(L->feed);
        assert(Word_Id(At_Level(L)) == SYM_VANISHABLE);
        cell_flags = (
            CELL_FLAG_WEIRD_VANISHABLE
            | CELL_FLAG_FINAL  // not overwritten
        );
        break;

    // /typechecker-archetype: pure native:intrinsic [...]

      case SYM_TYPECHECKER_ARCHETYPE:
        assert(Symbol_Id(at_symbol) == SYM_TYPECHECKER_ARCHETYPE);

        Fetch_Next_In_Feed(L->feed);
        assert(Word_Id(At_Level(L)) == SYM_PURE);
        details_flags = STUB_FLAG_PHASE_PURE;  // not overwritten
        cell_flags = CELL_FLAG_FINAL;  // not overwritten
        break;

    // /unstable-typechecker-archetype: pure native:intrinsic [...]

      case SYM_UNSTABLE_TYPECHECKER_ARCHETYPE:
        assert(Symbol_Id(at_symbol) == SYM_UNSTABLE_TYPECHECKER_ARCHETYPE);

        Fetch_Next_In_Feed(L->feed);
        assert(Word_Id(At_Level(L)) == SYM_PURE);
        details_flags = STUB_FLAG_PHASE_PURE;  // not overwritten
        cell_flags = CELL_FLAG_FINAL;  // not overwritten
        break;

      default:
        crash (nullptr);
    }

    UNUSED(at_symbol);

    Fetch_Next_In_Feed(L->feed);
    assert(Is_Chain(At_Level(L)) or Word_Id(At_Level(L)) == SYM_NATIVE);

    Fetch_Next_In_Feed(L->feed);
    assert(Is_Block(At_Level(L)));

} make_native: {

    assert(Is_Cell_Erased(SPARE));

    Element* spec = Copy_Cell_May_Bind(SPARE, At_Level(L), g_lib_context);
    Fetch_Next_In_Feed(L->feed);

    Dispatcher* dispatcher = f_cast(Dispatcher*, *g_native_cfunc_pos);
    ++g_native_cfunc_pos;

    assume (
      Details* details = Make_Native_Dispatch_Details_May_Update_Spec(
        spec, NATIVE_NORMAL, dispatcher
    ));
    details->header.bits |= details_flags;

    Sink(Value) action = Sink_Lib_Value(id);
    Init_Action(action, details, Canon_Symbol(id), UNCOUPLED);
    action->header.bits |= cell_flags;

    assert(cast(Details*, Frame_Phase(Lib_Value(id))) == details);

    assert(not Is_Cell_Erased(SPARE));
    Erase_Cell(SPARE);  // clean up for STATE_0 expectations
}}


//
//  Startup_Natives: C
//
// This is a special bootstrapping step that makes the native functions.  The
// native for NATIVE itself can clearly not be made by means of calling itself
// e.g. (native: native ["A function that creates natives" ...]), so of course
// that has to be manually constructed.
//
// 1. See Startup_Lib() for how all the variables up to MAX_SYM_LIB_PREMADE
//    are created in advance to hold the natives (no need to walk and look for
//    SET-WORD, etc.)
//
void Startup_Natives(const Element* boot_natives)
{
    Context* lib = g_lib_context;  // native variables already exist [1]

    assert(Series_Index(boot_natives) == 0);  // should be head, sanity check
    assert(Cell_Binding(boot_natives) == UNBOUND);

    require (
      Level* L = Make_Level_At_Core(
        &Evaluator_Executor,
        boot_natives,
        lib,
        LEVEL_MASK_NONE
            | LEVEL_FLAG_VANISHABLE_VOIDS_ONLY  // irrelevant, won't vaporize!
    ));
    Push_Level(L);

  setup_native_dispatcher_enumeration: {

  // There's no parameter to NATIVE saying what the Dispatcher* is.  It's
  // assumed there is some global state set up, which each call to NATIVE
  // advances and gets the next Dispatcher* from that global state.
  //
  // This isn't particularly elegant, but something is going to be weird
  // about it one way or another.  Fabricating a HANDLE! to pass to NATIVE as
  // a second parameter would be a possibility, but that comes with its own
  // set of problems: how would you inject that HANDLE! into the stream
  // of evaluation when all we have are (foo: native [...]) statements?

    assert(g_native_cfunc_pos == nullptr);
    g_native_cfunc_pos = raw_cast(
        CFunction* const*,
        &g_core_native_dispatchers[0]
    );
    assert(g_currently_loading_module == nullptr);
    g_currently_loading_module = g_lib_context;

    g_current_uses_librebol = false;  // raw natives don't use librebol

} make_unchecked_natives_by_hand: {

  // Eval can't run `native: native [...]` or `tweak*: native [...]`
  //
  // Obviously there's a bootstrapping problem with NATIVE.  As for TWEAK*,
  // you can't run a SET-WORD assignment unless TWEAK* exists, because TWEAK*
  // is fundamental to interpreter operation for SET and GET operations
  //
  // So they're pushed up to the front of the boot block and "made by hand",
  // e.g. not by running evaluation.  (This reordering to put them at the
  // head is done in %make-natives.r)

    Make_Native_In_Lib_By_Hand(L, SYM_NATIVE);  // -> NATIVE-BEDROCK
    Make_Native_In_Lib_By_Hand(L, SYM_TWEAK_P);  // -> TWEAK*-BEDROCK

} make_c_debug_break_native_by_hand: {

  // The reason to build C-DEBUG-BREAK by hand is so so that the evaluator can
  // take for granted that `Frame_Phase(LIB(C_DEBUG_BREAK))` will always be
  // valid, in order to do its "interception" trick to bypass normal dispatch.

    Make_Native_In_Lib_By_Hand(L, SYM_C_DEBUG_BREAK);

} make_typechecker_archetype_by_hand: {

  // Startup_Type_Predicates() uses symbols, data stack, adds words to lib.
  // Not possible until this point in time.

    Make_Native_In_Lib_By_Hand(L, SYM_TYPECHECKER_ARCHETYPE);
    Make_Native_In_Lib_By_Hand(L, SYM_UNSTABLE_TYPECHECKER_ARCHETYPE);

    Startup_Type_Predicates();

} make_other_natives: {

  // For the rest of the natives, we can actually use the evaluator to
  // execute the NATIVE invocations.  This defers to refinement processing
  // of chains to handle things like NATIVE:COMBINATOR and NATIVE:INTRINSIC.
  // It also means natives could take more arguments if they wanted to,
  // without having to write special code to handle it.

    bool threw = Trampoline_With_Top_As_Root_Throws();
    assert(not threw);
    UNUSED(threw);

    assert(Is_Okay(As_Stable(Level_Out(L))));

} finished: {

    Drop_Level(L);

    assert(
        g_native_cfunc_pos
        == (
            raw_cast(CFunction* const*, &g_core_native_dispatchers[0])
            + g_num_core_natives
        )
    );

    g_native_cfunc_pos = nullptr;
    g_currently_loading_module = nullptr;

  #if RUNTIME_CHECKS  // ensure a couple of functions can be looked up by ID
    if (not Is_Action(LIB(FOR_EACH)))
        crash (LIB(FOR_EACH));

    if (not Is_Action(LIB(PARSE_REJECT)))
        crash (LIB(PARSE_REJECT));

    Count num_append_args = Phase_Num_Params(Frame_Phase(LIB(APPEND)));
    assert(num_append_args == Phase_Num_Params(Frame_Phase(LIB(INSERT))));
    assert(num_append_args == Phase_Num_Params(Frame_Phase(LIB(CHANGE))));

    Count num_find_args = Phase_Num_Params(Frame_Phase(LIB(FIND)));
    assert(num_find_args == Phase_Num_Params(Frame_Phase(LIB(SELECT))));
  #endif

} hook_to_and_as_for_reversibility_checks: {

  // There was once some rather complex optimized code for debugging TO and
  // AS, which basically implemented a kind of ENCLOSE.  But since ENCLOSE
  // exists it's better to just use it...as optimizing something that only
  // applies in debug builds with crazy mechanics isn't a good investment.

  #if RUNTIME_CHECKS
    rebElide("unprotect $to, /to: enclose to/ check-to-or-as/");
    rebElide("unprotect $as, /as: enclose as/ check-to-or-as/");
  #endif
}}


//
//  Shutdown_Natives: C
//
// Being able to run Recycle() during the native startup process means being
// able to holistically check the system state.  This relies on initialized
// data in the natives table.  Since the interpreter can be shutdown and
// started back up in the same session, we can't rely on zero initialization
// for startups after the first, unless we manually null them out.
//
void Shutdown_Natives(void) {
}
