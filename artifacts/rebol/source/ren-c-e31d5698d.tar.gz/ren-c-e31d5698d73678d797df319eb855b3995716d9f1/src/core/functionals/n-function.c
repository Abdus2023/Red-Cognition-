//
//  file: %n-function.c
//  summary: "Generator for an ACTION! whose body is a block of user code"
//  section: natives
//  project: "Ren-C Language Interpreter and Run-time Environment"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012-2025 Ren-C Open Source Contributors
// Copyright 2012 REBOL Technologies
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information.
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//
// FUNC is a common means for creating an action from a BLOCK! of code, with
// another block serving as the "spec" for parameters and HELP:
//
//     >> print-sum-twice: func [
//            "Prints the sum of two integers, and return the sum"
//            return: [integer!]
//            x "First Value" [integer!]
//            y "Second Value" [integer!]
//        ][
//            let sum: x + y
//            repeat 2 [print ["The sum is" sum]]
//            return sum
//        ]
//
//     >> print-sum-twice 10 20
//     The sum is 30
//     The sum is 30
//
// Ren-C brings new abilities not present in historical Rebol:
//
// * Return-type checking via `return: [...]` in the spec
//
// * Definitional RETURN, so that each FUNC has a local definition of its
//   own version of return specially bound to its invocation.
//
// * Specific binding of arguments, so that each instance of a recursion
//   can discern WORD!s from each recursion.  (In R3-Alpha, this was only
//   possible using CLOSURE which made a costly deep copy of the function's
//   body on every invocation.  Ren-C's method does not require a copy.)
//
// * Vanishable functions that return VOID! will disappear in multi-step
//   evaluations...leaving whatever result was in the evaluation previous to
//   the function call as-is.
//
// * Refinements-as-their-own-arguments--which streamlines the evaluator,
//   saves memory, simplifies naming, and simplifies the FRAME! mechanics.
//
//=//// NOTES /////////////////////////////////////////////////////////////=//
//
// * See LAMBDA for a variant that doesn't include definitional return.
//   (An aspirational goal is that FUNC with definitional return could be
//   built in usermode with LAMBDA.)
//
// * R3-Alpha defined FUNC in terms of MAKE ACTION! on a block.  There was
//   no particular advantage to having an entry point to making functions
//   from a spec and body that put them both in the same block, so FUNC
//   serves as a more logical native entry point for that functionality.
//

#include "sys-core.h"

enum {
    IDX_FUNC_BODY = IDX_INTERPRETED_BODY,
    MAX_IDX_FUNC = IDX_FUNC_BODY
};


//
//  Func_Dispatcher: C
//
// Puts a definitional return ACTION! in the RETURN slot of the frame, and
// runs the body block associated with this function.
//
// (At one time optimized dispatchers for cases like `func [...] []` were
// used, that avoided running empty blocks.  These were deemed to be more
// trouble than they were worth--at least for now--and so a common dispatcher
// is used even for cases that could be optimized.)
//
Bounce Func_Dispatcher(Level* const L)
{
    USE_LEVEL_SHORTHANDS (L);

    enum {
        ST_FUNC_INITIAL_ENTRY = STATE_0,
        ST_FUNC_BODY_EXECUTING,
        ST_FUNC_RUNNING_RETURN_P
    };

    Details* details = Ensure_Level_Details(L);
    assert(Details_Max(details) == MAX_IDX_FUNC);

    if (THROWING) {  // might be a RETURN:RUN targeting this Level
        assert(STATE == ST_FUNC_BODY_EXECUTING);
        const Stable* label = VAL_THROWN_LABEL(L);
        if (
            not Is_Frame(label)
            or Frame_Phase(label) != Frame_Phase(LIB(DEFINITIONAL_REDO))
            or Frame_Coupling(label) != L->varlist
        ){
            return BOUNCE_THROWN;  // wasn't a REDO thrown to this level
        }

        CATCH_THROWN(OUT, L);

        if (Is_Light_Null(OUT))
            goto redo_with_current_frame_values;

        assert(Heart_Of(OUT) == HEART_FRAME);
        goto reuse_level_to_run_frame_in_out;
    }

    switch (STATE) {
      case ST_FUNC_INITIAL_ENTRY: goto initial_entry;
      case ST_FUNC_BODY_EXECUTING: goto body_finished_without_returning;
      case ST_FUNC_RUNNING_RETURN_P: goto return_p_finished_without_returning;
      default: assert(false);
    }

  initial_entry: {  //////////////////////////////////////////////////////////

  // 1. Originally this Dispatcher didn't process throws.  DEFINITIONAL-RETURN
  //    did all the work (it has to do type checking to deliver good errors)
  //    and then used a generic UNWIND supported by the Trampoline.
  //
  //    But redo mechanics meant that Dispatchers had to be complicit.  This
  //    eliminated generic REDO, so now it's a specific aspect of RETURN:RUN's
  //    relationship to Func_Dispatcher() and needs to be caught here.
  //
  //    (That could mean that it's better to give up the generic UNWIND and
  //    fold plain RETURN catching in with RETURN:RUN catching, but that needs
  //    multiplexing the signal of whether to :RUN into the thrown value.)

    Element* body = Details_Element_At(details, IDX_DETAILS_1);  // code to run
    assert(Is_Block(body) and Series_Index(body) == 0);

    Add_Link_Inherit_Bind(L->varlist, List_Binding(body));
    Force_Level_Varlist_Managed(L);

    Inject_Definitional_Returner(L, LIB(DEFINITIONAL_RETURN), SYM_RETURN);
    Inject_Methodization_If_Any(L);

    Context* binding = raw_cast(ParamList*, L->varlist);
    Element* spare = Copy_Cell(SPARE, body);
    Tweak_Cell_Binding(spare, binding);

    STATE = ST_FUNC_BODY_EXECUTING;

    Enable_Dispatcher_Catching_Of_Throws(L);  // for RETURN:RUN, not RETURN [1]

    return CONTINUE(spare);  // body result is discarded

} redo_with_current_frame_values: { //////////////////////////////////////////

  // This will trigger a call back to the evaluator with the same VarList.
  // We will re-enter this dispatcher in the ST_FUNC_INITIAL_ENTRY state.
  //
  // 1. Because tail calls might use existing arguments and locals when
  //    calculating the new call's locals and args, we only avoid allocating
  //    new memory for the args and locals if we reuse the frame "as is",
  //    assuming the values of the variables have been loaded with what the
  //    recursion expects.  We still have to reset specialized values back
  //    to what a fresh call would have.

    possibly(Link_Inherit_Bind(L->varlist) == nullptr);  // maybe assigned null
    Tweak_Link_Inherit_Bind(L->varlist, nullptr);  // re-entry sets back

    const Key* key_tail;
    const Key* key = Phase_Keys(&key_tail, details);
    L->u.action.key = key;
    L->u.action.key_tail = key_tail;
    Param* param = Phase_Params_Head(details);
    L->u.action.param = param;
    Arg* arg = Level_Args_Head(L);
    L->u.action.arg = arg;
    for (; key != key_tail; ++key, ++arg, ++param) {
        if (Is_Specialized(param)) {  // must reset [1]
          #if DEBUG_POISON_UNINITIALIZED_CELLS
            Poison_Cell(arg);
          #endif
            Blit_Cell(arg, param);
        }
        else {
            // assume arguments assigned to values desired for recursion
        }
    }

    assert(Get_Executor_Flag(ACTION, L, DISPATCHER_CATCHES));
    Clear_Executor_Flag(ACTION, L, DISPATCHER_CATCHES);

    return REDO_TYPECHECKED;  // !!! should it clear DISPATCHER_CATCHES?

} reuse_level_to_run_frame_in_out: { /////////////////////////////////////////

  // This form of REDO allocates a new VarList, but reuses the Level.  It will
  // gather new arguments from the callsite (the callsite's feed was captured
  // and reassigned as L's feed before the throw of the REDO).

    Drop_Action(L);

    Stable* out = cast(Stable*, OUT);

    Restart_Action_Level(L);
    require (
      Push_Action(L, out, PREFIX_0)
    );

    Erase_Cell(OUT);  // invariant for ST_ACTION_INITIAL_ENTRY

    assert(Get_Executor_Flag(ACTION, L, IN_DISPATCH));
    Clear_Executor_Flag(ACTION, L, IN_DISPATCH);

    assert(Get_Executor_Flag(ACTION, L, DISPATCHER_CATCHES));
    Clear_Executor_Flag(ACTION, L, DISPATCHER_CATCHES);

    STATE = ST_ACTION_INITIAL_ENTRY;
    return CONTINUE_SAMELEVEL;

} body_finished_without_returning: {  ////////////////////////////////////////

  // 1. If no RETURN is used, we check the RETURN slot and run whatever
  //    function is there with no arguments.  If it's not a function, then
  //    that's considered a panic.

    UNUSED(SUBOUT);  // body result discarded
    Drop_Level(SUBLEVEL);

    Index slot_num = Get_Details_Flag(details, METHODIZED) ? 2 : 1;

    assert(Key_Id(Varlist_Key(L->varlist, slot_num)) == SYM_RETURN_P);

    Cell* return_cell = Required_Arg_Of_Level(L, slot_num);
    if (Is_Bedrock(return_cell)) {
        Option(const Symbol*) label = Level_Label(L);
        panic (Error_Func_No_Return_Raw(label));  // !!! BEDROCK support
    }

    if (not Is_Action(As_Value(return_cell))) {
        Option(const Symbol*) label = Level_Label(L);
        panic (Error_Func_No_Return_Raw(label));
    }
    Element* return_p = Deactivate_Action(As_Value(return_cell));

    possibly(  // could optimize this case to skip RETURN* call overhead
        Frame_Phase(return_p) == Frame_Phase(LIB(DEFINITIONAL_RETURN))
    );

    Disable_Dispatcher_Catching_Of_Throws(L);  // want RETURN* to take over
    STATE = ST_FUNC_RUNNING_RETURN_P;
    return CONTINUE(return_p);

} return_p_finished_without_returning: {  ////////////////////////////////////

    UNUSED(SUBOUT);  // return_p result discarded
    Drop_Level(SUBLEVEL);

    Option(const Symbol*) label = Level_Label(L);
    panic (Error_Return_Undivergent_Raw(label));
}}


//
//  Func_Details_Querier: C
//
bool Func_Details_Querier(
    Sink(Stable) out,
    Details* details,
    SymId property
){
    assert(Details_Dispatcher(details) == &Func_Dispatcher);
    assert(Details_Max(details) == MAX_IDX_FUNC);

    switch (property) {

  //=//// RETURN //////////////////////////////////////////////////////////=//

      case SYM_RETURN_OF: {
        ParamList* paramlist = Phase_Paramlist(details);
        Extract_Returnlike_Parameter(out, paramlist, SYM_RETURN);
        return true; }

  //=//// BODY ////////////////////////////////////////////////////////////=//

    // A longstanding idea about FUNC is it could be implemented equivalently
    // in userspace.  So there was an idea about "lying" about what the body
    // of an optimized FUNC is, in order to make it look like what a user
    // would have to write to get equivalent behavior.  To not have holes,
    // this means anything used in the boilerplate can't be hijacked and a
    // debugger would have to simulate it if stepping was requested.
    //
    // 1. See %sysobj.r for STANDARD.FUNC-BODY
    //
    // 2. Index 7 (or 6 in zero-based C) should be #BODY, a "real" body.  To
    //    give it the appearance of executing code in place, we use a GROUP!.

      case SYM_BODY_OF: {
        Element* body = cast(Element*, Details_At(details, IDX_DETAILS_1));

        Slot* std_func_body_slot = Get_System(SYS_STANDARD, STD_FUNC_BODY);

        DECLARE_STABLE (example);
        require (
          Read_Slot(example, std_func_body_slot)
        );

        REBLEN real_body_index = 6;

        Source* fake = cast(Source*, Copy_Array_Shallow_Flags(
            STUB_MASK_MANAGED_SOURCE,
            Cell_Array(example)
        ));

        Element* slot = Array_At(fake, real_body_index);
        assert(Is_Rune(slot));  // should be #BODY [2]

        assert(Series_Index(body) == 0);
        Init_Group(slot, Cell_Array(body));
        Set_Cell_Flag(slot, NEWLINE_BEFORE);

        Init_Block(out, fake);
        return true; }

      default:
        break;
    }

    return false;
}


//
//  Make_Interpreted_Action: C
//
// This digests the spec block into a `paramlist` for parameter descriptions,
// along with an associated `keylist` of the names of the parameters and
// various locals.
//
// The C function dispatcher that is used for the resulting ACTION! varies.
// For instance, if the body is empty then it picks a dispatcher that does
// not bother running the code.  And if there's no return type specified,
// a dispatcher that doesn't check the type is used.
//
// 1. We capture the mutability flag that was in effect when this action was
//    created.  The default FUNC dispatcher takes the body as <const>, but
//    alternatives could be made which did not:
//
//        >> f: func:mutable [] [b: [1 2 3] clear b]]
//
//        >> f
//        == []
//
Bounce Make_Interpreted_Action(
    Level* level_,
    Option(SymId) returner,  // SYM_RETURN, SYM_YIELD, SYM_DUMMY1 ([]:)
    Dispatcher* dispatcher,
    REBLEN details_capacity
){
    INCLUDE_PARAMS_OF_FUNCTION;

    enum {
        ST_FUNC_INITIAL_ENTRY = STATE_0
    };

    switch (STATE) {
      case ST_FUNC_INITIAL_ENTRY: goto initial_entry;
      default: assert(false);
    }

  initial_entry: { ///////////////////////////////////////////////////////////

    if (not Is_Datatype(ARG(SPEC)))
        goto process_spec_and_block_or_fence_body;

    if (Datatype_Type(ARG(SPEC)) != TYPE_BLOCK)
        panic ("SPEC must be BLOCK! datatype if BODY is spec and body");

    if (not Is_Block(ARG(BODY)))
        panic ("BODY must be BLOCK! if SPEC is BLOCK! datatype");

    if (rebRunThrows(
        SPARE,
        CANON(REDUCE), rebQ(ARG(BODY))
    )){
        return THROWN;
    }
    require (
        Stable* spare = Decay_If_Unstable(SPARE)
    );
    assert(Is_Block(spare));  // REDUCE guarantee

    Length len;
    const Element* at = List_Len_At(&len, spare);

    if (len != 2)
        panic ("SPEC as BLOCK! means second argument must be length 2");

    if (not Is_Block(at))
        panic ("SPEC as BLOCK! means reduced SPEC must be BLOCK!");

    if (not (Is_Block(at + 1) or Is_Fence(at + 1)))
        panic ("Interpreted action body must eval to BLOCK! or FENCE!");

    Copy_Cell(ARG(SPEC), at);
    Copy_Cell(ARG(BODY), at + 1);

    goto process_spec_and_block_or_fence_body;

} process_spec_and_block_or_fence_body: { ////////////////////////////////////

  // 1. It would be possible for this code to be faster for arrow functions
  //    when you write things like (x -> [x + 1]), by allowing LAMBDA to take
  //    WORD!s or other standalone elements, vs making `->` build a block to
  //    act as the spec.  This isn't necessarily a terrible idea, but it
  //    complicates the interface and is difficult to maintain.  There are
  //    higher priority things to worry about, so punt on that for now.

    Element* spec = Element_ARG(SPEC);
    Element* body = Element_ARG(BODY);
    assert(Is_Block(spec));

    Element* gather;
    if (Is_Fence(body))
        gather = body;
    else {
        assert(Is_Block(body));
        gather = nullptr;
    }

    assert(details_capacity >= 1);  // relativized body put in details[0]

    ParamList* paramlist = Make_Paramlist_Managed(
        spec,
        returner == SYM_DUMMY1 ? MKF_DONT_POP_RETURN : MKF_MASK_NONE,
        returner,
        gather
    ) except (Error* e) {
        panic (e);
    }

    Details* details = Make_Dispatch_Details(
        BASE_FLAG_MANAGED,
        Phase_Archetype(paramlist),
        dispatcher,
        details_capacity  // we fill in details[0], caller fills any extra
    );

    Source* copy = Copy_Array_At_Shallow(
        Cell_Array(body),
        Series_Index(body)
    );

    Option(const Strand*) filename;
    if ((filename = Link_Filename(Cell_Array(spec)))) {  // favor spec
        Tweak_Link_Filename(copy, filename);
        MISC_SOURCE_LINE(copy) = MISC_SOURCE_LINE(Cell_Array(spec));
    }
    else if ((filename = Link_Filename(Cell_Array(body)))) {  // body fallback
        Tweak_Link_Filename(copy, filename);
        MISC_SOURCE_LINE(copy) = MISC_SOURCE_LINE(Cell_Array(body));
    }
    else {
        // Ideally Source arrays should be connected with *some* file and line
    }

    Element* rebound = Init_Block(
        Details_At(details, IDX_INTERPRETED_BODY),
        copy
    );
    Tweak_Cell_Binding(rebound, List_Binding(body));

    if (Get_Cell_Flag(body, CONST))  // capture mutability flag [2]
        Set_Cell_Flag(rebound, CONST);  // Inherit_Const() would need Stable*

    Init_Action(OUT, details, ANONYMOUS, UNCOUPLED);

    return BOUNCE_OUT;
}}


//
//  /function: native [
//
//  "Generates an ACTION! with RETURN capability"
//
//      return: [action!]
//      spec [block! datatype!]
//      @(body) [<const> block! fence!]
//  ]
//
DECLARE_NATIVE(FUNCTION)
{
    INCLUDE_PARAMS_OF_FUNCTION;

    possibly(STATE != STATE_0);

    Bounce b = Irreducible_Bounce(Make_Interpreted_Action(
        LEVEL,
        SYM_RETURN,  // has a RETURN: in the paramlist
        &Func_Dispatcher,
        MAX_IDX_FUNC  // archetype and one array slot (will be filled)
    ));

    if (b != BOUNCE_TOPLEVEL_OUT)
        return b;

    return BOUNCE_OUT;
}


//
//  /procedure: native [
//
//  "Variation of FUNCTION that will always return TRASH"
//
//      return: [action!]
//      spec [block! datatype!]
//      @(body) [<const> block! fence!]
//  ]
//
DECLARE_NATIVE(PROCEDURE)
{
    INCLUDE_PARAMS_OF_PROCEDURE;

    possibly(STATE != STATE_0);

    Bounce b = Irreducible_Bounce(Make_Interpreted_Action(
        LEVEL,
        SYM_RETURN,
        &Func_Dispatcher,
        MAX_IDX_FUNC  // archetype and one array slot (will be filled)
    ));

    if (b != BOUNCE_TOPLEVEL_OUT)
        return b;

  tweak_unconstrained_parameter_to_auto_trash: {

    Details* details = Ensure_Frame_Details(OUT);

    Param* param = m_cast(Param*, Returnlike_Parameter_In_Paramlist(
        Phase_Paramlist(details), SYM_RETURN
    ));

    if (not Is_Parameter_Unconstrained(param))
        panic ("PROCEDURE can't have RETURN:");  // allow `return: [trash!]`?

    return BOUNCE_OUT;
}}


//
//  Init_Thrown_Unwind_Value: C
//
// This routine generates a thrown signal that can be used to indicate a
// desire to jump to a particular level in the stack with a return value.
// It is used in the implementation of the UNWIND native.
//
// See notes is %sys-frame.h about how there is no actual TYPE_THROWN type.
//
Bounce Init_Thrown_Unwind_Value(
    Level* level_,
    const Stable* seek, // FRAME!, ACTION! (or INTEGER! relative to frame)
    const Value* value,
    Level* target // required if level is INTEGER! or ACTION!
) {
    DECLARE_ELEMENT (label_unwind_frame);
    Copy_Plain_Cell(label_unwind_frame, LIB(UNWIND));

    if (Is_Frame(seek) and Is_Frame_On_Stack(Cell_Varlist(seek))) {
        g_ts.unwind_level = Level_Of_Varlist_If_Running(Cell_Varlist(seek));
    }
    else if (Is_Frame(seek)) {
        Level* L = target->prior;
        for (; true; L = L->prior) {
            if (L == BOTTOM_LEVEL)
                panic (Error_Invalid_Exit_Raw());

            if (not Is_Action_Level(L))
                continue; // only exit functions

            if (Is_Level_Fulfilling_Or_Typechecking(L))
                continue; // not ready to exit

            if (Frame_Phase(seek) == L->u.action.original) {
                g_ts.unwind_level = L;
                break;
            }
        }
    }
    else {
        assert(Is_Integer(seek));

        REBLEN count = VAL_INT32(seek);
        if (count <= 0)
            panic (Error_Invalid_Exit_Raw());

        Level* L = target->prior;
        for (; true; L = L->prior) {
            if (L == BOTTOM_LEVEL)
                panic (Error_Invalid_Exit_Raw());

            if (not Is_Action_Level(L))
                continue; // only exit functions

            if (Is_Level_Fulfilling_Or_Typechecking(L))
                continue; // not ready to exit

            --count;
            if (count == 0) {
                g_ts.unwind_level = L;
                break;
            }
        }
    }

    Init_Thrown_With_Label(level_, value, label_unwind_frame);
    return BOUNCE_THROWN;
}


//
//  /unwind: native [
//
//  "Jump up the stack to return from a specific frame or call"
//
//      return: []
//      level "Frame or index to exit from"
//          [frame! integer!]
//      ^result "Result for enclosing state"
//          [any-value?]
//  ]
//
DECLARE_NATIVE(UNWIND)
//
// UNWIND is implemented via a throw that bubbles through the stack.  Using
// UNWIND's action Value with a target `binding` field is the protocol
// understood by Eval_Core to catch a throw itself.
//
// !!! Allowing to pass an INTEGER! to jump from a function based on its
// BACKTRACE number is a bit low-level, and perhaps should be restricted to
// a debugging mode (though it is a useful tool in "code golf").
//
// !!! This might be a little more natural if the label of the throw was a
// FRAME! value.  But that also would mean throws named by frames couldn't be
// taken advantage by the user for other features, while this only takes one
// function away.  (Or, perhaps antiform frames could be used?)
{
    INCLUDE_PARAMS_OF_UNWIND;

    Stable* level = ARG(LEVEL);
    Value* result = ARG(RESULT);

    return Init_Thrown_Unwind_Value(LEVEL, level, result, level_);
}


//
//  Typecheck_Coerce_Return_Use_Toplevel: C
//
// 1. It may be that tighter controls should be put on, that you must say
//    you return FAILURE! in order to return failures (or at least say that
//    you return ANY-VALUE?).  It probably should -not- be the case that a
//    function have to annotate beyond ANY-VALUE? to say that a hot potato
//    is returned, in particular ~(veto)~.  Because generic constructs like
//    CASE are already saying they can return ANY-VALUE?.
//
Result(bool) Typecheck_Coerce_Return_Use_Toplevel(
    Level* L,  // Level whose spare/scratch used (not necessarily return level)
    const Cell* param,  // parameter for the RETURN (may be quoted)
    Value* v  // not `const Value*` -- coercion needs mutability
){
    assert(  // for specialized slot, RETURN can't be a plain PARAMETER!
        Heart_Of(param) == HEART_PARAMETER
        and (
            Type_Of_Raw(param) == TYPE_BEDROCK_HOLE  // "holes" in ParamLists
            or Type_Of_Raw(param) == TYPE_PARAMETER  // plain PARAMETER!
        )
    );

    assert(Parameter_Class(param) == PARAMCLASS_META);

    if (Not_Parameter_Checked_Or_Coerced(param))
        return true;  // skip all typechecking and coercion

    if (Is_Failure(v) or Is_Hot_Potato(v))
        return true;  // for now, all functions allow these [1]

    trap (
      bool check = Typecheck_Coerce_Use_Toplevel(L, param, v)
    );

    return check;
}


//
//  /definitional-return: native [
//
//  "RETURN, giving a result to the caller"
//
//      return: []
//      ^value [<hole> <veto> any-value?]
//      :run "Reuse stack level for another call (<redo> uses locals/args too)"
//      ;   [<variadic> any-stable?]  ; would force this frame managed
//  ]
//
DECLARE_NATIVE(DEFINITIONAL_RETURN)
//
// Returns in Ren-C are functions that are aware of the function they return
// to.  So the dispatchers for functions that provide return e.g. FUNC will
// actually use an instance of this native, and poke a binding into it to
// identify the action.
//
// This means the RETURN that is in LIB is actually a labeled TRASH! to inform
// you that no definitional return is in effect.
//
// 1. The cached name for values holding this native is set to RETURN by the
//    dispatchers that use it, overriding DEFINITIONAL-RETURN, which might
//    seem confusing debugging this.
//
// 2. Check type NOW instead of waiting and having the dispatcher check it.
//    Reasoning is that that lets the error indicate the callsite, e.g. the
//    point where `return badly-typed-value` happened.
//
//    !!! In the userspace formulation of this abstraction, it indicates
//    it's not RETURN's type signature that is constrained, as if it were
//    then RETURN would be implicated in the error.  Instead, RETURN must
//    take [any-value?] as its argument, and then report the error itself...
//    implicating the frame (in a way parallel to this native).
{
    INCLUDE_PARAMS_OF_DEFINITIONAL_RETURN;  // cached name usually RETURN [1]

    assert(STATE == STATE_0);

    Level* return_level = LEVEL;  // Level of this RETURN call

    Option(VarList*) coupling = Level_Coupling(return_level);
    if (not coupling)
        panic (Error_Archetype_Invoked_Raw());

    possibly(Level_Label(LEVEL) == CANON(RETURN_P));  // common renaming [1]

    Level* target_level = Level_Of_Varlist_May_Panic(unwrap coupling);
    Details* target_details = Ensure_Level_Details(target_level);

    Value* v;

  auto_trash_labeling: {

  // If you RETURN without an argument, we can detect that via "bedrock" and
  // a <hole> parameter.  The behavior we take by default is to return TRASH!
  // that is labeled with the name of the function that we are returning
  // from (if we know it).

    Param* value_param = ARG(VALUE);

    if (Is_Cell_A_Bedrock_Hole(value_param)) {
        Option(const Symbol*) label = Level_Label(target_level);
        if (label)
            v = Init_Trash(value_param, unwrap label);
        else
            v = Init_Tripwire(value_param);
    }
    else
        v = As_Value(value_param);

} handle_return: {

    const Element* return_param = Returnlike_Parameter_In_Paramlist(
        Phase_Paramlist(target_details), SYM_RETURN
    );

    if (not ARG(RUN)) {  // plain simple RETURN (not weird tail-call)
        require (
          bool check = Typecheck_Coerce_Return_Use_Toplevel(
            LEVEL, return_param, v
          )
        );
        if (not check)  // do it now [2]
            panic (Error_Bad_Return_Type(target_level, v, return_param));

        DECLARE_ELEMENT (label_unwind_frame);
        Copy_Plain_Cell(label_unwind_frame, LIB(UNWIND));
        g_ts.unwind_level = target_level;

        Init_Thrown_With_Label(LEVEL, v, label_unwind_frame);
        return BOUNCE_THROWN;
    }

  //=//// TAIL-CALL HANDLING //////////////////////////////////////////////=//

    // Tail calls are a semi-obscure feature that are included more "just to
    // show we can" vs. actually mattering that much.  They have the negative
    // property of obscuring the actual call stack, which is a reasoning that
    // kept them from being included in Python:
    //
    //   https://en.wikipedia.org/wiki/Tail_call
    //

    const Stable* gather_args;

    require (
      Stable* stable = Decay_If_Unstable(v)
    );
    if (
        Is_Tag(stable)
        and strcmp(cast(char*, Cell_Utf8_At(stable)), "redo") == 0
    ){
        gather_args = Stable_LIB(NULL);
    }
    else if (Is_Frame(stable)) {  // just reuse Level, have to change feed
        gather_args = stable;
        assert(target_level->feed != return_level->feed);  // can't happen?
        Retarget_Level_Feed(target_level, return_level->feed);
    }
    else
        panic ("RETURN:RUN requires action, frame, or <redo> as argument");

    // We need to cooperatively throw a restart instruction up to the level
    // of the frame.  Use DEFINITIONAL-REDO as the throw label that Eval_Core()
    // will identify for that behavior.
    //
    Copy_Cell(SPARE, LIB(DEFINITIONAL_REDO));
    Element* frame = Deactivate_Action(SPARE);
    Tweak_Frame_Coupling(  // comment said "may have changed"?
        frame,
        Varlist_Of_Level_Force_Managed(target_level)
    );

    Init_Thrown_With_Label(LEVEL, gather_args, frame);
    return BOUNCE_THROWN;
}}


//
//  /return: native [
//
//  "RETURN, giving a result to the caller"
//
//      return: []
//      ^value [<hole> <veto> any-value?]
//      :run "Reuse stack level for another call (<redo> uses locals/args too)"
//      ;   [<variadic> any-stable?]  ; would force this frame managed
//      {return*}
//  ]
//
DECLARE_NATIVE(RETURN)
//
// RETURN is implemented by calling the RETURN* currently in scope, giving
// it whatever argument it got.
{
  default_handling: {

    INCLUDE_PARAMS_OF_RETURN;

    Element* return_p = Init_Word(LOCAL(RETURN_P), CANON(RETURN_P));
    Add_Cell_Sigil(return_p, SIGIL_META);
    Bind_Cell_If_Unbound(return_p, Level_Binding(LEVEL));

    heeded (Corrupt_Cell_If_Needful(SPARE));
    heeded (Corrupt_Cell_If_Needful(SCRATCH));

    STATE = ST_TWEAK_GETTING;

    require (
      Get_Var_To_Out_Use_Toplevel(return_p, GROUP_EVAL_NO)
    );

    if (not Is_Action(OUT))
        panic ("RETURN found a RETURN* that wasn't an ACTION!");

    if (Frame_Phase(OUT) != Frame_Phase(LIB(DEFINITIONAL_RETURN))) {
        Param* param = ARG(VALUE);
        if (Is_Cell_A_Bedrock_Hole(param))
            return rebDelegate(rebRUN(OUT));

        Value* v = As_Value(param);
        Lift_Cell(v);
        return rebDelegate(rebRUN(OUT), v);
    }

} optimized_builtin_return_call: {

    INCLUDE_PARAMS_OF_DEFINITIONAL_RETURN;

    heeded (ARG(VALUE));

    require (
      Tweak_Level_Phase(LEVEL, Frame_Phase(OUT))
    );
    Tweak_Level_Coupling(LEVEL, Frame_Coupling(OUT));

    STATE = STATE_0;
    return Apply_Cfunc(NATIVE_CFUNC(DEFINITIONAL_RETURN), LEVEL);
}}


//
//  /definitional-redo: native [
//
//  "Internal throw signal used by RETURN:RUN"
//
//      return: []
//  ]
//
DECLARE_NATIVE(DEFINITIONAL_REDO)
//
// It would be possible to multiplex RETURN:RUN's functionality onto the throw
// signal of DEFINITIONAL-RETURN.  It could use CELL_FLAG_NOTE on the thrown
// value (which would be sneaky and lost if the throw mechanics didn't know
// about the flag and copied cells, losing it).  Or it could be part of the
// meta-representational mechanics, where any value that isn't a quoted or
// quasiform was presumed to be a redo signal...and plain RETURN would just
// unlift the result.
//
// However, RETURN has been using a generic UNWIND facility provided by the
// trampoline, which keeps that tested.  It also underscores the fact that
// RETURN has to do the type checking while DEFINITIONAL-RETURN is still on
// the stack, to deliver a good error message.
//
// What to do here can be revisited, but it was necessary to get rid of the
// old signal that was a generic REDO command, because generic REDO no longer
// makes sense.
{
    INCLUDE_PARAMS_OF_DEFINITIONAL_REDO;

    panic ("DEFINITIONAL-REDO should not be called directly");
}
