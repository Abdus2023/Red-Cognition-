//
//  file: %c-bind.c
//  summary: "Word Binding Routines"
//  project: "Rebol 3 Interpreter and Run-time (Ren-C branch)"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012 REBOL Technologies
// Copyright 2012-2017 Ren-C Open Source Contributors
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Binding relates a word to a context.  Every word can be either bound,
// specifically bound to a particular context, or bound relatively to a
// function (where additional information is needed in order to find the
// specific instance of the variable for that word as a key).
//

#include "sys-core.h"


//
//  Bind_Values_Inner_Loop: C
//
// Bind_Values_Core() sets up the binding table and then calls
// this recursive routine to do the actual binding.
//
void Bind_Values_Inner_Loop(
    Binder* binder,
    Element* head,
    const Element* tail,
    Context* context,
    Option(SymId) add_midstream_types,
    Flags flags
){
    Element* v = head;
    for (; v != tail; ++v) {
        if (Is_Cell_Wordlike(v)) {
          const Symbol* symbol = Word_Symbol(v);

          if (Is_Stub_Sea(context)) {
            SeaOfVars* sea = cast(SeaOfVars*, context);
            bool strict = true;
            Patch* patch = opt Sea_Patch(sea, symbol, strict);
            if (patch) {
                Tweak_Cell_Binding(v, sea);
                Tweak_Word_Stub(v, patch);
            }
            else if (
                add_midstream_types == SYM_ANY
                or (
                    add_midstream_types == SYM_SET
                    and Is_Set_Word(v)
                )
            ){
                Init_Void_Signifying_Unset(Append_Context_Bind_Word(context, v));
            }
          }
          else {
            assert(Is_Stub_Varlist(context));
            VarList* varlist = cast(VarList*, context);

            REBINT n = opt Try_Get_Binder_Index(binder, symbol);
            if (n > 0) {
                //
                // A binder index of 0 should clearly not be bound.  But
                // negative binder indices are also ignored by this process,
                // which provides a feature of building up state about some
                // words while still not including them in the bind.
                //
                assert(n <= Varlist_Len(varlist));

                // We're overwriting any previous binding, which may have
                // been relative.

                Tweak_Cell_Binding(v, varlist);
                Tweak_Word_Index(v, n);
            }
            else if (
                add_midstream_types == SYM_ANY
                or (
                    add_midstream_types == SYM_SET
                    and Is_Set_Word(v)
                )
            ){
                //
                // Word is not in varlist, so add it if option is specified
                //
                Append_Context_Bind_Word(varlist, v);
                Add_Binder_Index(binder, symbol, VAL_WORD_INDEX(v));
            }
          }
        }
        else if (flags & BIND_DEEP) {
            if (Is_Cell_Listlike(v)) {
                const Element* sub_tail;
                Element* sub_at = List_At_Mutable_Hack(&sub_tail, v);
                Bind_Values_Inner_Loop(
                    binder,
                    sub_at,
                    sub_tail,
                    context,
                    add_midstream_types,
                    flags
                );
            }
        }
    }
}


//
//  Bind_Values_Core: C
//
// Bind words in an array of values to a specified context.
//
// NOTE: If types are added, then they will be added in "midstream".  Only
// bindings that come after the added value is seen will be bound.
//
void Bind_Values_Core(
    Element* head,
    const Element* tail,
    const Stable* context,
    Option(SymId) add_midstream_types,
    Flags flags // see %sys-core.h for BIND_DEEP, etc.
){
    Binder* binder = Construct_Binder();

    VarList* c = Cell_Varlist(context);

    // Associate the canon of a word with an index number.  (This association
    // is done by poking the index into the Stub of the Symbol behind the
    // ANY-WORD?, so it must be cleaned up to not break future bindings.)
    //
  if (not Is_Module(context)) {
    Index index = 1;
    const Key* key_tail;
    const Key* key = Varlist_Keys(&key_tail, c);
    const Slot* slot = Varlist_Slots_Head(c);
    for (; key != key_tail; key++, slot++, index++)
        Add_Binder_Index(binder, Key_Symbol(key), index);
  }

    Bind_Values_Inner_Loop(
        binder,
        head,
        tail,
        c,
        add_midstream_types,
        flags
    );

    Destruct_Binder(binder);
}


//
//  Unbind_Values_Core: C
//
// Unbind words in a block, optionally unbinding those which are
// bound to a particular target (if target is NULL, then all
// words will be unbound regardless of their VAL_WORD_CONTEXT).
//
void Unbind_Values_Core(
    Element* head,
    const Element* tail,
    Option(VarList*) context,
    bool deep
){
    Element* v = head;
    for (; v != tail; ++v) {
        if (
            Is_Cell_Wordlike(v)
            and (not context or Cell_Binding(v) == unwrap context)
        ){
            Unbind_Any_Word(v);
        }
        else if (Is_Cell_Listlike(v) and deep) {
            const Element* sub_tail;
            Element* sub_at = List_At_Mutable_Hack(&sub_tail, v);
            Unbind_Values_Core(sub_at, sub_tail, context, true);
        }
    }
}


//
//  Try_Bind_Word: C
//
// Returns 0 if word is not part of the context, otherwise the index of the
// word in the context.
//
bool Try_Bind_Word(const Element* context, Element* word)
{
    const bool strict = true;
    if (Is_Module(context)) {
        Option(Patch*) patch = Sea_Patch(
            Cell_Module_Sea(context),
            Word_Symbol(word),
            strict
        );
        if (not patch)
            return false;
        Tweak_Cell_Binding(word, Cell_Module_Sea(context));
        Tweak_Word_Stub(word, unwrap patch);
        return true;
    }

    Option(Ordinal) n = Find_Symbol_In_Context(
        context,
        Word_Symbol(word),
        strict
    );
    if (not n)
        return false;

    Tweak_Cell_Binding(word, Cell_Varlist(context));
    Tweak_Word_Index(word, unwrap n);
    return true;
}


//
//  Make_Let_Variable: C
//
// Efficient form of "mini-object" allocation that can hold exactly one
// variable.  Unlike a context, it does not have the ability to hold an
// archetypal form of that context...because the only value cell in the
// singular array is taken for the variable content itself.
//
// 1. The way it is designed, the list of lets terminates in either a nullptr
//    or a context pointer that represents the specifying frame for the chain.
//    So we can simply point to the existing binding...whether it is a let,
//    a use, a frame context, or nullptr.
//
Let* Make_Let_Variable(
    const Symbol* symbol,
    Context* inherit
){
    require (
      Stub* let = Make_Untracked_Stub(  // one variable
        STUB_MASK_LET
            | CONTEXT_FLAG_PURE_INHERITED_EVIL_MACRO(inherit)
      )
    );

    Init(Slot) slot = Slot_Init_Hack(upcast(Slot*, Stub_Cell(let)));
    Init_Void_Signifying_Unset(slot);

    Tweak_Link_Inherit_Bind_Raw(let, inherit);  // linked list [1]
    Corrupt_Unused_Field(let->misc.corrupt);  // not currently used
    INFO_LET_SYMBOL(let) = m_cast(Symbol*, symbol);

    return raw_cast(Let*, let);
}


//
//  Try_Get_Binding_Of: C
//
// Find the context a word is bound into.  This has to account for things
// including what "Lens" should be used for the phase of a function.
//
bool Try_Get_Binding_Of(
    Sink(Element) out,
    const Element* wordlike,
    Context* binding  // only heeded if wordlike has no binding
){
    const Symbol* symbol = Word_Symbol(wordlike);

    Context* c = Cell_Binding(wordlike);
    if (not c)
        c = binding;  // fall back on provided binding if none in Cell

    Context* next;

    if (not c)
        return false;

    Flags must_be_final_bit = 0;  // first PURE varlist in chain forces

    goto loop_body;  // stylize loop to avoid annoying indentation level

  next_context: { ////////////////////////////////////////////////////////////

  // We want to continue the next_context loop from inside sub-loops, which
  // means we need a `goto` and not a `continue`.  But putting the goto at
  // the end of the loop would jump over variable initializations.  Stylizing
  // this way makes it work without a warning.

    c = next;

    if (c == nullptr)
        return false;

} loop_body: { ///////////////////////////////////////////////////////////////

    Flavor flavor = Stub_Flavor(c);
    Erase_Cell(out);  // out holds a "full cell" worth of lookup, if present

  //=//// ALTER `c` IF USE STUB ///////////////////////////////////////////=//

  // Sometimes the Link_Inherit_Bind() is already taken by another binding
  // chain, and so a Use Stub has to be fabricated to hold an alternative
  // binding to use in another chain.  But the effect should be the same, so
  // we transform the context to the one that the Use Stub points to.
  //
  // 1. The "final phase" of a function application is allowed to use the
  //    VarList of the Level directly as a context, and put the next context
  //    into Link_Inherit_Bind().  There's no Lens in that case, so we use the
  //    VarList itself as the Lens--providing full visibility of non-sealed
  //    locals and arguments.  A null lens cues this behavior below, so we
  //    can't leave it null when we have a USE of a Lens-less FRAME!.  Use a
  //    dummy symbol to make it act the same as no lens.

    next = opt Link_Inherit_Bind(c);  // save so we can update `c`

    if (flavor == FLAVOR_USE) {
        Element* overbind = As_Element(Stub_Cell(c));

        if (Is_Word(overbind)) {  // OVERBIND use of single WORD!
            if (Word_Symbol(overbind) != symbol)
                goto next_context;

            c = Cell_Binding(overbind);  // use its context, I guess?
            Corrupt_If_Needful(next);  // don't need it
            goto loop_body;  // skips assignment via next
        }

        Copy_Cell(out, overbind);  // save for later use for lens or label [1]
        c = Cell_Context(overbind);  // do search on other contexts
        flavor = Stub_Flavor(c);
    }

  //=//// MODULE LOOKUP ///////////////////////////////////////////////////=//

  // Module lookup is very common so we do it first.  It's relatively fast in
  // most cases, see the definition of SeaOfVars for an explanation of the
  // linked list of "Patch" pointed to by each Symbol, holding variables for
  // any module that has that symbol in it.

    if (flavor == FLAVOR_SEA) {
        SeaOfVars* sea = cast(SeaOfVars*, c);
        bool strict = true;
        Patch* patch = opt Sea_Patch(sea, symbol, strict);
        if (patch) {
            Init_Module(out, sea);
            Tweak_Word_Stub(wordlike, patch);
            goto finalize_and_return_true;
        }
        goto next_context;
    }

  //=//// LET STUBS ///////////////////////////////////////////////////////=//

  // A Let Stub is currently very simple, it just holds a single variable.
  // There may be a way to unify this with VarList in such a way that the use
  // of a single Symbol* key in the keylist position could cue it to know that
  // it's a single element context, which could unify the way that Let and
  // VarList work, though it would mean sacrificing the [0] slot which is
  // needed by ParamList to hold the inherited phase.

    if (flavor == FLAVOR_LET) {
        if (Let_Symbol(raw_cast(Let*, c)) == symbol) {
            Init_Let(out, raw_cast(Let*, c));
            Tweak_Word_Stub(wordlike, c);
            goto finalize_and_return_true;
        }
        goto next_context;
    }

    assert(flavor == FLAVOR_VARLIST);

  //=//// VARLIST LOOKUP //////////////////////////////////////////////////=//

  // VarLists are currently very basic, and require a linear KeyList search
  // to see if a Symbol is present.  There are no fancy hashings to accelerate
  // with some method that might have false positives about whether the key is
  // there.  (Symbols are immutable, and hence there could be fingerprinting
  // done that is tested against information stored in KeyLists.)  It's not as
  // big a problem as it used to be, because modules are based on SeaOfVars
  // and not VarLists...so VarLists have many fewer keys than they used to.
  //
  // But there are a couple of things that make searching in VarList more
  // complicated.  One is that the VarList may be a frame, and the frame can
  // even have duplicate keys--where only some of keys are applicable when
  // viewing the frame through a certain "Lens".

    VarList* vlist = cast(VarList*, c);

    if (Is_Cell_Erased(out))  // wasn't a USE, context is all we have
        Init_Context_Cell(out, vlist);

    Option(Ordinal) n = Find_Symbol_In_Context(  // must search
        out,
        symbol,
        true
    );

    if (n) {
        Tweak_Word_Index(wordlike, unwrap n);
        goto finalize_and_return_true;
    }

    if (Get_Stub_Flag(vlist, CONTEXT_PURE))  // pure reads only above here
        must_be_final_bit = CELL_FLAG_BINDING_MUST_BE_FINAL;

    goto next_context;

} finalize_and_return_true: { ////////////////////////////////////////////////

  // Everything should be pure and then eventually stop being pure, but
  // shouldn't get pure again (not-pure can't build on pure).
  //
  // Our concept here is that once you're in pure mode, the constness is taken
  // care of by the purity system--anything mutable is mutable because it's
  // okay (input arguments should have been made const, etc.)  So if you get a
  // mutable thing there, it's okay that it's mutable--it's some local state
  // private to the pure function.
  //
  // But if your context lets you reach down deeper in the binding chain to
  // something that existed before the purity was started, then you should
  // experience that as final/const, and only fetch final values.

    out->header.bits |= must_be_final_bit;

    return true;
}}


// We remove the decoration from the VARS argument, but remember whether we
// were setting or not.  e.g.
//
//     let x: ...
//     let [x y]: ...
//     let (expr): ...
//
// As opposed to (let x) or (let [x y]) or (let (expr)), which just LET.
//
#define LEVEL_FLAG_LET_IS_SETTING  LEVEL_FLAG_MISCELLANEOUS


//
//  /let: native [
//
//  "Dynamically add new variables into the stream of evaluation"
//
//      return: [
//          any-stable?  "Expression result if (let x: <expr>)"
//          word!        "the new variable if (let $x)"
//          void!       "vanishes if (let x)"
//      ]
//      '@vars "Variable(s) to create"  ; can't soft quote due to DEFAULT
//          [
//              word! ^word! group! block!
//              word!: ^word!: /word!: block!: group!:
//          ]
//      @expression "Optional Expression to assign"
//          [<variadic> element?]  ; fake variadic [1]
//
//      {bindings-holder}  ; workaround [2]
//  ]
//
DECLARE_NATIVE(LET)
//
// 1. Though LET shows as a variadic function on its interface, it does not
//    need to use the variadic argument...since it is a native (and hence
//    can access the frame and feed directly).
//
// 2. Because we stacklessly evaluate the right hand side, we can't persist
//    a `Context*` stack variable of the LET bindings chain we built across
//    that evaluation.  We need to put the `Context*` somewhere that it will
//    be GC safe during the evaluation, and retrievable after it.
//
//    But there's not currently any kind of CONTEXT! abstraction exposed that
//    captures the binding environment that a Context* does.  That needs to
//    change... and there need to be individual parts like LET! as well.
//    Until such an abstraction exists, we have things like BLOCK! which can
//    hold a Context* in its Cell->extra slot as a binding, so that serves as
//    a proxy for the functionality.
{
    INCLUDE_PARAMS_OF_LET;

    Element* vars = ARG(VARS);

    UNUSED(ARG(EXPRESSION));
    Level* L = level_;  // fake variadic [2]
    Context* L_binding = Level_Binding(L);

    enum {
        ST_LET_INITIAL_ENTRY = STATE_0,
        ST_LET_EVAL_STEP  // only used when LEVEL_FLAG_LET_IS_SETTING
    };

    switch (STATE) {
      case ST_LET_INITIAL_ENTRY:
        Init_Block(LOCAL(BINDINGS_HOLDER), EMPTY_ARRAY);
        goto initial_entry;

      case ST_LET_EVAL_STEP:
        goto integrate_eval_bindings;

      default:
        assert (false);
    }

  initial_entry: {  ///////////////////////////////////////////////////////////

    if (Is_Group(vars))
        goto escape_groups;

    if (Is_Set_Group(vars)) {
        Set_Level_Flag(L, LET_IS_SETTING);
        assume (
          Unsingleheart_Sequence(vars)  // turn into normal GROUP!
        );
        goto escape_groups;
    }

    goto generate_new_block_if_quoted_or_group;

} escape_groups: { //=//// let (...): ... /////////////////////////////////=//

    // Though the evaluator offers parameter conventions that escape groups
    // for you before your function gets called, we can't use that convention
    // here due to a contention with DEFAULT:
    //
    //     let (...): default [...]
    //
    // We want the LET to win.  So this means we have to make left win in a
    // prioritization battle with right, if they're both soft literal.  At
    // the moment, left will defer if right is literal at all.  It needs some
    // conscious tweaking when there is time for it...but the code was
    // written to do the eval here in LET with a hard literal...works for now.
    //
    // 1. Question: Should it be allowed to write (let 'x: ...) and have it
    //    act as if you had written (x: ...), e.g. no LET behavior at all?
    //    This may seem useless, but it could be useful in generated code to
    //    "escape out of" a LET in some boilerplate.  And it would be
    //    consistent with the behavior of (let ['x]: ...)
    //
    // 2. For convenience, the group can evaluate to a SET-BLOCK,  e.g.
    //
    //        block: $[x y]:
    //        (block): <whatever>  ; no real reason to prohibit this
    //
    //    There are conflicting demands where we want `(thing):` equivalent
    //    to `[(thing)]:`, while we don't want "mixed decorations" where
    //    `('^thing):` would become both SET! and METAFORM!.
    //
    // 3. Right now what is permitted is conservative.  Bias it so that if you
    //    want something to just "pass through the LET" that you use a quote
    //    mark on it, and the LET will ignore it.

    assert(Is_Group(vars));

    if (Eval_Any_List_At_Throws(SPARE, vars, SPECIFIED))
        return THROWN;

    require (
      Decay_If_Unstable(SPARE)
    );
    if (Is_Antiform(SPARE))
        panic (Error_Bad_Antiform(SPARE));

    Element* spare = As_Element(SPARE);

    if (Is_Quoted(spare))  // should (let 'x: <whatever>) be legal? [1]
        panic ("QUOTED? escapes not supported at top level of LET");

    if (Try_Get_Settable_Word_Symbol(nullptr, spare) or Is_Set_Block(spare)) {
        if (Get_Level_Flag(L, LET_IS_SETTING)) {
            // Allow `(set-word):` to ignore redundant colon [2]
            Clear_Level_Flag(L, LET_IS_SETTING);  // let block/word signal it
        }
        else {
            panic (
                "[let (expr)] can't have expr be SET-XXX!, use [let (expr):]"
            );
        }
    }
    else if (Is_Word(spare) or Is_Block(spare)) {
        if (Get_Level_Flag(L, LET_IS_SETTING)) {
            assume (
              Setify(spare)  // graft colon off (...): on word/block
            );
            Clear_Level_Flag(L, LET_IS_SETTING);  // let block/word signal it
        }
    }
    else
        panic ("LET GROUP! limited to WORD! and BLOCK!");  // [3]

    vars = spare;

} generate_new_block_if_quoted_or_group: {

    // Writes rebound copy of `vars` to SPARE if it's a SET-WORD! or SET-BLOCK!
    // so it can be used in a reevaluation.  For WORD!/BLOCK! forms of LET it
    // just writes the rebound copy into the OUT cell.
    //
    // 1. It would be nice if we could just copy the input variable and
    //    rewrite the binding, but at time of writing /foo: is not binding
    //    compatible with WORD!...it has a pairing allocation for the chain
    //    holding the word and a space, and no binding index of its own.
    //    This will all be reviewed at some point, but for now we do a
    //    convoluted rebuilding of the matching structure from a word basis.

    Context* bindings = L_binding;  // context chain we may be adding to

    if (bindings and Not_Base_Managed(bindings))
        Set_Base_Managed_Bit(bindings);  // natives don't always manage

    assert(Not_Level_Flag(L, LET_IS_SETTING));

    if (Is_Block(vars))
        goto handle_block_or_set_block;

    if (Is_Set_Block(vars)) {
        Set_Level_Flag(L, LET_IS_SETTING);
        goto handle_block_or_set_block;
    }

  detect_word_or_set_word: {

    const Symbol* symbol;

    if (Is_Word(vars) or Is_Meta_Form_Of(WORD, vars)) {
        symbol = Word_Symbol(vars);
        goto handle_word_or_set_word;
    }

    symbol = opt Try_Get_Settable_Word_Symbol(nullptr, cast(Element*, vars));
    if (symbol) {
        Set_Level_Flag(L, LET_IS_SETTING);
        goto handle_word_or_set_word;
    }

    panic ("Malformed LET.");

  handle_word_or_set_word: {

    bindings = Make_Let_Variable(symbol, bindings);

    Sink(Element) where = Get_Level_Flag(L, LET_IS_SETTING)
        ? SPARE
        : OUT;

    Init_Word_Bound(where, symbol, bindings);
    if (Heart_Of(vars) != HEART_WORD) {  // more complex than we'd like [1]
        assume (
          Setify(where)
          );
        if (Heart_Of(vars) == HEART_PATH) {
            assume (  // was a path when we got it!
              Blank_Head_Or_Tail_Sequencify(
                where, HEART_PATH, CELL_FLAG_LEADING_BLANK
            ));
        }
        else
            assert(Heart_Of(vars) == HEART_CHAIN);
    }
    if (Is_Metaform(vars))
        Add_Cell_Sigil(where, SIGIL_META);

    Corrupt_If_Needful(vars);  // if in spare, we may have overwritten

    goto finished_making_let_bindings;

}} handle_block_or_set_block: {

    // 1. In the "LET dialect", quoted words pass through things with their
    //    existing binding, but allowing them to participate in the same
    //    multi-return operation:
    //
    //        let [value error]
    //        [value position error]: transcode data  ; awkward
    //
    //        let [value 'position error]: transcode data  ; better
    //
    //    This is applied generically: no quoted items are processed by the
    //    LET...it merely removes the quoting level and generates a new block
    //    as output which doesn't have the quote.
    //
    // 2. Once the multi-return dialect was planned to have more features like
    //    naming arguments literally.  That wouldn't have any meaning to LET
    //    and would be skipped.  That feature of naming outputs has been
    //    scrapped, though...so questions about what to do if things like
    //    integers etc. appear in blocks are open at this point.

    if (Is_Set_Block(vars))
        assert(Get_Level_Flag(L, LET_IS_SETTING));
    else {
        assert(Not_Level_Flag(L, LET_IS_SETTING));
        assert(Is_Block(vars));
    }

    const Element* tail;
    const Element* item = List_At(&tail, vars);
    Context* item_binding = List_Binding(vars);

    assert(TOP_INDEX == STACK_BASE);

    bool altered = false;

    for (; item != tail; ++item) {
        const Element* temp = item;
        Context* temp_binding = item_binding;

        if (Is_Quoted(temp)) {
            Copy_Cell_May_Bind(PUSH(), temp, temp_binding);
            Unquote_Quoted_Cell(TOP_ELEMENT);  // drop quote in output block [1]
            altered = true;
            continue;  // do not make binding
        }

        if (Is_Group(temp)) {  // evaluate non-QUOTED? groups in LET block
            if (Eval_Any_List_At_Throws(OUT, temp, item_binding))
                return THROWN;

            if (Any_Void(OUT)) {
                Init_Space(OUT);
            }
            else {
                require (
                  Decay_If_Unstable(OUT)
                );
                if (Is_Antiform(OUT))
                    panic (Error_Bad_Antiform(OUT));
            }

            temp = cast(Element*, OUT);
            temp_binding = SPECIFIED;

            altered = true;
        }

        if (Is_Set_Word(temp))
            goto wordlike;

        if (Is_Path(temp)) {
            Option(SingleHeart) singleheart;
            switch (
                opt (singleheart = Try_Get_Sequence_Singleheart(temp))
            ){
              case LEADING_BLANK_AND(WORD):
                goto wordlike;

              case LEADING_BLANK_AND(TUPLE):  // should pass through!
              default:
                break;
            }
            panic ("LET only supports /WORD for paths for now...");
        }

        switch (opt Heart_Of(temp)) {  // permit quasi
          case HEART_RUNE:  // is multi-return opt for dialect, passthru
            Copy_Cell_May_Bind(PUSH(), temp, temp_binding);
            break;

          wordlike:
          case HEART_WORD: {
            Copy_Cell_May_Bind(PUSH(), temp, temp_binding);  // !!! no derel
            const Symbol* symbol = Word_Symbol(temp);
            bindings = Make_Let_Variable(symbol, bindings);
            Tweak_Cell_Binding(TOP_ELEMENT, bindings);
            Tweak_Word_Stub(TOP_ELEMENT, bindings);
            break; }

          default:
            panic (Error_Bad_Value(temp));  // default to passthru [2]
        }
    }

    Sink(Element) where = Get_Level_Flag(L, LET_IS_SETTING)
        ? SPARE
        : OUT;

    if (altered) {  // elements altered, can't reuse input block rebound
        assert(Get_Level_Flag(L, LET_IS_SETTING));
        assume (
          Setify(Init_List(
            where,  // may be SPARE, and vars may point to it
            HEART_BLOCK,
            Pop_Managed_Source_From_Stack(STACK_BASE)
        )));
    }
    else {
        Drop_Data_Stack_To(STACK_BASE);

        if (vars != where)
            Copy_Cell(where, vars);  // Move_Cell() of ARG() not allowed
    }
    Tweak_Cell_Binding(where, bindings);

    Corrupt_If_Needful(vars);  // if in spare, we may have overwritten

} finished_making_let_bindings: {

    Tweak_Cell_Binding(Element_LOCAL(BINDINGS_HOLDER), bindings);

    if (Get_Level_Flag(L, LET_IS_SETTING))
        goto eval_right_hand_side_if_let_is_setting;

    Element* out = As_Element(OUT);
    assert(Is_Word(out) or Is_Block(out) or Is_Meta_Form_Of(WORD, out));
    USED(out);
    goto integrate_let_bindings;

}} eval_right_hand_side_if_let_is_setting: {  // no `bindings` use after here

    // We want the left hand side to use the *new* LET bindings, but the right
    // hand side should use the *old* bindings.  For instance:
    //
    //     let /assert: specialize assert/ [handler: [print "should work!"]]
    //
    // Leverage same mechanism as REEVAL to preload the next execution step
    // with the rebound SET-WORD! or SET-BLOCK!
    //
    // (We want infix operations to be able to "see" the left side of the
    // LET, so this requires reevaluation--as opposed to just evaluating
    // the right hand side and then running SET on the result.)

    Element* spare = As_Element(SPARE);
    assert(
        Try_Get_Settable_Word_Symbol(nullptr, spare)
        or Is_Set_Block(spare)
    );

    Flags flags =
        FLAG_STATE_BYTE(ST_STEPPER_REEVALUATING)
            | (L->flags.bits & EVAL_EXECUTOR_FLAG_FULFILLING_ARG);

    require (
      Level* sub = Make_Level(&Stepper_Executor, LEVEL->feed, flags)
    );
    Copy_Cell(Evaluator_Level_Current(sub), spare);

    Push_Level(sub);

    STATE = ST_LET_EVAL_STEP;
    return CONTINUE_SUBLEVEL;

} integrate_eval_bindings: {  ////////////////////////////////////////////////

    // The evaluation may have expanded the bindings, as in:
    //
    //     let y: let x: 1 + 2 print [x y]
    //
    // The LET Y: is running the LET X step, but if it doesn't incorporate that
    // it will be setting the feed's bindings to just include Y.  We have to
    // merge them, with the outer one taking priority:
    //
    //    >> x: 10, let x: 1000 + let x: x + 10, print [x]
    //    1020
    //
    // !!! Currently, any bindings added during eval are lost. Review this.
    //
    // 1. When it was looking at infix, the evaluator caches the fetched value
    //    of the word for the next execution.  But we are pulling the rug out
    //    from under that if the immediately following item is the same as
    //    what we have... or a TUPLE! starting with it, etc.
    //
    //        (x: 10 let x: 20 x)  (x: 10 let x: make object! [y: 20] x.y)
    //
    //    We could try to be clever and maintain that cache in the cases that
    //    call for it.  But with evaluator hooks we don't know what kinds of
    //    overrides it may have (maybe the binding for items not at the head
    //    of a path is relevant?)  Simplest thing to do is drop the cache.

    Copy_Cell(OUT, SUBOUT);
    Drop_Level(SUBLEVEL);

    goto integrate_let_bindings;

} integrate_let_bindings: {  /////////////////////////////////////////////////

    // Going forward we want the feed's binding to include the LETs.  Note
    // that this can create the problem of applying the binding twice; this
    // needs systemic review.

    Context* bindings = List_Binding(Element_LOCAL(BINDINGS_HOLDER));
    Tweak_Cell_Binding(Feed_Data(L->feed), bindings);

    return BOUNCE_OUT;
}}


//
//  /add-let-binding: native [
//
//  "Experimental function for adding a new variable binding"
//
//      return: [frame! any-list?]
//      environment [frame! any-list?]
//      word [word! ^word!]
//      ^value [any-value?]
//  ]
//
DECLARE_NATIVE(ADD_LET_BINDING)
//
// !!! At time of writing, there are no "first class environments" that
// expose the "Specifier" chain in arrays.  So the arrays themselves are
// used as proxies for that.  Usermode dialects (like UPARSE) update their
// environment by passing in a rule block with a version of that rule block
// with an updated binding.  A function that wants to add to the evaluator
// environment uses the frame at the moment.
{
    INCLUDE_PARAMS_OF_ADD_LET_BINDING;

    Element* env = Element_ARG(ENVIRONMENT);
    Context* parent;

    Element* word = Element_ARG(WORD);

    if (Is_Frame(env)) {
        Level* L = Level_Of_Varlist_May_Panic(Cell_Varlist(env));
        parent = Level_Binding(L);
        if (parent)
            Set_Base_Managed_Bit(parent);
    } else {
        assert(Any_List(env));
        parent = List_Binding(env);
    }

    Let* let = Make_Let_Variable(Word_Symbol(ARG(WORD)), parent);

    Value* v = ARG(VALUE);
    if (Is_Meta_Form_Of(WORD, word)) {
        Copy_Cell(Stub_Cell(let), v);  // don't decay
    }
    else {
        assert(Is_Word(word));
        if (Is_Non_Meta_Assignable_Unstable_Antiform(v))
            Copy_Cell(Stub_Cell(let), v);
        else {
            require (  // !!! Review: action-PACK! rules?
                Stable* stable = Decay_If_Unstable(v)
            );
            Copy_Cell(Stub_Cell(let), stable);
        }
    }

    if (Is_Frame(env)) {
        Level* L = Level_Of_Varlist_May_Panic(Cell_Varlist(env));
        Tweak_Cell_Binding(Feed_Data(L->feed), let);
    }
    else {
        Tweak_Cell_Binding(env, let);
    }

    return COPY_TO_OUT(env);
}


//
//  /add-use-object: native [
//
//  "Experimental function for adding an object's worth of binding to a frame"
//
//      return: [trash!]
//      frame [frame!]
//      object [object!]
//  ]
//
DECLARE_NATIVE(ADD_USE_OBJECT) {
    INCLUDE_PARAMS_OF_ADD_USE_OBJECT;

    Element* object = Element_ARG(OBJECT);

    Level* L = Level_Of_Varlist_May_Panic(Cell_Varlist(ARG(FRAME)));
    Context* L_binding = Level_Binding(L);

    if (L_binding)
        Set_Base_Managed_Bit(L_binding);

    require (
      Use* use = Alloc_Use_Inherits(L_binding)
    );
    Copy_Cell(Stub_Cell(use), object);

    Tweak_Cell_Binding(Feed_Data(L->feed), use);

    return TRASH_OUT;
}


//
//  /definitional: native [
//
//  "Look up variable in the context of an executing function FRAME! callsite"
//
//      return: [any-value?]
//      frame [frame!]
//      var [word! ^word! tuple! ^tuple!]  ; demand unbound?
//  ]
//
DECLARE_NATIVE(DEFINITIONAL)
{
    INCLUDE_PARAMS_OF_DEFINITIONAL;

    Element* var = Element_ARG(VAR);
    if (Cell_Binding(var) != nullptr)
        panic ("DEFINITIONAL requires unbound word or tuple");

    Context* binding = Level_Binding(
        Level_Of_Varlist_May_Panic(Cell_Varlist(ARG(FRAME)))
    );

    Bind_Cell_If_Unbound(var, binding);

    heeded (Corrupt_Cell_If_Needful(SPARE));
    heeded (Corrupt_Cell_If_Needful(SCRATCH));

    STATE = ST_TWEAK_GETTING;

    require (
      Get_Var_To_Out_Use_Toplevel(var, GROUP_EVAL_NO)
    );

    return BOUNCE_OUT;
}


//
//  Clonify_And_Bind_Relative: C
//
// Clone the Flex embedded in a value *if* it's in the given set of types
// (and if "cloning" makes sense for them, e.g. they are not simple scalars).
//
// Note: The resulting clones will be managed.  The model for lists only
// allows the topmost level to contain unmanaged values...and we *assume* the
// values we are operating on here live in an array.
//
// 1. In Ren-C's binding model, function bodies are conceptually unbound, and
//    need the binding of the frame instance plus whatever binding was
//    on the body to resolve the words.  That resolution happens every time
//    the body is run.  Since function frames don't expand in size, we can
//    speed the lookup process for unbound words by reusing their binding
//    space to say whether a word is present in this function's frame or not.
//
// 2. To make the test for IS_WORD_UNBOUND() easy, it's just that the index
//    is less than or equal to zero.  If a word has a negative index then
//    that means it is caching the fact that the word CAN be found in the
//    action at the positive index.  If it has zero and a binding, that
//    means it CAN'T be found in the action's frame.
//
//    !!! This feature became disabled when $word bound to environments.
//    Review if a similar optimization could be helpful in the future.
//
//      https://rebol.metaeducation.com/t/copying-function-bodies/2119/4
//
// 3. If we're cloning a sequence, we have to copy the mirror byte.  If it's
//    a plain array that happens to have been aliased somewhere as a sequence,
//    we don't know if it's going to be aliased as that same sequence type
//    again...but is that worth testing if it's a sequence here?
//
Result(None) Clonify_And_Bind_Relative(
    Element* v,
    Flags flags,
    bool deeply,
    Option(Binder*) binder,
    Option(Details*) relative
){
    assert(flags & BASE_FLAG_MANAGED);

    Option(Heart) heart = Unchecked_Heart_Of(v);

    if (
        relative
        and Is_Cell_Wordlike(v)
        and IS_WORD_UNBOUND(v)  // use unbound words as "in frame" cache [1]
    ){
        // [2] is not active at this time
    }
    else if (deeply and (Any_Series_Heart(heart) or Any_Sequence_Heart(heart))) {
        //
        // Objects and Flexes get shallow copied at minimum
        //
        Element* deep = nullptr;
        Element* deep_tail = nullptr;

        if (Is_Cell_Pairlike(v)) {
            Pairing* copy = Copy_Pairing(
                Cell_Pairing(v),
                BASE_FLAG_MANAGED
            );
            PAIRLIKE_PAYLOAD_1_PAIRING_BASE(v) = copy;

            deep = Pairing_Head(copy);
            deep_tail = Pairing_Tail(copy);
        }
        else if (Is_Cell_Listlike(v)) {  // ruled out pairlike sequences above...
            Source* copy = cast(Source*, Copy_Array_At_Extra_Shallow(
                STUB_MASK_MANAGED_SOURCE,
                Cell_Array(v),
                0,  // !!! what if Series_Index() is nonzero?
                0
            ));
            /* if (Any_Sequence(v)) */  // copy regardless? [3]
                MIRROR_BYTE(copy) = MIRROR_BYTE(Cell_Array(v));

            PAIRLIKE_PAYLOAD_1_PAIRING_BASE(v) = copy;

            // See notes in Clonify()...need to copy immutable paths so that
            // binding pointers can be changed in the "immutable" copy.
            //
            if (Any_Sequence_Heart(heart))
                Freeze_Source_Shallow(copy);

            // !!! At one point, arrays were marked relative as well as the
            // words in function bodies.  Now it's needed to consider them
            // to be unbound most of the time.

            deep = Array_Head(copy);
            deep_tail = Array_Tail(copy);
        }
        else if (Any_Series_Heart(heart)) {
            trap (
              Flex* copy = Copy_Flex_Core(BASE_FLAG_MANAGED, Cell_Flex(v))
            );
            PAIRLIKE_PAYLOAD_1_PAIRING_BASE(v) = copy;
        }

        // If we're going to copy deeply, we go back over the shallow
        // copied Array and "clonify" the values in it.
        //
        if (deep) {
            for (; deep != deep_tail; ++deep) {
                trap (
                  Clonify_And_Bind_Relative(
                    deep,
                    flags,
                    deeply,
                    binder,
                    relative
                ));
            }
        }
    }
    else {
        // We're not copying the value, so inherit the const bit from the
        // original value's point of view, if applicable.
        //
        v->header.bits |= (flags & ARRAY_FLAG_CONST_SHALLOW);
    }

    return none;
}


//
//  Copy_And_Bind_Relative_Deep_Managed: C
//
// This routine is called by Make_Phase to copy the body deeply, and while
// it is doing that it puts a cache in any unbound words of whether or not
// that words can be found in the function's frame.
//
// !!! This function was once used for function bodies; now they are just
// shallow copied.  Further questions are if they should not be copied at
// all, or only copied if functions take GROUP! bodies vs. literal FENCE!
// or blocks.  Code kept temporarily for possible future study.
//
Source* Copy_And_Bind_Relative_Deep_Managed(
    const Stable* body,
    Details* relative,
    LensMode lens_mode
){
    Binder* binder = Construct_Binder();

  add_binder_indices: {

  // Setup binding table from the argument word list.  Note that some cases
  // (like an ADAPT) reuse the exemplar from the function they are adapting,
  // and should not have the locals visible from their binding.  Other cases
  // such as the plain binding of the body of a FUNC created the exemplar
  // from scratch, and should see the locals.  Caller has to decide.

    EVARS e;
    Init_Evars(&e, Phase_Archetype(relative));
    e.lens_mode = lens_mode;
    while (Try_Advance_Evars(&e))
        Add_Binder_Index(binder, Key_Symbol(e.key), e.n);
    Shutdown_Evars(&e);

} shallow_copy_then_adjust: {

    const Source* original = Cell_Array(body);
    Index index = Series_Index(body);
   /* Context* binding = List_Binding(body); */
    REBLEN tail = Series_Len_At(body);
    assert(tail <= Array_Len(original));

    if (index > tail)  // !!! should this be asserted?
        index = tail;

    Flags flags = STUB_MASK_MANAGED_SOURCE;
    bool deeply = true;

    REBLEN len = tail - index;

    // Currently we start by making a shallow copy and then adjust it

    Source* copy = raw_cast(Source*, Make_Array_For_Copy(flags, original, len));
    Set_Flex_Len(copy, len);

    const Element* src = Array_At(original, index);
    Element* dest = Array_Head(copy);
    REBLEN count = 0;
    for (; count < len; ++count, ++dest, ++src) {
        Copy_Cell(dest, src);
        require (
          Clonify_And_Bind_Relative(  // !!! undo allocations?
            dest,
            flags | BASE_FLAG_MANAGED,
            deeply,
            binder,
            relative
        ));
    }

    Destruct_Binder(binder);
    return copy;
}}


//
//  Create_Loop_Context_May_Bind_Body: C
//
// Looping constructs are parameterized by WORD!s to set each time:
//
//    for-each [x y] [1 2 3] [print ["x is" x "and y is" y]]
//
// Ren-C adds features:
//
// * Quoting a WORD! means that the variable will be unbound when written
//   by the loop structure (hence, loops use a special write function that
//   is sensitive to this flag to update the variable).
//
// * Using $WORD! means that the existing binding of the variable will be
//   used vs. creating a new one.
//
// * Using ^WORD! means the variable will not be decayed when it is written.
//   Failing to decorate with ^ also means that ACTION! antiforms will cause
//   errors and not be assigned.
//
// (The combinatorics of wanting both $ and ^ semantics are not currently
// worked out yet.)
//
// 1. The returned VarList* is an ordinary object, that outlives the loop:
//
//        x-word: ~
//        for-each x [1 2 3] [x-word: $x, break]
//        get x-word  ; returns 3
//
//    !!! Loops should probably free their objects by default when finished
//
// 2. The binding of BODY will only be modified if there are actual new loop
//    variables created.  So (for-each $x ...) won't make any new variables.
//    But note that this means there won't be a reference to the VarList*
//    containing the alias that gets created in that case...which means that
//    the caller needs to be sure that VarList* gets GC-protected.
//
//    !!! Consider perhaps finding a way to put a "no-op" in the bind chain
//    that can still hold onto the VarList*, to relieve the caller of the
//    concern of protecting the VarList*.
//
Result(VarList*) Create_Loop_Context_May_Bind_Body(
    Element* body,  // binding modified if new loop variables created [2]
    Element* spec  // spec BLOCK! -or- just a plain WORD!, @WORD!, SPACE, etc.
){
    // !!! This just hacks in GROUP! behavior, because the :param convention
    // does not support groups and gives GROUP! by value.  In the stackless
    // build the preprocessing would most easily be done in usermode.
    //
    if (Is_Group(spec)) {
        DECLARE_VALUE (temp);
        if (Eval_Any_List_At_Throws(temp, spec, SPECIFIED))
            return fail (Error_No_Catch_For_Throw(TOP_LEVEL));
        require (
          Decay_If_Unstable(temp)
        );
        if (Is_Antiform(temp))
            return fail (Error_Bad_Antiform(temp));
        Move_Cell(spec, As_Element(temp));
    }

    REBLEN num_vars = Is_Block(spec) ? Series_Len_At(spec) : 1;
    if (num_vars == 0)
        return fail (Error_Bad_Value(spec));

    const Element* tail;
    const Element* item;
    Context* binding;  // needed if looking up $var to write to

    if (Is_Block(spec)) {
        binding = List_Binding(spec);
        item = List_At(&tail, spec);
    } else {
        item = cast(Element*, spec);
        tail = cast(Element*, spec) + 1;
        binding = SPECIFIED;
    }

    Binder* binder = nullptr;  // only made if body needs binding

  walk_block_for_errors_before_making_binder: {

  // Better to error here, because if we wait until we're in the middle of
  // building the context, the managed portion (keylist) would be incomplete
  // and tripped on by the GC if we didn't do some kind of workaround.

    for (const Element* check = item; check != tail; ++check) {
        if (Is_Space(check))  // makes "drain", doesn't need rebinding
            continue;

        if (
            Type_Of_Raw(check) <= MAX_TYPE_NOQUOTE_QUASI_OK
            or Type_Of(check) == TYPE_QUOTED_1_TIME_NONQUASI
        ){
            HeartsigilByte byte = HEARTSIGIL_BYTE(check);
            if (
                byte == Byte_From_Heart(HEART_WORD)
                or byte == Byte_From_Heart_And_Sigil(HEART_WORD, SIGIL_META)
            ){
                if (not binder)
                    binder = Construct_Binder();
                continue;
            }
            else if (
                byte == Byte_From_Heart_And_Sigil(HEART_WORD, SIGIL_TIE)
            ){
                continue;
            }
        }

        return fail (Error_Bad_Value(check));
    }

} make_object: {

  // 1. Tied word indicates that we wish to use the original binding.  So
  //    `for-each $x [1 2 3] [...]` will actually set that x instead of making
  //    a new one.  We use the ALIAS dual convention.

    // KeyLists are always managed, but varlist is unmanaged by default (so
    // it can be freed if there is a problem)
    //
    VarList* varlist = Alloc_Varlist(HEART_OBJECT, num_vars);

    Option(Error*) error = SUCCESS;

    SymId dummy_sym = SYM_DUMMY1;

    Index index = 1;
    for (; index <= num_vars; ++index, ++item) {
        const Symbol* symbol;

        if (Is_Space(item)) {
            if (dummy_sym == SYM_DUMMY9)
                error = Error_User(
                    "Current limitation: only up to 9 foreign/space keys"
                );

            symbol = Canon_Symbol(dummy_sym);
            dummy_sym = cast(SymId, cast(int, dummy_sym) + 1);

            Init(Slot) slot = Append_Context(varlist, symbol);
            Init_Bedrock_Drain(slot);
            Track_Shield_Cell(slot);

            if (binder)
                Add_Binder_Index(binder, symbol, -1);  // for remove

            continue;
        }

        symbol = Word_Symbol(item);

        HeartsigilByte byte = HEARTSIGIL_BYTE(item);

        Init(Slot) slot = Append_Context(varlist, symbol);

        if (byte == Byte_From_Heart_And_Sigil(HEART_WORD, SIGIL_TIE)) {
            if (dummy_sym == SYM_DUMMY9)
                error = Error_User(
                    "Current limitation: only up to 9 foreign/space keys"
                );

            symbol = Canon_Symbol(dummy_sym);
            dummy_sym = cast(SymId, cast(int, dummy_sym) + 1);

            Element* copy = Copy_Cell_May_Bind(slot, item, binding);
            Force_Cell_Sigil(copy, SIGIL_META);  // make it $word
            Tweak_Cell_Lift_Byte(slot, TYPE_BEDROCK_ALIAS);
            assert(Is_Cell_A_Bedrock_Alias(slot));  // alias uses ^META [1]
        }
        else {
            assert(binder);  // set above

            if (not Try_Add_Binder_Index(binder, symbol, index)) {
                DECLARE_ELEMENT (word);
                Init_Word(word, symbol);
                error = Error_Dup_Vars_Raw(word);
                break;  // note for-each [x $x] can be legal
            }

            Init_Void_Signifying_Unset(slot);
            if (byte == Byte_From_Heart_And_Sigil(HEART_WORD, SIGIL_META))
                Set_Cell_Flag(slot, LOOP_SLOT_ROOT_META);
            else
                assert(byte == Byte_From_Heart(HEART_WORD));
        }

        if (Type_Of(item) == TYPE_QUOTED_1_TIME_NONQUASI)
            Set_Cell_Flag(slot, LOOP_SLOT_FORMAT_UNBIND);
        else
            assert(Type_Of_Raw(item) <= MAX_TYPE_NOQUOTE_NOQUASI);
    }

    // As currently written, the loop constructs which use these contexts
    // will hold pointers into the arrays across arbitrary user code running.
    // If the context were allowed to expand, then this can cause memory
    // corruption:
    //
    // https://github.com/rebol/rebol-issues/issues/2274
    //
    // !!! Because FLEX_FLAG_DONT_RELOCATE is just a synonym for
    // FLEX_FLAG_FIXED_SIZE at this time, it means that there has to be
    // unwritable cells in the extra capacity, to help catch overwrites.  If
    // we wait too late to add the flag, that won't be true...but if we pass
    // it on creation we can't make the context via Append_Context().  Review
    // this mechanic; and for now forego the protection.
    //
    /* Set_Flex_Flag(c, DONT_RELOCATE); */

    if (error) {
        if (binder)
            Destruct_Binder(binder);  // remove bind indices even if failing

        Free_Unmanaged_Flex(Varlist_Array(varlist));
        return fail (unwrap error);
    }

    Manage_Stub(varlist);  // must be managed to use in binding

    // If the user gets ahold of these contexts, we don't want them to be
    // able to expand them...because things like FOR-EACH have historically
    // not been robust to the memory moving.
    //
    Set_Flex_Flag(Varlist_Array(varlist), FIXED_SIZE);

    if (binder) {  // don't modify binding unless we have to
        Tweak_Link_Inherit_Bind(varlist, List_Binding(body));
        Tweak_Cell_Binding(body, varlist);
        Destruct_Binder(binder);
    }

    return varlist;
}}


//
//  Read_Slot_Dual: C
//
void Read_Slot_Dual(Sink(Value) out, const Slot* slot)
{
    if (Is_Bedrock(slot))
        Copy_Plain_Cell(out, slot);
    else
        Copy_Lifted_Cell(out, As_Value(slot));
}


//
//  Read_Slot_Meta: C
//
// Create_Loop_Context_May_Bind_Body() allows $WORD! for reusing an existing
// variable's binding:
//
//     x: 10
//     for-each $x [20 30 40] [...]
//     ; The 10 will be overwritten, and x will be equal to 40, here
//
// It accomplishes this by putting a word into the "variable" slot, and having
// a flag to indicate a dereference is necessary.
//
Result(None) Read_Slot_Meta(Sink(Value) out, const Slot* slot)
{
    if (Not_Bedrock(slot)) {
        const Value* var = Slot_Hack(slot);
        Copy_Cell(out, var);
        return none;
    }

  handle_dual_slot: {

    // e.g. `for-each _ [1 2 3] [...]` sets slot to "toss values"

    assert(not Is_Cell_A_Bedrock_Drain(slot));

    if (Is_Cell_A_Bedrock_Hole(slot)) {
        Init_Null_Signifying_Unspecialized(out);
        return none;
    }

    assert(Is_Cell_A_Bedrock_Alias(slot));

    DECLARE_ELEMENT (temp);  // don't have to guard--slot guards
    Copy_Cell_Core(temp, slot, CELL_MASK_COPY);
    Tweak_Cell_Quoted_Type(temp, HEART_WORD);
    unnecessary(Push_Lifeguard(temp));  // slot protects it.

    if (rebRunThrows(out, CANON(GET), temp))
        return fail (Error_No_Catch_For_Throw(TOP_LEVEL));

    return none;
}}


//
//  Read_Slot: C
//
Result(None) Read_Slot(Sink(Stable) out, const Slot* slot) {
    Sink(Value) atom_out = raw_cast(Value*, out);
    trap (
      Read_Slot_Meta(atom_out, slot)
    );
    if (Not_Cell_Stable(atom_out))
        return fail ("Cannot read unstable slot with Read_Slot()");
    return none;  // out is As_Stable()
}


//
//  Write_Loop_Slot_May_Unbind_Or_Decay: C
//
// Loops need to remember the decorations on the iterative variables, in order
// to know if they should unbind or decay the values.  This information does
// not apply to *all* writes to those variables: only the writes performed by
// the loop itself.  Hence a special write function is used.
//
// (It could be done another way by preserving the iterative variables and
// looking at the decorations on them each time they are written to, but this
// approach seems more efficient.)
//
Result(None) Write_Loop_Slot_May_Unbind_Or_Decay(Slot* slot, Value* v)
{
    if (Not_Cell_Flag(slot, LOOP_SLOT_ROOT_META)) {
        require (
            Decay_If_Unstable(v)
        );
    }

    if (Is_Cell_A_Bedrock_Drain(slot))  // e.g. `for-each _ [1 2 3] [...]`
        return none;  // toss it (we decayed first, in case it is undecayable)

    if (Get_Cell_Flag(slot, LOOP_SLOT_FORMAT_UNBIND))
        Unbind_Cell_If_Bindable_Core(v);

    if (Not_Bedrock(slot)) {  // ordinary write
        Copy_Cell(raw_cast(Value*, slot), v);
        return none;
    }

    assert(Is_Cell_A_Bedrock_Alias(slot));

    DECLARE_ELEMENT (temp);
    Copy_Cell(temp, raw_cast(Element*, slot));
    Tweak_Cell_Quoted_Type(temp, HEART_WORD);
    unnecessary(Push_Lifeguard(temp));  // slot protects it.

    rebElide(CANON(SET), temp, rebQ(v));  // may be writing alias, etc.

    return none;
}


#if RUNTIME_CHECKS

//
//  Assert_Cell_Binding_Valid_Core: C
//
void Assert_Cell_Binding_Valid_Core(const Cell* cell)
{
    Option(Heart) heart = Unchecked_Heart_Of(cell);
    if (not Is_Bindable_Heart(heart))
        return;

    Context* binding = raw_cast(Context*, cell->extra.base);
    if (not binding)
        return;

    assert(Type_Of_Raw(cell) < MIN_TYPE_ANTIFORM);  // no bindings

    assert(Is_Base(binding));
    assert(Is_Base_Managed(binding));
    assert(Is_Base_A_Stub(binding));
    assert(Is_Base_Readable(binding));

    if (heart == HEART_FRAME) {
        assert(Is_Stub_Varlist(binding));  // actions/frames bind contexts only
        return;
    }

    if (Is_Stub_Let(binding)) {
        return;
    }

    if (Is_Stub_Patch(binding)) {
        assert(!"Direct binding to module patch cells is not allowed");
        return;
    }

    if (Is_Stub_Use(binding)) {
        /*assert(Is_Cell_Listlike(cell));  // can't bind words to use */
        return;
    }

    if (Is_Stub_Details(binding)) {  // relative binding
        /* assert(Is_Cell_Listlike(cell)); */  // weird word cache trick uses
        return;
    }

    if (Is_Stub_Sea(binding)) {
        // attachment binding no longer exists
        return;
    }

    assert(Is_Stub_Varlist(binding));
}

#endif
