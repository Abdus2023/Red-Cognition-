//
//  file: %cast-cells.hpp
//  summary: "Instrumented operators for casting Cell subclasses"
//  project: "Ren-C Interpreter and Run-time"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012-2025 Ren-C Open Source Contributors
//
// See README.md and CREDITS.md for more information
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//
// See src/include/casts/README.md for general information about CastHook.
//
// This file is specifically for checking casts to Cells.
//
// One benefit is we can check cells for valid readability at the moment of
// the cast.  While this doesn't seem too profound since attempts to read
// the Cell would trigger failures anyway even without the casts...it does
// help with locality.  Also makes sure that locations are accurately labeled
// as to whether they have a valid Element/Value/Value or are Sink()/Init().
//
// Another big benefit is that casts to Element can enusre that no antiforms
// are in the cell, and casts to Value don't hold unstable antiforms.  This
// could be accomplished without casts with helper functions such as
// As_Element() or As_Stable(), but using a cast makes the checks
// work generically in macros parameterized by type.  Also, using a cast
// helps point out "ugliness" that encourages caution at these points, and
// looking to find another way to do it.
//
//=//// NOTES /////////////////////////////////////////////////////////////=//
//
// A. CastHook<> has two parameters (From and To types), but we pin down the
//    "To" type, then match a pattern for any "From" type (F).
//
// B. See the definition of CastHook for why the generalized casting
//    mechanic runs through const pointers only.
//
// C. See the definitions of UpcastTag and DowncastTag for an explanation of
//    why we trust upcasts by default (you can override it if needed).
//

// We don't bother with the "trusted" upcast here (yet?) but just check all
// conversions from these types.
//
DECLARE_C_TYPE_LIST(g_convertible_to_cell,
    Pairing,  // same size as Stub, holds two Cells
    char  // some memory blobs use char* for debuggers to read UTF-8 easier
);


//=//// cast(Slot*, ...) //////////////////////////////////////////////////=//

template<typename F>  // [A]
struct CastHook<const F*, const Slot*> {  // both must be const [B]
    static const bool legal = g_convertible_to_cell::contains<F>::value;

    static void Validate_Bits(const F* p) {
        if (not p)
            return;

        const Cell* c = c_cast(const Cell*, p);
        Assert_Cell_Readable(c);
    }
};


//=//// cast(Param*, ...) /////////////////////////////////////////////////=//

// Param has only one legal state that's not legal for Value... and that is
// the "hole" state of a bedrock parameter used to indicate no specialization.
//
// Before a function starts running, this is also the only legal values that
// can be in a FRAME!...but once the frame is running, it's possible to put
// any slot value into the context (e.g. locals can become aliases, etc.)
//
// !!! This puts some limitations on redo of FRAME!s, or typechecking between
// levels of adaptation.  Also aliased variables.  Rethink as this evolves

template<typename F>  // [A]
struct CastHook<const F*, const Param*> {  // both must be const [B]
    static const bool legal = g_convertible_to_cell::contains<F>::value;

    static void Validate_Bits(const F* p) {
        if (not p)
            return;

        const Cell* c = c_cast(const Cell*, p);
        Assert_Cell_Readable(c);
        assert(Type_Of_Raw(c) <= MAX_TYPE_PARAM);
    }
};


//=//// cast(Value*, ...) //////////////////////////////////////////////////=//

template<typename F>  // [A]
struct CastHook<const F*, const Value*> {  // both must be const [B]
  static const bool legal = g_convertible_to_cell::contains<F>::value;

  static void Validate_Bits(const F* p) {
    if (not p)
        return;

    const Cell* c = c_cast(const Cell*, p);
    Assert_Cell_Readable(c);
    assert(Type_Of_Raw(c) < MIN_TYPE_BEDROCK);  // bedrock is only illegal lift
  }
};


//=//// cast(Stable*, ...) //////////////////////////////////////////////////=//

template<typename F>  // [A]
struct CastHook<const F*, const Stable*> {  // both must be const [B]
  static const bool legal = g_convertible_to_cell::contains<F>::value;

  static void Validate_Bits(const F* p) {
    if (not p)
        return;

    const Cell* c = c_cast(const Cell*, p);
    Assert_Cell_Readable(c);
    assert(Type_Of_Raw(c) <= MAX_TYPE_STABLE);
  }
};


//=//// cast(Element*, ...) ///////////////////////////////////////////////=//

template<typename F>  // [A]
struct CastHook<const F*, const Element*> {  // both must be const [B]
    static const bool legal = g_convertible_to_cell::contains<F>::value;

    static void Validate_Bits(const F* p) {
        if (not p)
            return;

        const Cell* c = c_cast(const Cell*, p);
        Assert_Cell_Readable(c);
        assert(Type_Of_Raw(c) < MIN_TYPE_ANTIFORM);
    }
};


//=//// cast(Dual*, ...) //////////////////////////////////////////////////=//

// Same rules as Element* (just a different meaning: ordinary cells are the
// lifted states, while bedrock states are represented by NOQUOTE_63).

template<typename F>  // [A]
struct CastHook<const F*, const Dual*> {  // both must be const [B]
    static const bool legal = g_convertible_to_cell::contains<F>::value;

    static void Validate_Bits(const F* p) {
        if (not p)
            return;

        const Cell* c = c_cast(const Cell*, p);
        Assert_Cell_Readable(c);
        assert(Type_Of_Raw(c) < MIN_TYPE_ANTIFORM);
    }
};
