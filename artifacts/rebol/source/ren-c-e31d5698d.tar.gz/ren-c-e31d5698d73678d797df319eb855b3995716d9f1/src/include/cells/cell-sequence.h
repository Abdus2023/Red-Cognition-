//
//  file: %cell-sequence.h
//  summary: "Common Definitions for Immutable Interstitially-Delimited Lists"
//  project: "Rebol 3 Interpreter and Run-time (Ren-C branch)"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012-2024 Ren-C Open Source Contributors
// Copyright 2012 REBOL Technologies
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information.
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//
// A "Sequence" is a constrained "arraylike" type with elements separated by
// interstitial delimiters.  Three basic forms are TUPLE! (separated by `.`),
// CHAIN! (separated by ':'), and PATH! (separated by `/`)
//
//     192.168.0.1       ; a 4-element TUPLE!
//     append:dup:part   ; a 3-element CHAIN!
//     lib/insert        ; a 2-element PATH!
//
// Because they are defined by separators *between* elements, sequences of
// zero or one item are not legal.  (This is one reason why they are immutable:
// so the constraint of having at least two items can be validated at the time
// of creation.)
//
// Both forms are allowed to contain WORD!, INTEGER!, GROUP!, BLOCK!, TEXT!,
// and TAG!.  Quasiforms of these types (where legal) are also permitted.
// There are versions with Sigil as well.
//
//     <abc>/(d e f)/[g h i]    ; a 3-element PATH!
//     foo.1.bar                ; a 3-element TUPLE!
//     ^abc.(def)               ; a 2-element ^TUPLE!
//     @<a>/<b>/<c>             ; a 3-element @TUPLE!
//     ~/home/README            ; a 3-element PATH!
//
// PATH!s may contain TUPLE!s, but not vice versa.  This means that mixed
// usage can be interpreted unambiguously:
//
//     a.b.c/d.e.f    ; a 2-element PATH! containing 3-element TUPLEs
//     a/b/c.d/e/f    ; a 5-element PATH! with 2-element TUPLE! in the middle
//
// It is also legal to put SPACE in slots at the head or tail.  They render
// invisibly, allowing you to begin or terminate sequences with the delimiter:
//
//     .foo.bar     ; a 3-element TUPLE! with SPACE in the first slot
//     1/2/3/       ; a 4-element PATH! with SPACE in the last slot
//     /a           ; a 2-element PATH! with SPACE in the first slot
//
// Internal blanks are not allowed.  Because although there might be some
// theoretical use for `a//b` or similar sequences, those aren't as compelling
// as being able to have `http://example.com` be URL! (vs. a 3-element PATH!)
//
// Neither PATH! nor TUPLE may contain "arrow-words" in any slot (those with
// `>` or `<` in their spelling), so interpretation of TAG!s is unambiguous:
//
//     .<.>.     ; a 3-element TUPLE! with TAG! <.> in slot 2
//
//=//// NOTES /////////////////////////////////////////////////////////////=//
//
// A. Reduced cases such as "2-element path" `/` and the "2-element tuple" `.`
//    are instead chosen as WORD!.  This was considered non-negotiable, that
//    `/` be allowed to mean divide.  Making it a PATH! that divided turned
//    out to be much more convoluted than having special word flags.  (See
//    SYMBOL_FLAG_ILLEGAL_IN_ANY_SEQUENCE etc. for how these are handled,
//    where `.` can be put in paths but `/` can't appear in any path or tuple.)
//
// B. The immutability of sequences allows important optimizations in the
//    implementation that minimize allocations.  For instance, the 2-element
//    PATH! of `/foo` can be specially encoded to use no more space
//    than a plain WORD!.  And a 2-element TUPLE! like `a.b` bypasses the need
//    to create an Array tracking entity by pointing directly at a managed
//    "pairing" of 2 cells--the same code used to compress two INTEGER! into
//    a PAIR!.
//
//    (There are also optimizations for encoding short numeric sequences like
//    IP addresses or colors into single cells...which aren't as important but
//    carried over to preserve history of the feature.)
//
// C. Compressed forms detect their compression as follows:
//
//    - Byte compressed forms have CELL_FLAG_DONT_MARK_PAYLOAD_1, which you
//      can test for more clearly with (not Sequence_Has_Pointer(cell))
//
//    - Pair compression has CELL_PAYLOAD_1() with BASE_FLAG_CELL
//
//    - Single WORD! forms have CELL_PAYLOAD_1() as FLAVOR_SYMBOL
//        If CELL_FLAG_LEADING_BLANK it is either a `/foo` or `.foo` case
//        Without the flag, it is either a `foo/` or `foo.` case
//
//    - Uncompressed forms have CELL_PAYLOAD_1() as FLAVOR_SOURCE
//


// 1. Quasiforms are legal in paths--which is one of the reasons why paths
//    themselves aren't allowed to be quasiforms.  Because `~/foo/~` is more
//    useful as a 3-element path with quasiform blanks in the first and last
//    positions, than a quasiform path is useful.
//
//    (Note that exceptions like [~/~ ~//~ ~...~] are quasi-words.)
//
INLINE Result(None) Check_Sequence_Element(
    Heart sequence_heart,
    const Element* v,
    bool is_head
){
    assert(Any_Sequence_Heart(sequence_heart));

    Option(Heart) h = Heart_Of(v);

    if (is_head) {  // note quasiforms legal, even at head [1]
        if (
            Is_Quoted(v)  // 'foo:bar has quote on foo:bar, not foo
            or Cell_Underlying_Sigil(v)  // $a.b => $[a b], not [$a b]
        ){
            return fail (Error_Bad_Sequence_Head_Raw(v));
        }
    }

    if (h == HEART_PATH)  // path can't put be put in path, tuple, or chain
        goto bad_sequence_item;

    if (h == HEART_CHAIN) {  // inserting a chain
        if (sequence_heart == HEART_PATH)
            return none;  // chains can only be put in paths
        goto bad_sequence_item;
    }

    if (h == HEART_TUPLE) {  // inserting a tuple
        if (sequence_heart != HEART_TUPLE)
            return none;  // legal in non-tuple sequences (path, chain)
        goto bad_sequence_item;
    }

    if (h == HEART_BLANK) {  // heart of quasars, sigils, lone quote
        assert(not is_head or Is_Quasar(v));  // callers check blanks/sigils
        if (Is_Blank(v))  // undecorated blank (not [$ ^ @ ~ '])
            return fail (
                Error_Bad_Sequence_Blank_Raw()  // blank only legal at head
            );
        return none;  // ~:$:~ etc. are legal
    }

    if (not Any_Sequencable_Heart(h))
        goto bad_sequence_item;

    if (h == HEART_WORD) {
        const Symbol* symbol = Word_Symbol(v);
        if (symbol == CANON(DOT_1) and sequence_heart != HEART_TUPLE)
            return none;
        if (
            sequence_heart != HEART_CHAIN  // !!! temporary for //: -- review
            and Get_Flavor_Flag(SYMBOL, symbol, ILLEGAL_IN_ANY_SEQUENCE)
        ){
            goto bad_sequence_item;  //  [<| |>] => <|/|>  ; tag
        }
        if (sequence_heart == HEART_PATH)
            return none;
        if (Get_Flavor_Flag(SYMBOL, symbol, ILLEGAL_IN_TUPLE))
            goto bad_sequence_item;  // e.g. contains a slash
    }

    return none;  // all other words should be okay

  bad_sequence_item:

    return fail (
        Error_Bad_Sequence_Item_Raw(Datatype_From_Heart(sequence_heart), v)
    );
}


//=//// UNCOMPRESSED ARRAY SEQUENCE FORM //////////////////////////////////=//

#define Init_Any_Sequence_Listlike(out,heart,a) \
    Init_Any_Sequence_At_Listlike((out), (heart), (a), 0)


//=//// Leading-SPACE SEQUENCE OPTIMIZATION ///////////////////////////////=//
//
// Ren-C has no REFINEMENT! datatype, so `:foo` is a CHAIN!, which generalizes
// to where `:foo:bar` is a CHAIN! as well.
//
// In order to make this not cost more than a "REFINEMENT!" word type did in
// R3-Alpha, the underlying representation of `:foo` in the cell is the same
// as a WORD!.  This is true for `/foo` and `foo/` and `.foo` and `foo.` too.
//
// 1. !!! Temporarily raise attention to usage like `.5` or `5.` to guide
//    people that these are contentious with tuples.  There is no other way
//    to represent such tuples--while DECIMAL! has an alternative by
//    including the zero.  This doesn't put any decision in stone, but
//    reserves the right to make a decision at a later time.
//
INLINE Result(Element*) Blank_Head_Or_Tail_Sequencify(
    Element* v,
    Heart heart,
    Flags flag
){
    assert(flag == CELL_MASK_ERASED_0 or flag == CELL_FLAG_LEADING_BLANK);
    assert(Any_Sequence_Heart(heart));

    trap (
      Check_Sequence_Element(
        heart,
        v,
        flag == CELL_MASK_ERASED_0  // 0 means no leading space, item is "head"
    ));

    if (Type_Of_Raw(v) > MAX_TYPE_NOQUOTE_NOQUASI)
        goto cant_optimize_in_situ;  // quote bits mean on sequence itself

    if (Is_Word(v)) {  // in-situ optimization, see [B]
        v->header.bits &= (~ CELL_FLAG_LEADING_BLANK);
        v->header.bits |= flag;
        Tweak_Cell_Type_Matching_Heart(v, heart);
        return v;
    }

    if (Any_List(v)) {  // try mirror optimization
        assert(Is_Group(v) or Is_Block(v) or Is_Fence(v));  // only valid kinds
        const Source* a = Cell_Array(v);
        Option(Heart) mirror = Mirror_Of(a);
        Option(Heart) h = Heart_Of(v);
        if (not mirror or (unwrap mirror == unwrap h)) {
            Tweak_Mirror_Byte(a, unwrap Heart_Of(v));  // remember herat
            Tweak_Cell_Type_Matching_Heart(v, heart);  // e.g. TYPE_BLOCK => TYPE_PATH
            v->header.bits |= flag;
            return v;
        }
    }

    if (Is_Integer(v)) {
        if (heart == HEART_TUPLE) {
            return fail (  // reserve notation for future use [1]
                "5. and .5 currently reserved, please use 5.0 and 0.5"
            );
        }
        // fallthrough (should be able to single cell optimize any INTEGER!)
    }

  cant_optimize_in_situ: {

  // There simply aren't enough bits in the 32-bit version of a Cell to be
  // able to store both the type of a sequence and the type of the element
  // in the optimized sequence representation for arbitrary types.  The 64-bit
  // builds *could* use the extra header bits to optimize any single Cell
  // as a sequence...but would it want to use the bits for that?
  //
  // Given that we don't have space for every combination we make a Stub
  // (pairing node) for the unoptimized cases.

    Pairing* p = Alloc_Pairing(BASE_FLAG_MANAGED);
    if (flag == CELL_FLAG_LEADING_BLANK) {
        Init_Blank(Pairing_First(p));
        Copy_Cell(Pairing_Second(p), v);
    }
    else {
        Copy_Cell(Pairing_First(p), v);
        Init_Blank(Pairing_Second(p));
    }

    Reset_Cell_Header(
        v,
        FLAG_HEART_AND_LIFT(heart)
            | (not CELL_FLAG_DONT_MARK_PAYLOAD_1)  // mark the pairing
            | CELL_FLAG_DONT_MARK_PAYLOAD_2  // payload second not used
    );
    Tweak_Cell_Binding(v, UNBOUND);  // "arraylike", needs binding
    SERIESLIKE_PAYLOAD_1_BASE(v) = p;
    Corrupt_Unused_Field(v->payload.split.two.corrupt);

    return v;
}}

#define Setify(elem) \
    Blank_Head_Or_Tail_Sequencify((elem), HEART_CHAIN, CELL_MASK_ERASED_0)

#define Refinify(elem) \
    Blank_Head_Or_Tail_Sequencify((elem), HEART_CHAIN, CELL_FLAG_LEADING_BLANK)

#define Getify(elem)  Refinify(elem)  // !!! Update!


//=//// BYTE-SIZED INTEGER! SEQUENCE OPTIMIZATION /////////////////////////=//
//
// Rebol's historical TUPLE! was limited to a compact form of representing
// byte-sized integers in a cell.  That optimization is used when possible,
// either when initialization is called explicitly with a byte buffer or
// when it is detected as applicable to a generated TUPLE!.
//
// This allows 8 single-byte integers to fit in a cell on 32-bit platforms,
// and 16 single-byte integers on 64-bit platforms.  If that is not enough
// space, then an array is allocated.
//
// !!! Since arrays use full cells for INTEGER! values, it would be more
// optimal to allocate an immutable binary series for larger allocations.
// This will likely be easy to reuse in an RUNE!+CHAR! unification, so
// revisit this low-priority idea at that time.

INLINE Result(Element*) Init_Any_Sequence_Bytes(
    Init(Element) out,
    Heart heart,
    const Byte* data,
    Size size
){
    assert(Any_Sequence_Heart(heart));
    Reset_Cell_Header(
        out,
        FLAG_HEART_AND_LIFT(heart)
            | CELL_MASK_NO_MARKING
    );
    Tweak_Cell_Binding(out, UNBOUND);  // paths bindable, can't have garbage

    if (size > Size_Of(out->payload.at_least_8) - 1) {  // too big
        Source* a = Make_Source_Managed(size);
        for (; size > 0; --size, ++data) {
            trap (
              Sink(Element) cell = Alloc_Tail_Array(a)
            );
            Init_Integer(cell, *data);
        }
        Init_Block(out, Freeze_Source_Shallow(a));  // !!! TBD: compact BLOB!
    }
    else {
        out->payload.at_least_8[IDX_SEQUENCE_USED] = size;
        Byte* dest = out->payload.at_least_8 + 1;
        for (; size > 0; --size, ++data, ++dest)
            *dest = *data;
    }

    return out;
}

#define Init_Tuple_Bytes(out,data,len) \
    Init_Any_Sequence_Bytes((out), HEART_TUPLE, (data), (len))

INLINE Option(Element*) Try_Init_Any_Sequence_All_Integers(
    Init(Element) out,
    Heart heart,
    const Stable* head,  // NOTE: Can't use PUSH() or evaluation
    REBLEN len
){
    assert(Any_Sequence_Heart(heart));

    if (len > Size_Of(out->payload.at_least_8) - 1)
        return nullptr;  // no optimization yet if won't fit in payload bytes

    if (len < 2)
        return nullptr;

    Reset_Cell_Header(
        out,
        FLAG_HEART_AND_LIFT(heart)
            | CELL_MASK_NO_MARKING
    );
    Tweak_Cell_Binding(out, UNBOUND);  // paths are bindable, can't be garbage

    out->payload.at_least_8[IDX_SEQUENCE_USED] = len;

    Byte* bp = out->payload.at_least_8 + 1;

    const Stable* item = head;
    REBLEN n;
    for (n = 0; n < len; ++n, ++item, ++bp) {
        if (not Is_Integer(item))
            return nullptr;
        REBI64 i64 = VAL_INT64(item);
        if (i64 < 0 or i64 > 255)
            return nullptr;  // only packing byte form for now
        *bp = i_cast(Byte, i64);
    }

    return out;
}


//=//// 2-Element "PAIR" SEQUENCE OPTIMIZATION ////////////////////////////=//

INLINE Result(Element*) Init_Any_Sequence_Or_Conflation_Pairlike(
    Init(Element) out,
    Heart heart,
    const Element* first,
    const Element* second
){
    assert(Any_Sequence_Heart(heart));

    if (
        (Is_Quasar(first) and Is_Quasar(second))  // ~/~ is a WORD!
        or (Is_Blank(first) and Is_Blank(second))  // plain / is a WORD!
    ){
        if (heart == HEART_PATH)
            Init_Word(out, CANON(SLASH_1));
        else if (heart == HEART_CHAIN)
            Init_Word(out, CANON(COLON_1));
        else {
            assert(heart == HEART_TUPLE);
            Init_Word(out, CANON(DOT_1));
        }
        if (Is_Quasar(first))
            Tweak_Cell_Lift_Byte(out, TYPE_QUASIFORM);
        return out;
    }

    if (Is_Blank(first)) {  // try optimize e.g. `/a` or `.a` or `:a` etc.
        Copy_Cell(out, second);
        return Blank_Head_Or_Tail_Sequencify(
            out, heart, CELL_FLAG_LEADING_BLANK
        );
    }
    else if (Is_Blank(second)) {
        Copy_Cell(out, first);
        return Blank_Head_Or_Tail_Sequencify(  // optimize `a/` or `a:`
            out, heart, CELL_MASK_ERASED_0
        );
    }

    if (Is_Integer(first) and Is_Integer(second)) {
        REBI64 i1 = VAL_INT64(first);
        REBI64 i2 = VAL_INT64(second);

        if (heart == HEART_TUPLE) {  // conflates with decimal, e.g. 10.20
            REBI64 magnitude = 1;
            REBI64 r = i2;
            do {
                magnitude *= 10;
                r = r / 10;
            } while (r != 0);

            REBDEC d = cast(REBDEC, i1) + cast(REBDEC, i2) / magnitude;
            return Init_Decimal(out, d);
        }

        if (heart == HEART_CHAIN) {  // conflates with time, e.g. 10:20
            REBI64 nano = ((i1 * 60 * 60) + (i2 * 60)) * SEC_SEC;
            return Init_Time_Nanoseconds(out, nano);
        }

        Byte buf[2];
        if (i1 >= 0 and i2 >= 0 and i1 <= 255 and i2 <= 255) {
            buf[0] = i_cast(Byte, i1);
            buf[1] = i_cast(Byte, i2);
            require (
              Init_Any_Sequence_Bytes(out, heart, buf, 2)
            );
            return out;
        }

        // fall through
    }

    trap (
      Check_Sequence_Element(heart, first, true)
    );
    trap (
      Check_Sequence_Element(heart, second, false)
    );

    Pairing* pairing = Alloc_Pairing(BASE_FLAG_MANAGED);
    Copy_Cell(Pairing_First(pairing), first);
    Copy_Cell(Pairing_Second(pairing), second);

    Reset_Cell_Header(
        out,
        FLAG_HEART_AND_LIFT(heart)
            | (not CELL_FLAG_DONT_MARK_PAYLOAD_1)  // first is pairing
            | CELL_FLAG_DONT_MARK_PAYLOAD_2  // payload second not used
    );
    Tweak_Cell_Binding(out, UNBOUND);  // "arraylike", needs binding
    PAIRLIKE_PAYLOAD_1_PAIRING_BASE(out) = pairing;
    Corrupt_Unused_Field(out->payload.split.two.corrupt);

    return out;
}


INLINE Result(Element*) Init_Any_Sequence_Pairlike(
    Init(Element) out,
    Heart heart,
    const Element* first,
    const Element* second
){
    trap (
      Init_Any_Sequence_Or_Conflation_Pairlike(out, heart, first, second)
    );

    if (not Any_Sequence(out))
        return fail (Error_Conflated_Sequence_Raw(Datatype_Of(out), out));

    return out;
}

INLINE Result(Element*) Pop_Sequence_Or_Conflation(
    Init(Element) out,
    Heart heart,
    StackIndex base
){
    if (TOP_INDEX - base < 2) {
        Drop_Data_Stack_To(base);
        return fail (Error_Sequence_Too_Short_Raw());
    }

    if (TOP_INDEX - base == 2) {  // two-element path optimization
        Option(Error*) error = SUCCESS;
        Init_Any_Sequence_Or_Conflation_Pairlike(
            out,
            heart,
            TOP_ELEMENT - 1,
            TOP_ELEMENT
        ) except (Error* e) {
            // drop stack before returning error
            error = e;
        };
        Drop_Data_Stack_To(base);
        if (error)
            return fail (unwrap error);
        return out;
    }

    if (Try_Init_Any_Sequence_All_Integers(  // optimize e.g. 192.0.0.1
        out,
        heart,
        Data_Stack_At(Element, base) + 1,
        TOP_INDEX - base
    )){
        Drop_Data_Stack_To(base);  // optimization worked! drop stack...
        return out;
    }

    assert(TOP_INDEX - base > 2);  // guaranteed from above
    Source* a = Pop_Managed_Source_From_Stack(base);
    Freeze_Source_Shallow(a);
    return Init_Any_Sequence_Listlike(out, heart, a);
}

INLINE Result(Element*) Pop_Sequence(
    Init(Element) out,
    Heart heart,
    StackIndex base
){
    trap (
      Pop_Sequence_Or_Conflation(out, heart, base)
    );
    if (not Any_Sequence(out))
        return fail (Error_Conflated_Sequence_Raw(Datatype_Of(out), out));

    return out;
}


// This is a general utility for turning stack values into something that is
// either pathlike or value like.  It is used in COMPOSE of paths, which
// allows things like:
//
//     >> compose $(void)/a
//     == a
//
//     >> compose $(space)/a
//     == /a
//
//     >> compose @ (void)/(void)/(void)
//     == ~null~  ; anti
//
// While you can't create a PATH! or TUPLE! out of just blanks, this function
// will decay two blanks in a path to the WORD! `/` and two blanks in a tuple
// to the WORD! '.' -- this could be extended to allow more blanks to get words
// like `///` if that were deemed interesting.
//
INLINE Result(Stable*) Pop_Sequence_Or_Element_Or_Null(
    Init(Stable) out,
    Heart sequence_heart,
    StackIndex base
){
    if (TOP_INDEX == base)  // nothing to pop
        return Init_Null(out);

    if (TOP_INDEX - 1 == base) {  // only one item, use as-is if possible
        Move_Cell(out, TOP_ELEMENT);  // ensures element
        DROP();  // balances stack

        if (not Is_Blank(out)) {  // allow .(void) to be . if COMPOSE'd
            trap (
              Check_Sequence_Element(
                sequence_heart,
                cast(Element*, out),
                false  // don't think of it as head, or do?
            ));
        }

        return out;  // let the item just decay to itself as-is
    }

    return Pop_Sequence_Or_Conflation(out, sequence_heart, base);
}


// Note that paths can be initialized with an array, which they will then
// take as immutable...or you can create a `/foo`-style path in a more
// optimized fashion using Refinify()

INLINE Length Sequence_Len(const Cell* c) {
    assert(Has_Sequence_Heart(c));

    if (not Sequence_Has_Pointer(c)) {  // compressed bytes
        assert(not Cell_Payload_2_Needs_Mark(c));
        return c->payload.at_least_8[IDX_SEQUENCE_USED];
    }

    const Base* payload1 = CELL_PAYLOAD_1(c);
    if (Is_Base_A_Cell(payload1))  // see if it's a pairing
        return 2;  // compressed 2-element sequence, sizeof(Stub)

    switch (Stub_Flavor(cast(Flex*, payload1))) {
      case FLAVOR_SYMBOL :  // compressed single WORD! sequence
        return 2;

      case FLAVOR_SOURCE : {  // uncompressed sequence
        const Source* a = cast(Source*, payload1);
        if (Mirror_Of(a))
            return 2;  // e.g. `(a):` stores TYPE_GROUP in the mirror byte
        assert(Array_Len(a) >= 2);
        assert(Is_Source_Frozen_Shallow(a));
        return Array_Len(a); }

      default :
        assert(false);
        DEAD_END;
    }
}

// Paths may not always be implemented as arrays, so this mechanism needs to
// be used to read the pointers.  Writes to the passed in location.
//
// 1. It would sometimes be possible to return a pointer into the array and
//    not copy a cell.  But
//
// 2. Because the cell is being viewed as a PATH! or TUPLE!, we cannot view
//    it as a WORD! unless we fiddle the bits at a new location.  The cell
//    is relative and may be at a quote level.
//
// 3. The quotes must be removed because the quotes are intended to be "on"
//    the path or tuple.  If implemented as a pseudo-WORD!
//
// 4. "Mirror Bytes" are the idea that things like a GROUP! or a BLOCK! which
//    are put into a sequence already have a Stub allocated, and that array
//    Stub has a place where size is written for non-array types when using
//    the small series optimization.
//
INLINE Element* Copy_Sequence_At_Untracked(
    Sink(Element) out,
    const Cell* sequence,
    Index n
){
    assert(out != sequence);
    assert(Any_Sequence_Heart(Unchecked_Heart_Of(sequence)));

    if (not Sequence_Has_Pointer(sequence)) {  // compressed bytes
        assert(n < sequence->payload.at_least_8[IDX_SEQUENCE_USED]);
        return Init_Integer(out, sequence->payload.at_least_8[n + 1]);
    }

    const Base* payload1 = CELL_PAYLOAD_1(sequence);
    if (Is_Base_A_Cell(payload1)) {  // test if it's a pairing
        const Pairing* p = cast(Pairing*, payload1);  // compressed pair
        if (n == 0) {
            Copy_Cell(out, Pairing_First(p));
            return out;
        }
        assert(n == 1);
        Copy_Cell_Untracked(out, Pairing_Second(p));
        return out;
    }

    switch (Stub_Flavor(raw_cast(Flex*, payload1))) {
      case FLAVOR_SYMBOL : {  // compressed single WORD! sequence
        assert(n < 2);
        if (Get_Cell_Flag(sequence, LEADING_BLANK) ? n == 0 : n != 0)
            return Init_Blank(out);

        Copy_Cell_Core_Untracked(out, sequence, CELL_MASK_COPY);  // [2]
        Tweak_Cell_Type_Matching_Heart(out, HEART_WORD);  // [3]
        return out; }

      case FLAVOR_SOURCE : {  // uncompressed sequence, or compressed "mirror"
        const Source* a = cast(Source*, SERIESLIKE_PAYLOAD_1_BASE(sequence));
        Option(Heart) mirror = Mirror_Of(a);
        if (mirror) {  // [4]
            assert(n < 2);
            if (Get_Cell_Flag(sequence, LEADING_BLANK) ? n == 0 : n != 0)
                return Init_Blank(out);

            Copy_Cell_Core_Untracked(out, sequence, CELL_MASK_COPY);
            Tweak_Cell_Type_Matching_Heart(out, unwrap mirror);  // [3]
            return out;
        }
        assert(Array_Len(a) >= 2);
        assert(Is_Source_Frozen_Shallow(a));
        return Copy_Cell(out, Array_At(a, n)); }

      default :
        assert(false);
        DEAD_END;
    }
}

#define Copy_Sequence_At(out,sequence,n) \
    TRACK(Copy_Sequence_At_Untracked((out), (sequence), (n)))

INLINE Element* Copy_Sequence_At_May_Bind_Untracked(
    Init(Element) out,
    const Element* sequence,
    Index n,
    Context* context
){
    Copy_Sequence_At(out, sequence, n);
    if (Is_Bindable_Heart(Unchecked_Heart_Of(out)))
        Bind_Cell_If_Unbound(out, context);
    return out;
}

#define Copy_Sequence_At_May_Bind(out,sequence,n,context) \
    TRACK(Copy_Sequence_At_May_Bind_Untracked( \
        (out), (sequence), (n), (context)))

INLINE Byte Sequence_Byte_At(const Cell* sequence, REBLEN n) {
    DECLARE_ELEMENT (at);
    Copy_Sequence_At(at, sequence, n);
    if (not Is_Integer(at))
        panic ("Sequence_Byte_At() used on non-byte ANY-SEQUENCE?");
    return VAL_UINT8(at);  // !!! All callers of this routine need vetting
}

INLINE Context* Sequence_Binding(const Element* sequence) {
    assert(Has_Sequence_Heart(sequence));

    // Getting the binding for any of the optimized types means getting
    // the binding for *that item in the sequence*; the sequence itself
    // does not provide a layer of communication connecting the interior
    // to a frame instance (because there is no actual layer).

    if (not Sequence_Has_Pointer(sequence))  // compressed bytes
        return SPECIFIED;

    const Base* payload1 = CELL_PAYLOAD_1(sequence);
    if (Is_Base_A_Cell(payload1))  // see if it's a pairing
        return Cell_Binding(sequence);  // compressed 2-element sequence

    switch (Stub_Flavor(cast(Flex*, payload1))) {
      case FLAVOR_SYMBOL:  // compressed single WORD! sequence
        return SPECIFIED;

      case FLAVOR_SOURCE: {  // uncompressed sequence
        const Source* a = Cell_Array(sequence);
        if (Mirror_Of(a))
            return SPECIFIED;
        return Cell_Binding(sequence); }

      default :
        assert(false);
        DEAD_END;
    }
}


// !!! This is a simple compatibility routine for all the tuple-using code
// that was hanging around before (IMAGE!, networking) which assumed that
// tuples could only contain byte-sized integers.  All callsites referring
// to it are transitional.
//
INLINE bool Try_Get_Sequence_Bytes(
    void* buf,
    const Cell* sequence,
    Size buf_size
){
    Length len = Sequence_Len(sequence);

    Byte* dp = cast(Byte*, buf);
    Size i;
    DECLARE_ELEMENT (temp);
    for (i = 0; i < buf_size; ++i) {
        if (i >= len) {
            dp[i] = 0;
            continue;
        }
        Copy_Sequence_At(temp, sequence, i);
        if (not Is_Integer(temp))
            return false;
        REBI64 i64 = VAL_INT64(temp);
        if (i64 < 0 or i64 > 255)
            return false;

        dp[i] = cast(Byte, i64);
    }
    return true;
}

INLINE void Get_Tuple_Bytes(
    void *buf,
    const Cell* tuple,
    Size buf_size
){
    assert(Heart_Of(tuple) == HEART_TUPLE);
    if (not Try_Get_Sequence_Bytes(buf, tuple, buf_size))
        panic ("non-INTEGER! found used with Get_Tuple_Bytes()");
}

#define MAX_TUPLE \
    ((Size_Of(uint32_t) * 2))  // !!! No longer a "limit", review callsites



//=//// REFINEMENTS AND PREDICATES ////////////////////////////////////////=//


INLINE Element* Init_Set_Word(Init(Element) out, const Symbol* s) {
    Init_Word(out, s);
    Tweak_Cell_Type_Matching_Heart(out, HEART_CHAIN);
    impossible(Get_Cell_Flag(out, LEADING_BLANK));
    return out;
}

INLINE Element* Init_Get_Word(Init(Element) out, const Symbol* s) {
    Init_Word(out, s);
    Tweak_Cell_Type_Matching_Heart(out, HEART_CHAIN);
    Set_Cell_Flag(out, LEADING_BLANK);
    return out;
}


INLINE Option(SingleHeart) Try_Get_Sequence_Singleheart(const Cell* c) {
    assert(Has_Sequence_Heart(c));

    if (not Sequence_Has_Pointer(c))  // compressed bytes
        return NOT_SINGLEHEART_0;

    if (Is_Base_A_Cell(SERIESLIKE_PAYLOAD_1_BASE(c))) {
        const Pairing* p = cast(Pairing*, PAIRLIKE_PAYLOAD_1_PAIRING_BASE(c));

        if (Is_Blank(Pairing_First(p)))
            return Leading_Blank_And(Heart_Of_Builtin(Pairing_Second(p)));

        if (Is_Blank(Pairing_Second(p)))
            return Trailing_Blank_And(Heart_Of_Builtin(Pairing_First(p)));

        return NOT_SINGLEHEART_0;
    }

    const Flex* f = cast(Flex*, SERIESLIKE_PAYLOAD_1_BASE(c));
    if (Stub_Flavor(f) == FLAVOR_SYMBOL) {
        if (c->header.bits & CELL_FLAG_LEADING_BLANK)
            return LEADING_BLANK_AND(WORD);

        return TRAILING_BLANK_AND(WORD);
    }

    Option(Heart) mirror = Mirror_Of(raw_cast(const Source*, f));
    if (not mirror)  // s actually is sequence elements, not one element
        return NOT_SINGLEHEART_0;

    if (c->header.bits & CELL_FLAG_LEADING_BLANK)
        return Leading_Blank_And(unwrap mirror);

    return Trailing_Blank_And(unwrap mirror);
}


// GET-WORD! and SET-WORD!

INLINE bool Is_Get_Word_Cell(const Cell* c) {
    return (
        Heart_Of(c) == HEART_CHAIN and
        LEADING_BLANK_AND(WORD) == Try_Get_Sequence_Singleheart(c)
    );
}

INLINE bool Is_Get_Word(const Stable* v)
  { return Is_Chain(v) and Is_Get_Word_Cell(v); }

INLINE bool Is_Set_Word_Cell(const Cell* c) {
    return (
        Heart_Of(c) == HEART_CHAIN and
        TRAILING_BLANK_AND(WORD) == Try_Get_Sequence_Singleheart(c)
    );
}

INLINE bool Is_Set_Word(const Stable* v)
  { return Is_Chain(v) and Is_Set_Word_Cell(v); }


// The new /foo: assignment form ensures that the thing being assigned is
// an action.  Places that want to see this as a SET-WORD! (like WRAP) tend
// to be doing so because they want a symbol.  This is a combined interface
// that subsumes testing for both foo: and /foo: and gives the symbol.
//
INLINE Option(const Symbol*) Try_Get_Settable_Word_Symbol(
    Option(Sink(bool)) bound,
    const Element* v
){
    if (Type_Of_Raw(v) > MAX_TYPE_NOQUOTE_NOQUASI)
        return nullptr;
    if (Is_Set_Word_Cell(v)) {
        if (bound)
            *(unwrap bound) = IS_WORD_BOUND(v);
        return Word_Symbol(v);
    }
    if (Heart_Of(v) != HEART_PATH)
        return nullptr;
    if (LEADING_BLANK_AND(CHAIN) != Try_Get_Sequence_Singleheart(v))
        return nullptr;  // v is not /?:?:? style path

    DECLARE_ELEMENT (temp);  // !!! should be able to optimize and not need this
    Copy_Sequence_At_May_Bind(temp, v, 1, Sequence_Binding(v));
    assert(Is_Chain(temp));

    if (TRAILING_BLANK_AND(WORD) != Try_Get_Sequence_Singleheart(temp))
        return nullptr;  // v is not /foo: style path

    if (bound)
        *(unwrap bound) = IS_WORD_BOUND(temp);
    return Word_Symbol(temp);
}

INLINE bool Is_Set_Run_Word(const Stable* v) {
    if (not Is_Path(v))
        return false;

    return did Try_Get_Settable_Word_Symbol(nullptr, As_Element(v));
}


// GET-TUPLE! and SET-TUPLE!

INLINE bool Is_Get_Tuple_Cell(const Cell* c) {
    return (
        Heart_Of(c) == HEART_CHAIN and
        LEADING_BLANK_AND(TUPLE) == Try_Get_Sequence_Singleheart(c)
    );
}

INLINE bool Is_Get_Tuple(const Stable* v)
  { return Is_Chain(v) and Is_Get_Tuple_Cell(v); }

INLINE bool Is_Set_Tuple_Cell(const Cell* c) {
    return (
        Heart_Of(c) == HEART_CHAIN and
        TRAILING_BLANK_AND(TUPLE) == Try_Get_Sequence_Singleheart(c)
    );
}

INLINE bool Is_Set_Tuple(const Stable* v)
  { return Is_Chain(v) and Is_Set_Tuple_Cell(v); }


// GET-BLOCK! and SET-BLOCK!

INLINE bool Is_Get_Block_Cell(const Cell* c) {
    return (
        Heart_Of(c) == HEART_CHAIN and
        LEADING_BLANK_AND(BLOCK) == Try_Get_Sequence_Singleheart(c)
    );
}

INLINE bool Is_Get_Block(const Stable* v)
  { return Is_Chain(v) and Is_Get_Block_Cell(v); }

INLINE bool Is_Set_Block_Cell(const Cell* c) {
    return (
        Heart_Of(c) == HEART_CHAIN and
        TRAILING_BLANK_AND(BLOCK) == Try_Get_Sequence_Singleheart(c)
    );
}

INLINE bool Is_Set_Block(const Stable* v)
  { return Is_Chain(v) and Is_Set_Block_Cell(v); }


// GET-GROUP! and SET-GROUP!

INLINE bool Is_Get_Group_Cell(const Cell* c) {
    return (
        Heart_Of(c) == HEART_CHAIN and
        LEADING_BLANK_AND(GROUP) == Try_Get_Sequence_Singleheart(c)
    );
}

INLINE bool Is_Get_Group(const Stable* v)
  { return Is_Chain(v) and Is_Get_Group_Cell(v); }

INLINE bool Is_Set_Group_Cell(const Cell* c) {
    return (
        Heart_Of(c) == HEART_CHAIN and
        TRAILING_BLANK_AND(GROUP) == Try_Get_Sequence_Singleheart(c)
    );
}

INLINE bool Is_Set_Group(const Stable* v)
  { return Is_Chain(v) and Is_Set_Group_Cell(v); }


INLINE bool Any_Set_Value(const Stable* v) {  // !!! optimize?
    Option(SingleHeart) single;
    return (
        Is_Chain(v)
        and (single = Try_Get_Sequence_Singleheart(v))
        and Singleheart_Has_Trailing_Blank(unwrap single)
    );
}

INLINE bool Any_Get_Value(const Stable* v) {  // !!! optimize?
    Option(SingleHeart) single;
    return (
        Is_Chain(v)
        and (single = Try_Get_Sequence_Singleheart(v))
        and Singleheart_Has_Leading_Blank(unwrap single)
    );
}


#define Is_Refinement Is_Get_Word

INLINE const Symbol* Cell_Refinement_Symbol(const Cell* v) {
    assert(Is_Get_Word_Cell(v));
    return Word_Symbol(v);
}


INLINE Element* Blockify_Any_Sequence(Element* seq) {  // always works
    DECLARE_ELEMENT (temp);
    assume (
      Alias_Any_Sequence_As(temp, seq, HEART_BLOCK)
    );
    Copy_Cell(seq, temp);
    return seq;
}
