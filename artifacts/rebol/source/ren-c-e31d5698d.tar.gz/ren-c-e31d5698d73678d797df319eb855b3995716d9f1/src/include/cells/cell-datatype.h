//
//  file: %cell-datatype.h
//  summary: "DATATYPE! Datatype Header"
//  project: "Rebol 3 Interpreter and Run-time (Ren-C branch)"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012 REBOL Technologies
// Copyright 2012-2025 Ren-C Open Source Contributors
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information.
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Rebol2/Red/R3-Alpha have a notion of a distinct DATATYPE! type, which can
// appear in blocks.  However it never really had a reified lexical form, so
// they would default to looking like WORD!s
//
//    r3-alpha>> reduce [integer! block!]
//    == [integer! block!]
//
// You would have to use something like MOLD:ALL to reveal a LOAD-able syntax
// that would get you a DATATYPE! and not a WORD!:
//
//    r3-alpha>> mold:all reduce [integer! block!]
//    == "[#[datatype! integer!] #[datatype! block!]]"
//
// Ren-C's approach is to leverage antiform fences to act as datatypes:
//
//    >> integer!
//    == ~{integer!}~  ; anti
//
//    >> type of first ['''10]
//    == ~{quoted!}~  ; anti
//
//    >> heart of first ['''10]
//    == ~{integer!}~   ; anti
//
// They cannot be put in blocks, but their metaforms can.  Not being able to
// appear in blocks has advantages, such as disambiguating situations like
// this historical code:
//
//     rebol2>> find [a 1 b c] integer!
//     == [1 b c]
//
//     rebol2>> find compose [a (integer!) b c] integer!
//     == [integer! b c]  ; not a word!, should render as [#[integer!] b c]
//
// The TYPESET! datatype is replaced with the idea of type predicates, which
// are actions (antiform FRAME!)
//
//    >> match any-series?/ [a b c]
//    == [a b c]
//
//    >> match any-series?/ 10
//    == ~null~  ; anti
//
// Enhancements to the speed of type checking predicates are done using
// "intrinsics" as well as a new concept of "typesets" as a table built up
// from %types.r that mixes sparse and ranged byte checking for speed.
//
//=//// NOTES /////////////////////////////////////////////////////////////=//
//
// * %words.r is arranged so symbols for the fundamental types are at the
//   start of the enumeration.
//

// Datatypes cache a byte of their datatype in the array of the FENCE!.
// This is only available on antiforms, which are canonized from arbitrary
// FENCE!s created by the user to the ones made in Startup_Datatypes() which
// have the DATATYPE_BYTE() set.
//
// Non-builtin types will give zero (Datatype_Type() returns an Option(Type))
//
#define DATATYPE_BYTE(source) \
    SECOND_BYTE(&FLEX_INFO(source))


// 1. This returns a RebolValue* to hold the datatype.  This paves the way
//    for the ability to GC datatypes if all references disappear.  (Right
//    now it doesn't work that way because the datatypes live in the
//    SYS.CONTEXTS.DATATYPES module, and are held alive by the module.  Could
//    we have "weak" variables that disappear when when all refs vanish?)
//
// 2. There are some open questions at the moment about how to handle the
//    issue of dependencies in native specs on extension types.  For instance,
//    the FFI extension wants to have parameters that take [library!], but
//    you might load the FFI extension first and then load the library
//    extension...so when the FFI native specs are loaded the parameter
//    generation might crash.  Hence allowing extensions to register the
//    datatypes they depend on before the actual extension providing it
//    is something that this is starting with.
//
INLINE RebolValue* Register_Datatype(const char* name)  // return "holder" [1]
{
    Size size = strsize(name);
    assume (
        const Symbol* symbol = Intern_Symbol(b_cast(name), size)
    );

    Api(Value*) result = Alloc_Value();

    Option(Patch*) patch = Sea_Patch(g_datatypes_context, symbol, true);
    if (patch) {
        Stable* datatype = cast(Stable*, Stub_Cell(unwrap patch));
        assert(Is_Datatype(datatype));
        Copy_Cell(result, datatype);
        return rebUnmanage(result);  // forward registrations [2]
    }

    Source* a = Alloc_Singular(STUB_MASK_MANAGED_SOURCE);
    Init_Word(Stub_Cell(a), symbol);
    Freeze_Source_Deep(a);

    Init(Slot) slot = Append_Context(g_datatypes_context, symbol);
    Stable* datatype = Init_Fence(slot, a);
    Tweak_Cell_Lift_Byte(datatype, TYPE_DATATYPE);

    Copy_Cell(result, datatype);
    return rebUnmanage(result);
}

INLINE void Unregister_Datatype(RebolValue* datatype_holder)
{
    assert(Is_Datatype(As_Stable(datatype_holder)));
    rebRelease(datatype_holder);
}


INLINE bool Is_Symbol_Id_Of_Builtin_Type(SymId id) {
    assert(id != SYM_0_constexpr);
    return (
        i_cast(SymId16, id) >= MIN_SYM_BUILTIN_TYPES
        and i_cast(SymId16, id) <= MAX_SYM_BUILTIN_TYPES
    );
}

INLINE TypeEnum Type_From_Symbol_Id(SymId id) {
    assert(Is_Symbol_Id_Of_Builtin_Type(id));
    return unwrap Type_From_Byte(id - MIN_SYM_BUILTIN_TYPES + 1);
}

INLINE SymId Symbol_Id_From_Type(TypeEnum type) {
    assert(type != TYPE_0_constexpr);
    return i_cast(SymId,
        i_cast(SymId16, Byte_From_Type(type) + MIN_SYM_BUILTIN_TYPES - 1)
    );
}

INLINE SymId Symbol_Id_From_Heart(Heart heart) {
    assert(heart != HEART_0_constexpr);
    return i_cast(SymId,
        i_cast(SymId16, Byte_From_Heart(heart) + MIN_SYM_BUILTIN_TYPES - 1)
    );
}


INLINE Option(SymId) Datatype_Id(const Stable* v) {
    assert(Is_Datatype(v));
    if (Series_Len_At(v) != 1)
        panic ("Type blocks only allowed one element for now");
    const Element* item = List_At(nullptr, v);
    if (not Is_Word(item))
        panic ("Type blocks only allowed WORD! items for now");
    return Word_Id(item);
}

// 1. When a user writes (type: anti '{integer!}) then converting to an
//    antiform is what canonizes the fence's array to one that has the
//    DATATYPE_BYTE() set.  So you can only ask this of antiforms.
//
INLINE Option(Type) Datatype_Type(const Stable* v) {
    assert(Is_Datatype(v));  // only works on antiform [1]
    return Type_From_Byte(DATATYPE_BYTE(Cell_Array(v)));
}

#if RUNTIME_CHECKS
    INLINE Option(Type) Datatype_Type_Slow_Debug(const Stable* v) {
        Option(SymId) id = Datatype_Id(v);
        if (id and Is_Symbol_Id_Of_Builtin_Type(unwrap id))
            return Type_From_Symbol_Id(unwrap id);
        return TYPE_0;
    }
#endif

INLINE Option(Heart) Datatype_Heart(const Stable* v) {
    TypeEnum opt_type = opt Datatype_Type(v);
    assert(opt_type <= MAX_TYPE_HEART);  // no QUOTE/QUASI/ANTI
    return Heart_From_Byte(Byte_From_Type(opt_type));
}

INLINE Heart Datatype_Builtin_Heart(const Stable* v) {
    TypeEnum opt_type = opt Datatype_Type(v);
    assert(opt_type != TYPE_0_constexpr);  // enum class not bool coercible
    assert((opt_type) <= MAX_TYPE_HEART);  // not QUOTED/QUASI/ANTI
    return ii_cast(Heart, Heart_From_Byte(Byte_From_Type(opt_type)));
}

INLINE const ExtraHeart* Datatype_Extra_Heart(const Stable* v) {
    assert(Is_Datatype(v));

    const Symbol* s = Word_Symbol(List_Item_At(v));
    Option(Patch*) patch = Sea_Patch(g_datatypes_context, s, true);
    assert(patch);
    return unwrap patch;
}


INLINE const ExtraHeart* Cell_Extra_Heart(const Cell* v) {
    assert(not Heart_Of(v));
    return cast(ExtraHeart*, v->extra.base);
}

INLINE bool Have_Same_Type(const Stable* a, const Stable* b) {
    Option(Type) ta = Type_Of(a);
    Option(Type) tb = Type_Of(b);
    if ((not ta) and (not tb))
        return (
            Cell_Extra_Heart(Datatype_Of(a))
            == Cell_Extra_Heart(Datatype_Of(b))
        );
    if (Is_Quoted_Type(ta) and Is_Quoted_Type(tb))
        return true;  // all quoted types are same type, regardless of heart
    if (Is_Logic_Type(ta) and Is_Logic_Type(tb))
        return true;  // all logic types are same type, regardless of heart
    return ii_cast(TypeEnum, ta) == ii_cast(TypeEnum, tb);
}


INLINE bool Possibly_Unstable_Value_Has_Datatype(
    const Value* v,
    const Stable* datatype
){
    Option(Type) t = Type_Of_Possibly_Unstable(v);
    Option(Type) dt = Datatype_Type(datatype);
    if (t) {  // built-in type for v
        possibly(not dt);  // can be 0, assume uncommon, make other cases fast

        if (dt == ii_cast(TypeEnum, t))
            return true;  // fast path for builtin types

        if (Is_Quoted_Type(dt) and Is_Quoted_Type(t))
            return true;  // all quoted types are same

        if (Is_Logic_Type(dt) and Is_Logic_Type(t))
            return true;  // all logic types are same type

        return false;
    }
    if (dt)  // built-in datatype
        return false;  // builtin type can't match non-builtin value

    return Datatype_Extra_Heart(datatype) == Cell_Extra_Heart(v);
}


INLINE Stable* Init_Extended_Datatype_Untracked(
    Init(Stable) out,
    const ExtraHeart* ext_heart
){
    assert(Is_Stub_Patch(ext_heart));
    const Stable* datatype = cast(Stable*, Stub_Cell(ext_heart));
    assert(Is_Datatype(datatype));
    return Copy_Cell(out, datatype);
}

#define Init_Extended_Datatype(out,ext_heart) \
    TRACK(Init_Extended_Datatype_Untracked((out), (ext_heart)))


// Used by the Typechecker intrinsic, but also Generic dispatch and PARAMETER!
// typechecking optimization.
//
// 1. The built-in typeset checks can only really match extension types with
//    ANY-ELEMENT? and ANY-FUNDAMENTAL?.  So this should only be checked on
//    extension types *after* the hooks for their ExtraHeart have been done.
//
INLINE bool Builtin_Typeset_Check(
    TypesetByte typeset_byte,
    Option(Type) type  // includes extension types for ANY-ELEMENT?, etc. [1]
){
    TypesetFlags typeset = g_typesets[typeset_byte];

    if (typeset & TYPESET_FLAG_0_RANGE) {  // trivial ranges ok (one datatype)
        TypeEnum start = Type_From_Byte_Or_0(THIRD_BYTE(&typeset));
        TypeEnum end = Type_From_Byte_Or_0(FOURTH_BYTE(&typeset));
        return (
            start <= (opt type)
            and (opt type) <= end
        );
    }

    if ((opt type) > MAX_TYPE_ELEMENT)
        return false;  // antiform, no sparse_memberships (only ranged)

    return did (g_sparse_memberships[Byte_From_Type(type)] & typeset);
}
