//
//  file: %cell-list.h
//  summary: "BLOCK!, GROUP!, FENCE! and their antiforms (Array in payload)"
//  project: "Rebol 3 Interpreter and Run-time (Ren-C branch)"
//  homepage: https://github.com/metaeducation/ren-c/
//
//=////////////////////////////////////////////////////////////////////////=//
//
// Copyright 2012-2026 Ren-C Open Source Contributors
// Copyright 2012 REBOL Technologies
// REBOL is a trademark of REBOL Technologies
//
// See README.md and CREDITS.md for more information
//
// Licensed under the Lesser GPL, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.gnu.org/licenses/lgpl-3.0.html
//
//=////////////////////////////////////////////////////////////////////////=//
//
// "Lists" are Cells which contain an Array, an Index, and a Binding.  The
// three principal types are [BLOCK!], (GROUP!), and {FENCE!}.
//


INLINE bool Is_Cell_Listlike(const Cell* v) {  // PACK!s are allowed
    // called by core code, sacrifice Readable_Cell() checks
    if (Has_List_Heart(v))
        return true;
    if (not Has_Sequence_Heart(v))
        return false;
    if (not Cell_Payload_1_Needs_Mark(v))
        return false;
    const Base* payload1 = SERIESLIKE_PAYLOAD_1_BASE(v);
    if (Is_Base_A_Cell(payload1))
        return true;  // List_At() works, but Cell_Array() won't work!
    return Stub_Flavor(raw_cast(const Flex*, payload1)) == FLAVOR_SOURCE;
}

INLINE const Source* Cell_Array(const Cell* c) {  // PACK!s are allowed
    assert(Is_Cell_Listlike(c));

    const Base* series = SERIESLIKE_PAYLOAD_1_BASE(c);
    assert(Is_Base_A_Stub(series));  // not a pairing arraylike!
    if (Not_Base_Readable(series))
        panic (Error_Series_Data_Freed_Raw());

    return cast(Source*, series);
}

#define Cell_Array_Ensure_Mutable(v) \
    m_cast(Source*, Cell_Array(Ensure_Mutable(v)))

#define Cell_Array_Known_Mutable(v) \
    m_cast(Source*, Cell_Array(Known_Mutable(v)))


// These array operations take the index position into account.  The use
// of the word AT with a missing index is a hint that the index is coming
// from the Series_Index() of the value itself.
//
// IMPORTANT: This routine will trigger a panic if the array index is out
// of bounds of the data.  If a function can deal with such out of bounds
// arrays meaningfully, it should work with SERIES_INDEX_UNBOUNDED().
//
INLINE const Element* List_Len_At(
    Option(Sink(Length)) len_at_out,
    const Cell* cell  // want to be able to pass PACK!s, SPLICE!, etc.
){
    const Base* base = SERIESLIKE_PAYLOAD_1_BASE(cell);
    if (Is_Base_A_Cell(base)) {
        assert(Any_Sequence_Heart(Unchecked_Heart_Of(cell)));
        assert(SERIESLIKE_PAYLOAD_2_INDEX(cell) == 0);
        if (len_at_out)
            *(unwrap len_at_out) = PAIRING_LEN_2;
        return cast(Element*, base);
    }
    const Source* array = cast(Source*, base);
    Index i = SERIESLIKE_PAYLOAD_2_INDEX(cell);
    Length len = Array_Len(array);
    if (i < 0 or i > len)
        panic (Error_Index_Out_Of_Range_Raw());
    if (len_at_out)  // inlining should remove this if() for List_At()
        *(unwrap len_at_out) = len - i;
    return Array_At(array, i);
}

INLINE const Element* List_At(
    Option(const Element**) tail_out,
    const Cell* cell  // want to be able to pass PACK!s, SPLICE!, etc.
){
    const Base* base = SERIESLIKE_PAYLOAD_1_BASE(cell);
    if (Is_Base_A_Cell(base)) {
        assert(Has_Sequence_Heart(cell));
        const Pairing* p = cast(Pairing*, base);
        if (tail_out)
            *(unwrap tail_out) = Pairing_Tail(p);
        return Pairing_Head(p);
    }
    const Source* array = cast(Source*, base);
    Index i = SERIESLIKE_PAYLOAD_2_INDEX(cell);
    Length len = Array_Len(array);
    if (i < 0 or i > len)
        panic (Error_Index_Out_Of_Range_Raw());
    const Element* at = Array_At(array, i);
    if (tail_out)  // inlining should remove this if() for no tail
        *(unwrap tail_out) = at + (len - i);
    return at;
}

INLINE const Element* List_Item_At(const Cell* cell) {
    const Element* tail;
    const Element* item = List_At(&tail, cell);
    assert(item != tail);  // should be a valid value
    return item;
}


#define List_At_Ensure_Mutable(tail_out,v) \
    m_cast(Element*, List_At((tail_out), Ensure_Mutable(v)))

#define List_At_Known_Mutable(tail_out,v) \
    m_cast(Element*, List_At((tail_out), Known_Mutable(v)))


// !!! R3-Alpha introduced concepts of immutable series with PROTECT, but
// did not consider the protected status to apply to binding.  Ren-C added
// more notions of immutability (const, holds, locking/freezing) and enforces
// it at compile-time...which caught many bugs.  But being able to bind
// "immutable" data was mechanically required by R3-Alpha for efficiency...so
// new answers will be needed. :-/
//
#define List_At_Mutable_Hack(tail_out,v) \
    m_cast(Element*, List_At((tail_out), (v)))


//=//// ANY-LIST? INITIALIZER HELPERS ////////////////////////////////////=//
//
// Declaring as inline with type signature ensures you use a Source* to
// initialize.


#define Init_List_At_Core(out,flags,array,index,binding) \
    Init_Series_At_Core( \
        (out), (flags), known(Source*, (array)), (index), (binding))

#define Init_List_At(out,heart,array,index) \
    c_cast(Element*, Init_List_At_Core( \
        rigid_c_cast_known(Init(Element), (out)), \
        FLAG_HEART_AND_LIFT(heart), \
        (array), \
        (index), \
        UNBOUND))

#define Init_List(out,heart,array) \
    Init_List_At((out), (heart), (array), 0)

#define Init_Block(out,array)     Init_List((out), HEART_BLOCK, (array))
#define Init_Group(out,array)     Init_List((out), HEART_GROUP, (array))
#define Init_Fence(out,array)     Init_List((out), HEART_FENCE, (array))


INLINE Element* Init_Relative_Block_At(
    Init(Element) out,
    Details* details,  // action to which array has relative bindings
    Array* array,
    Index index
){
    Reset_Cell_Header(out, CELL_MASK_BLOCK);
    SERIESLIKE_PAYLOAD_1_BASE(out) = array;
    SERIES_INDEX_UNBOUNDED(out) = index;
    Tweak_Cell_Relative_Binding(out, details);
    return out;
}

#define Init_Relative_Block(out,action,array) \
    Init_Relative_Block_At((out), (action), (array), 0)


#if NO_RUNTIME_CHECKS
    #define List_Binding(v) \
        Cell_Binding(v)
#else
    INLINE Context* List_Binding(const Element* v) {
        assert(Is_Cell_Listlike(v));
        Context* c = Cell_Binding(v);
        if (not c)
            return SPECIFIED;

        Flavor flavor = Stub_Flavor(c);
        assert(
            flavor == FLAVOR_LET
            or flavor == FLAVOR_USE
            or flavor == FLAVOR_VARLIST
            or flavor == FLAVOR_SEA
        );
        return c;
    }
#endif


//=//// "SPLICES" (BLOCK! Antiforms) //////////////////////////////////////=//
//
// Block antiforms are understood by routines like APPEND or INSERT or CHANGE
// to mean that you intend to splice their content (the default is to append
// as-is, which is changed from Rebol2/Red).  The typical way of making these
// antiforms is the SPREAD function.
//
//    >> append [a b c] [d e]
//    == [a b c] [d e]
//
//    >> spread [d e]
//    == ~[d e]~  ; anti
//
//    >> append [a b c] ~[d e]~
//    == [a b c d e]
//
// 1. A splice with no elements is referred to as a "NONE".  It has use cases
//    for when you want a type that is "vanishing-like" but that can be stored
//    in a plain variable and can manifest its vanishing intent without an
//    operator like OPT being needed (the way you would need if you stored a
//    null in a variable and wanted to make it void).
//
//    The tradeoff in using none is that it is "truthy".
//

#define Init_Splice(out,a) \
    c_cast(Stable*, Init_List_At_Core( \
        rigid_c_cast_known(Init(Stable), (out)), \
        FLAG_TYPE(TYPE_SPLICE) | FLAG_HEART(HEART_BLOCK_SIGNIFYING_SPLICE), \
        (a), 0, UNBOUND))

#define Init_None(out) \
    Init_Splice((out), EMPTY_ARRAY)

INLINE bool Is_None_Core(const Stable* v) {  // SPLICE with no elements [1]
    if (not Is_Splice(v))
        return false;
    const Element* tail;
    const Element* at = List_At(&tail, v);
    return tail == at;
}

#define Is_None(v) \
    Is_None_Core(Possibly_Antiform(v))

INLINE Stable* Spread_Cell(Exact(Stable*) v) {
    assert(Any_List(v));
    Tweak_Cell_Heart(v, HEART_BLOCK_SIGNIFYING_SPLICE);  // forget former type
    Tweak_Cell_Binding(raw_cast(Element*, v), UNBOUND);
    Tweak_Cell_Lift_Byte(v, TYPE_SPLICE);
    return v;
}

INLINE Element* Unsplice_Cell(Stable* v) {
    assert(Is_Splice(v));
    Tweak_Cell_Lift_Byte(v, TYPE_BLOCK);
    return As_Element(v);
}


//=//// PACK! (GROUP! Antiforms) //////////////////////////////////////////=//
//
// GROUP! antiforms are known as PACK!, and used as a mechanism for bundling
// values so they can be passed as a single value.  They are leveraged in
// particular for multi-return, because SET of WORD! will unpack only the
// first item, while a SET of BLOCK! will unpack others.
//
//      >> pack [<a> <b>]
//      == \~('<a> '<b>)~\  ; antiform (pack!)
//
//      >> x: pack [<a> <b>]
//      == <a>
//
//      >> [x y]: pack [<a> <b>]
//      == <a>
//
//      >> x
//      == <a>
//
//      >> y
//      == <b>
//

#define Init_Pack(out,array) \
    c_cast(Value*, Init_List_At_Core( \
        rigid_c_cast_known(Init(Value), (out)), \
        FLAG_TYPE(TYPE_PACK) | FLAG_HEART(HEART_GROUP_SIGNIFYING_PACK), \
        (array), 0, UNBOUND))

#define Init_Lifted_Pack(out,array) \
    c_cast(Element*, Init_List_At_Core( \
        rigid_c_cast_known(Init(Element), (out)), \
        FLAG_TYPE(TYPE_QUASIFORM) | FLAG_HEART(HEART_GROUP_SIGNIFYING_PACK), \
        (array), 0, UNBOUND))


//=//// "HEAVY VOID" (EMPTY PACK! ANTIFORM) ///////////////////////////////=//
//
// Empty PACK! antiforms are used to represent a "heavy void" value that is
// distinct from the "light void" BLANK! antiform.  This helps in scenarios
// where you want to indicate nothingness without also indicating "vanishing
// intent" (as VOID! will disappear in multi-step evaluations).
//
// While some situations will error on heavy void, some other situations do
// not mind and consider either VOID! or empty PACK! as equally acceptable
// for representing "no value".  This is covered by ANY-VOID?
//

#define Init_Heavy_Void(out) \
    Init_Pack((out), EMPTY_ARRAY)  // Copy_Cell(LIB(HEAVY_VOID))?

#define Init_Lifted_Heavy_Void(out) \
    Init_Lifted_Pack((out), EMPTY_ARRAY)

INLINE bool Is_Heavy_Void_Core(const Value* v) {
    if (not Is_Pack(v))
        return false;
    const Element* tail;
    const Element* at = List_At(&tail, v);
    return tail == at;
}

#define Is_Heavy_Void(v) \
    Is_Heavy_Void_Core(Possibly_Unstable(v))

INLINE bool Is_Lifted_Heavy_Void(const Stable* v) {
    if (not Is_Lifted_Pack(v))
        return false;
    const Element* tail;
    const Element* at = List_At(&tail, v);
    return tail == at;
}

INLINE bool Any_Void_Core(const Value* v) {
    return Is_Void(v) or Is_Heavy_Void(v);
}

#define Any_Void(v) \
    Any_Void_Core(Possibly_Unstable(v))

INLINE bool Is_Any_Lifted_Void(const Stable* v) {
    return Is_Lifted_Void(v) or Is_Lifted_Heavy_Void(v);
}
