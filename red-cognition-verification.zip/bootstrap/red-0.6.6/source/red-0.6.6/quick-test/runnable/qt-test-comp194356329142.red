
			Red []
			do/expand {#do [abcd: 1]}
		