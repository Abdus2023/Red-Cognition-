
			Red []
			; without this line there's no string corruption (any unicode char does the trick):
			; ☺
			; at least one argument in spec must be 2 or more chars long
			spec: [yz [float!]]
			collect [
				=arg=: [
					set name word!
					set types block!
					(keep reduce [name make typeset! types])
				]
				parse spec [any [=arg=]]
			]