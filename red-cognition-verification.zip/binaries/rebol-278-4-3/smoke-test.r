REBOL []
print 1 + 2
quit

